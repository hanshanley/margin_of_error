Maryland2026 complete source card-count query and 24-county reference join
24 county-equivalent card observations plus the separate native state parent.
Cards Cast is NOT qualified cast ballots, certified unique voters or a turnout rate.
Original title includes MIB1/early voting/election day/MIB2; native run11/8/2026 7:44pm,
timezone not supplied. Reporting counters are not individual precinct records or final counting.
All25 native rows, original full PDF, independently verified grid, complete accepted card query,
scope holds and full24-county2026Census geometry are included, not metadata-only.
Baltimore city/county remain separate. Saint Mary's/St. Mary's has one explicit documented alias.
Native Eligible Voters/percentages are retained, never promoted to qualified denominators/rates.
No model fitting/allocation, party participation, precinct geometry or statewide voter total inferred.
Extract every member into an empty directory; Node22+ needs no network/npm:
  node reproduce.mjs > reproduced-queries.json
Compare reproduced-queries.json byte-for-byte with queries.json.
The original independent report parser is supplied separately with its existing dependencies.
The prior native28 and every historical query/download remain unchanged.
