import { readFileSync } from 'node:fs';
import { loadMarylandCardCounts } from './scripts/maryland-county-cards.mjs';
const grid = JSON.parse(readFileSync('data/county-source-reviews/20261109-maryland-cards-01/independent-card-grid.json'));
process.stdout.write(JSON.stringify({ county_counts: loadMarylandCardCounts(),
  separate_native_state_reference: grid.rows.at(-1) }, null, 2) + '\n');
