Complete Denver 2022 county precinct turnout, display layer and offline builder.
Source originals are checksum-pinned in inputs.json; acquire them before offline replay.
Install Shapely 2.2.0, then run:
python3.12 code/denver_precinct_display.py city-original.geojson voting-statistics.csv reproduced.json.gz
The gzip output must match precinct-CO-Denver-2022.json.gz byte for byte.
The polygons are for display only. Ballots are not allocated by geometry.
