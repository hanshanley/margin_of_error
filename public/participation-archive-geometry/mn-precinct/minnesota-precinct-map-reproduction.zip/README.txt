Minnesota general election precinct participation, 2012-2024.

Geometry: Office of the Minnesota Secretary of State and Minnesota Geospatial Information Office.
For definitive precinct lines consult the local election jurisdiction. These display layers
join exact dated precinct IDs and voter counts, and do not allocate counts by geography.

This package includes all 28,757 precinct and 616 state/county query rows. Registration at
7 a.m. and same-day registrations are not a matched denominator. The original workbook bytes
are not redistributed; the full extracted factual participation query is included for each
edition. GIS source responses contain only precinct IDs, counts and polygons.

With CPython 3.12 and Shapely 2.2.0 installed, run from the extracted directory:
python3.12 -m scripts.minnesota_precinct_geometry inputs input-pins.json reproduced
The result should match all files in tiles/.
