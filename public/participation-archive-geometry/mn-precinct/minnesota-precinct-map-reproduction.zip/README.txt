Minnesota general election precinct participation, 2016-2024.

Geometry: Office of the Minnesota Secretary of State and Minnesota Geospatial Information Office. Display only; the agencies do not guarantee definitive precinct lines. The collection used election-year layers, exact full precinct IDs and an independent count comparison, not an allocation. Polling Place Finder: https://pollfinder.sos.mn.gov.

The package includes all 20,549 precinct and 440 state/county query rows. Registration at 7 a.m. and same-day registrations are not a matched denominator. The original workbook bytes are not redistributed; the full extracted factual participation queries are included. GIS source responses contain only precinct IDs, counts and polygons.

With CPython 3.12 and Shapely 2.2.0 installed, run from the extracted directory:
python3.12 -m scripts.minnesota_precinct_geometry inputs input-pins.json reproduced
The result should match all files in tiles/.
