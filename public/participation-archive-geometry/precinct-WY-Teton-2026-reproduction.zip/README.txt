Teton County, Wyoming: 2026 general-election ballots cast, not turnout rates.
The baseline table includes the full official 432-row Wyoming precinct canvass.
The live map may use a newer accepted edition with the same Teton precinct IDs.
The display layer is in native EPSG:3739, not longitude/latitude GeoJSON.
Self-intersections were repaired and ambiguous overlaps removed from both precincts;
no ballots are allocated by geometry. Do not use the layer for legal boundaries.
Download the original precincts.gpkg from the exact URL recorded in the code and layer.
Original county GeoPackage and separate county committee documents are not repackaged.
With CPython 3.12 and Shapely 2.2.0 (GEOS 3.14.1), run offline:
  python3.12 code/teton_precinct_display.py /path/to/precincts.gpkg reproduced.json.gz
  cmp reproduced.json.gz precinct-WY-Teton-2026.json.gz
