2026 native county participation parents: complete sufficient-input reproduction
97 county queries: Idaho44; North Dakota53. No query or hold is omitted.
Counts are explicit native whole-county ballot parents, not candidate sums.
All986 Idaho and358 North Dakota participation rows are retained as validation inputs.
Idaho county ballots match the independent original ballot-report workbook.
43 Idaho native-registration fractions; Twin Falls rate withheld for conflicting registrations.
All53 North Dakota analysis rates and denominators remain withheld; the native API field is preserved.
2026 Census county reference shapes and both complete state identity sets are included.
These are unofficial captured snapshots, not final, demographic or precinct turnout rates.
Original source clocks and literal reporting/certification flags remain unchanged.
Extract this entire archive into an empty directory. With Node22+, run:
  node reproduce.mjs > reproduced-queries.json
Compare reproduced-queries.json byte-for-byte with queries.json.
The original gzip inputs, code and every query/hold are included; no network or npm install is needed.
