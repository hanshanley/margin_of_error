import { loadNativeCountyParents } from './scripts/native-county-parents.mjs';
process.stdout.write(JSON.stringify(loadNativeCountyParents(), null, 2) + '\n');
