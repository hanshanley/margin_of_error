import { loadMichiganCountyParents } from './scripts/michigan-county-parents.mjs';
process.stdout.write(JSON.stringify(loadMichiganCountyParents(), null, 2) + '\n');
