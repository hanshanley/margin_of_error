2026 Michigan native county ballot parents: complete sufficient-input reproduction
Two county queries: Bay50246; Isabella26288. Both analysis rates/denominators are withheld.
These are explicit native county parents, not House votes or derived precinct sums.
Bay's43 reporting counter versus35 report sections remains unresolved.
Isabella's22 City of Clare election ballots versus0 House-scope ballots are not repaired.
All63 native unit records, all four complete workbook tables, original workbook,
five original PDFs, all three native API responses and portable original reviewer are included.
Full83-county 2026 Census reference, source receipts and partial two-county scope are included.
Other81 counties are missing, not zero; no precinct geometry or statewide total is inferred.
Old native97-query and Michigan source archives are unchanged.
Extract this entire archive into an empty directory. With Node22+, run:
  node reproduce.mjs > reproduced-queries.json
Compare reproduced-queries.json byte-for-byte with queries.json. No network/npm is needed.
The separate first-page extraction script uses PyMuPDF and the retained original reviewer;
its --output option accepts a new directory without replacing published inputs.
No original acquisition or full source reduction must be repeated for these queries.
