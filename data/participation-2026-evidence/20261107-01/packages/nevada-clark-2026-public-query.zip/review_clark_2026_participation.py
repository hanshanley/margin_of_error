#!/usr/bin/env python3
import csv
import hashlib
import html
import json
import os
import re
from datetime import datetime
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
ORIGINALS = ROOT / "originals"
RECEIPTS = ROOT / "receipts"
OUTPUTS = ROOT / "outputs"
EXISTING_CURRENT = Path(os.environ["MARGIN_OF_ERROR_CURRENT_EARLY_VOTING"])
EXISTING_HISTORY = Path(os.environ["CLARK_HISTORICAL_REVIEW"])


class OptionParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.options = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "option":
            self.current = {"value": dict(attrs).get("value", ""), "label": ""}

    def handle_data(self, data):
        if self.current is not None:
            self.current["label"] += data

    def handle_endtag(self, tag):
        if tag.lower() == "option" and self.current is not None:
            self.current["label"] = " ".join(self.current["label"].split())
            self.options.append(self.current)
            self.current = None


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def text(path):
    return path.read_text(encoding="utf-8", errors="replace")


def number(value):
    return int(value.replace(",", ""))


def pct(value):
    return float(value.rstrip("%"))


def extract(pattern, source, flags=re.S):
    match = re.search(pattern, source, flags)
    if not match:
        raise ValueError(f"Pattern not found: {pattern}")
    return html.unescape(re.sub(r"<[^>]+>", "", match.group(1))).strip()


def extract_turnout_rows(source):
    rows = {}
    pattern = re.compile(
        r'<tr[^>]*class="turnout-row"[^>]*>.*?'
        r'<td[^>]*>([^<]+Turnout)</td>\s*'
        r'<td[^>]*>([\d,]+)</td>\s*'
        r'<td[^>]*>([\d.]+%)</td>\s*'
        r'<td[^>]*>([\d.]+%)</td>.*?</tr>',
        re.S,
    )
    for label, count, registered_rate, total_share in pattern.findall(source):
        rows[html.unescape(label).strip()] = {
            "count": number(count),
            "registered_rate_percent": pct(registered_rate),
            "total_share_percent": pct(total_share),
        }
    if len(rows) != 5:
        raise ValueError(f"Expected 5 turnout rows, found {len(rows)}")
    return rows


def receipt_date(path):
    for line in text(path).splitlines():
        if line.lower().startswith("date:"):
            return parsedate_to_datetime(line.split(":", 1)[1].strip()).isoformat()
    return None


def existing_rows():
    rows = []
    with EXISTING_CURRENT.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["state_code"] == "NV" and row["geography"] == "Clark":
                rows.append(
                    {
                        "mode": row["mode"],
                        "ballots": int(row["ballots"]),
                        "source_date": row["source_date"],
                        "source_retrieved_at": row["source_retrieved_at"],
                        "source_url": row["source_url"],
                        "status": row["status"],
                    }
                )
    if {row["mode"] for row in rows} != {"in_person_early", "mail_returned"}:
        raise ValueError("Existing Clark rows did not match expected modes")
    return rows


def history_summary():
    payload = json.loads(text(EXISTING_HISTORY))
    result = []
    for observation in payload["observations"]:
        result.append(
            {
                key: observation.get(key)
                for key in (
                    "year",
                    "native_contest",
                    "native_reporting_units",
                    "native_turnout",
                    "summed_native_registration_once_per_unit",
                    "turnout_exceeds_registration_units",
                    "qualified_turnout_rate",
                )
            }
        )
    return {
        "status": payload["status"],
        "source_sha256": sha256(EXISTING_HISTORY),
        "observations": result,
    }


def main():
    OUTPUTS.mkdir(exist_ok=True)
    enr_path = ORIGINALS / "2026-general-enr.html"
    history_form_path = ORIGINALS / "historical-results-form.html"
    early_path = ORIGINALS / "2026-early-voting-summary.html"
    dates_path = OUTPUTS / "2026-important-dates.txt"

    enr = text(enr_path)
    history_form = text(history_form_path)
    early = text(early_path)
    dates = text(dates_path)

    election = extract(r'<div class="election-header">\s*<b>(.*?)</b>', enr)
    status = extract(
        r'<div class="election-header">.*?<b>.*?</b><br/>\s*<b>(.*?)</b>', enr
    )
    updated = extract(r"<b>Updated\s+(.*?)</b>", enr)
    registered = number(extract(r"<span>([\d,]+ Registered Voters)</span>", enr).split()[0])
    turnout_rows = extract_turnout_rows(enr)
    total = number(
        extract(
            r"<tfoot[^>]*>.*?<strong>Total</strong>.*?"
            r"<td><strong>([\d,]+)</strong></td>",
            enr,
        )
    )
    total_rate = pct(
        extract(
            r"<tfoot[^>]*>.*?<strong>Total</strong>.*?"
            r"<td><strong>[\d,]+</strong></td>\s*"
            r"<td><strong>([\d.]+%)</strong></td>",
            enr,
        )
    )
    early_total = number(
        extract(r"<b>Accumulated Total</b></td><td[^>]*><b>([\d,]+)</b>", early)
    )

    parser = OptionParser()
    parser.feed(history_form)
    options = parser.options
    election_options = [
        option for option in options if "ELECTION" in option["label"].upper()
    ]
    category_options = [
        option
        for option in options
        if option["label"]
        in {
            "OFFICIAL ELECTION RESULTS",
            "EARLY VOTE TURNOUT SUMMARY",
            "STATEMENT OF VOTE (RESULTS BY PRECINCT)",
            "VOTER TURNOUT DATA FILE (BY VOTE METHOD)",
            "BALLOT QUESTIONS (TEXT AND AUDIO)",
        }
    ]
    has_2026_general = any(
        "2026 GENERAL ELECTION" in option["label"].upper()
        for option in election_options
    )

    existing = existing_rows()
    prior_early = next(row for row in existing if row["mode"] == "in_person_early")
    prior_mail = next(row for row in existing if row["mode"] == "mail_returned")
    old_history = history_summary()
    retrieved_at = parsedate_to_datetime(
        next(
            line.split(":", 1)[1].strip()
            for line in text(RECEIPTS / "2026-general-enr.html.headers.txt").splitlines()
            if line.lower().startswith("date:")
        )
    )
    retrieved_local = retrieved_at.astimezone(ZoneInfo("America/Los_Angeles"))
    mail_deadline = datetime(
        2026, 11, 7, 17, 0, tzinfo=ZoneInfo("America/Los_Angeles")
    )

    method_sum = sum(row["count"] for row in turnout_rows.values())
    share_sum = sum(row["total_share_percent"] for row in turnout_rows.values())
    calculated_rate = round(100 * total / registered, 2)
    checks = {
        "election_is_2026_general": election == "2026 General Election",
        "status_is_unofficial": status == "Unofficial Results",
        "method_counts_sum_to_total": method_sum == total,
        "reported_rate_matches_count_over_registration": calculated_rate == total_rate,
        "method_shares_sum_to_100": round(share_sum, 2) == 100.00,
        "early_summary_matches_enr": early_total
        == turnout_rows["Early Vote Turnout"]["count"],
        "history_form_declares_turnout_file_category": any(
            option["label"] == "VOTER TURNOUT DATA FILE (BY VOTE METHOD)"
            for option in category_options
        ),
        "history_form_has_no_2026_general_option": not has_2026_general,
        "mail_receipt_deadline_present": all(
            token in dates
            for token in (
                "11/7/26",
                "Last Day for Mail Ballots",
                "postmarked on or before Election Day",
            )
        ),
        "signature_cure_deadline_present": all(
            token in dates
            for token in ("11/9/26", "Last Day for Mail Ballot Signature", "sixth day")
        ),
        "canvass_deadline_present": all(
            token in dates for token in ("11/13/26", "Canvass Deadline")
        ),
        "retrieval_precedes_mail_receipt_deadline": retrieved_local < mail_deadline,
    }
    if not all(checks.values()):
        raise ValueError(f"Failed checks: {[key for key, ok in checks.items() if not ok]}")

    result = {
        "status": "qualified_county_aggregate_unofficial_linked_history_unknown",
        "state_code": "NV",
        "county": "Clark",
        "county_fips": "32003",
        "scope": "Clark County only; never Nevada statewide",
        "retrieved_at": retrieved_at.isoformat(),
        "retrieved_at_clark_county_local": retrieved_local.isoformat(),
        "source_update_label": updated,
        "election": election,
        "result_status": status,
        "registered_voters_current_2026_result_frame": registered,
        "total_turnout": total,
        "turnout_rate_percent_of_current_2026_registration": total_rate,
        "voting_methods": turnout_rows,
        "native_control_checks": checks,
        "credit_posting_status": {
            "provisional_rows_displayed_as_zero": {
                "early_vote": turnout_rows["Early Vote Provisional Turnout"]["count"],
                "election_day": turnout_rows["Election Day Provisional Turnout"]["count"],
            },
            "interpretation": (
                "UNKNOWN, not zero people. The result is explicitly unofficial; Clark "
                "County says provisional ballots are excluded from unofficial results "
                "and final results include provisionals actually counted. Mail receipt, "
                "signature cure, and canvass deadlines were not all complete at retrieval."
            ),
            "mail_ballot_receipt_deadline": "2026-11-07 17:00 America/Los_Angeles",
            "retrieved_before_mail_receipt_deadline": True,
            "mail_signature_cure_deadline": "2026-11-09 17:00 America/Los_Angeles",
            "canvass_deadline": "2026-11-13",
        },
        "history_statistics_form": {
            "turnout_category_declared": True,
            "election_options": election_options,
            "has_2026_general_option": has_2026_general,
            "interpretation": (
                "The permitted historical reporting form declares the turnout-by-method "
                "category but, at retrieval, offers 2026 Primary and not 2026 General. "
                "Therefore 2026 General linked/history-file presence is UNKNOWN, not zero."
            ),
        },
        "linked_frame_status": {
            "status": "UNKNOWN",
            "reason": (
                "No 2026 General history/turnout data-file option was declared on the "
                "historical form, and only public aggregate result pages were acquired. "
                "No person records or identifiers were downloaded."
            ),
        },
        "existing_2026_observations": {
            "rows": existing,
            "existing_early_plus_mail": prior_early["ballots"] + prior_mail["ballots"],
            "new_official_total_minus_existing_two_mode_sum": total
            - prior_early["ballots"]
            - prior_mail["ballots"],
            "qualification": (
                "The prior provider rows are early in-person and returned-mail counts, "
                "not a complete official all-mode Clark total. Mail returned is not "
                "assumed identical to counted mail turnout."
            ),
        },
        "historical_frame_warning": {
            "existing_history_proof": old_history,
            "interpretation": (
                "The 2024 statement denominator belongs to the 2024 election frame; "
                "the 2026 ENR registration count is a current 2026 frame. Differences "
                "cannot identify retained voters, first-time voters, migration, or "
                "candidate choice. Administrative history credits participation only."
            ),
        },
        "integration_disposition": {
            "proposal": "append_only_new_official_clark_county_observation",
            "reason": (
                "This is newer than the existing November 4 provider observations and "
                "adds an official countywide all-mode total plus current registration. "
                "Preserve existing rows and add this separately as unofficial."
            ),
            "publishable_fields": [
                "county",
                "election",
                "source_update_label",
                "result_status",
                "registered_voters_current_2026_result_frame",
                "total_turnout",
                "turnout_rate_percent_of_current_2026_registration",
                "aggregate voting-method counts",
            ],
            "withhold_or_mark_unknown": [
                "2026 linked-person history",
                "returning versus new participants",
                "first vote",
                "candidate choice",
                "final provisional credits",
                "final certified turnout",
                "Nevada statewide implications",
            ],
        },
    }

    source_urls = {
        "2026-general-info.html": "https://www.clarkcountynv.gov/government/departments/elections/26g-info",
        "reports-data-maps.html": "https://www.clarkcountynv.gov/government/departments/elections/reports_data_maps/",
        "historical-results-form.html": "https://elections.clarkcountynv.gov/electionresultsTV/results.aspx",
        "2026-general-enr.html": "https://elections.clarkcountynv.gov/ElectionResults_NV/EnrEng/EnrMain",
        "2026-early-voting-summary.html": "https://elections.clarkcountynv.gov/ElectionResultsTV/evturnout.aspx",
        "facts-26g.pdf": "https://www.clarkcountynv.gov/adobe/assets/urn:aaid:aem:912d393b-be95-46a9-81f0-76326555ef45/original/as/facts-26g.pdf",
        "tabulation.html": "https://www.clarkcountynv.gov/government/departments/elections/services/tabulation",
        "2026-important-dates.pdf": "https://www.clarkcountynv.gov/adobe/assets/urn:aaid:aem:a5950eb8-cb6d-404e-a533-b4856da8aa86/original/as/2026-dates.pdf",
    }
    metadata = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "sources": [
            {
                "file": name,
                "url": url,
                "bytes": (ORIGINALS / name).stat().st_size,
                "sha256": sha256(ORIGINALS / name),
                "retrieved_at": receipt_date(RECEIPTS / f"{name}.headers.txt"),
            }
            for name, url in source_urls.items()
        ],
        "local_comparison_inputs": [
            {
                "path": str(EXISTING_CURRENT),
                "sha256": sha256(EXISTING_CURRENT),
                "use": "existing public aggregate Clark 2026 observations only",
            },
            {
                "path": str(EXISTING_HISTORY),
                "sha256": sha256(EXISTING_HISTORY),
                "use": "existing completed 2020/2022/2024 summary only; no rerun",
            },
        ],
        "privacy": (
            "Only aggregate public pages were acquired. No voter names, addresses, "
            "identifiers, person-level files, or fine cells are included."
        ),
    }

    (OUTPUTS / "clark-2026-participation.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    (OUTPUTS / "source-metadata.json").write_text(
        json.dumps(metadata, indent=2) + "\n"
    )
    with (OUTPUTS / "clark-2026-aggregate.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "state_code",
                "county",
                "election",
                "status",
                "updated",
                "registered_voters",
                "total_turnout",
                "turnout_rate_percent",
                "early_vote",
                "election_day",
                "mail",
                "early_provisional_displayed",
                "election_day_provisional_displayed",
            ]
        )
        writer.writerow(
            [
                "NV",
                "Clark",
                election,
                status,
                updated,
                registered,
                total,
                total_rate,
                turnout_rows["Early Vote Turnout"]["count"],
                turnout_rows["Election Day Turnout"]["count"],
                turnout_rows["Mail Turnout"]["count"],
                turnout_rows["Early Vote Provisional Turnout"]["count"],
                turnout_rows["Election Day Provisional Turnout"]["count"],
            ]
        )
    print(json.dumps({"status": result["status"], "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
