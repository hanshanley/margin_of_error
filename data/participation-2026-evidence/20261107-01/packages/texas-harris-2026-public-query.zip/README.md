# Harris County 2026 participation source review

This package qualifies one official Harris County, Texas, all-mode participation
observation for the November 3, 2026 General and Special Elections.

Primary observation:

- `C. Total Voters (A+B)`: **1,393,495**, from election rosters.
- `Registered Voters`: **2,761,770**; the report does not define active,
  inactive, suspense, cutoff, or report-generation scope.
- Derived registered-voter fraction: **50.45659124402104447510111269222274121306%**.
- Separate `I. Total ballots counted (G+H)`: **1,392,280**, from tabulation
  software.

The report is explicitly **Preliminary Election Reconciliation - Unofficial
Totals**, dated `11/4/2026`, with no native time or timezone. It lists 3,605
provisional rejects/pending, 1,695 mail rejects/pending, 9,752 mail ballots not
returned or pending voter action, and 3,605 estimated provisional ballots.
Overseas/military completion is not declared.

This is county-only. It supports no demographic or party group, linked-history,
first-ever-voter, cohort-retention, or candidate-choice claim.

Run:

```bash
python3 code/review_harris.py
python3 code/build_manifest.py
python3 code/verify_package.py
```

The query requires macOS PDFKit/Vision through the included Swift script. It
verifies the official PDF's exact bytes and SHA-256 before OCR and output.
