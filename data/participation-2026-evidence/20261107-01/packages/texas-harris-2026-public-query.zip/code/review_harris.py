#!/usr/bin/env python3
import csv
import hashlib
import json
import subprocess
import sys
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 40

REVIEW = Path(__file__).resolve().parents[1]
SOURCE = REVIEW / "native-source/harris-2026-general-preliminary-reconciliation.pdf"
OCR = REVIEW / "native-source/harris-2026-general-preliminary-reconciliation.ocr.txt"
OUTPUT = REVIEW / "output"
EXPECTED_SHA256 = "64d92c0f8787191e42d3889caf60ecc5e56a7f1e2a8fdfd406152afcdc60f7b3"
EXPECTED_BYTES = 29813

VALUES = {
    "registered_voters": 2_761_770,
    "in_person_voters": 1_344_609,
    "by_mail_voters": 48_886,
    "total_voters": 1_393_495,
    "provisional_rejected_or_pending": 3_605,
    "mail_rejected_or_pending": 1_695,
    "total_rejected_or_pending": 5_300,
    "in_person_ballots_counted": 1_345_094,
    "mail_ballots_counted": 47_186,
    "total_ballots_counted": 1_392_280,
    "voter_ballot_difference": -4_085,
    "mail_not_returned_or_pending_voter_action": 9_752,
    "estimated_provisional_ballots": 3_605,
}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_ocr():
    subprocess.run(
        [
            "swift",
            str(REVIEW / "code/ocr_native.swift"),
            str(SOURCE),
            str(OCR),
        ],
        check=True,
    )


def verify_source_and_ocr():
    assert SOURCE.stat().st_size == EXPECTED_BYTES
    assert sha256(SOURCE) == EXPECTED_SHA256
    text = OCR.read_text(encoding="utf-8")
    required_literals = [
        "Preliminary Election Reconciliation - Unofficial Totals",
        "County:\nHarris",
        "Election Name: General and Special Elections",
        "Registered Voters:\n2,761,770",
        "Election Date: November 3, 2026",
        "A. In Person Voters",
        "1,344,609",
        "B. By mail voters",
        "48,886",
        "C. Total Voters (A+B)",
        "1,393,495",
        "D. Provisional Ballots",
        "3,605",
        "E. Mail Ballots",
        "1,695",
        "F. Total Ballots",
        "5,300",
        "1,345,094",
        "47,186",
        "1,392,280",
        "-4,085",
        "-0.294%",
        "9,752",
        "Bernard Johnson",
    ]
    for literal in required_literals:
        assert literal in text, literal
    assert text.count("3,605") == 2
    assert "Mail ballot counted number(H) does not include the empty ballot envelopes." in text
    return text


def measure_rows():
    common = {
        "state": "TX",
        "county": "Harris",
        "county_fips": "48201",
        "election_name_native": "General and Special Elections",
        "election_date": "2026-11-03",
        "source_status_native": "Preliminary Election Reconciliation - Unofficial Totals",
        "source_report_date_native": "11/4/2026",
        "source_time_native": "",
        "source_timezone_native": "",
        "group": "all_reported_voters",
    }
    definitions = [
        ("denominator", "registered_voters", "Registered Voters", "all_modes", VALUES["registered_voters"]),
        ("voters", "in_person", "A. In Person Voters", "in_person_all_periods", VALUES["in_person_voters"]),
        ("voters", "by_mail", "B. By mail voters", "mail", VALUES["by_mail_voters"]),
        ("voters", "total", "C. Total Voters (A+B)", "all_reported_modes", VALUES["total_voters"]),
        ("rejected_or_pending", "provisional", "D. Provisional Ballots Rejects or pending", "provisional", VALUES["provisional_rejected_or_pending"]),
        ("rejected_or_pending", "mail", "E. Mail Ballots rejected or pending", "mail", VALUES["mail_rejected_or_pending"]),
        ("rejected_or_pending", "total", "F. Total Ballots rejected or pending (D+E)", "all_reported_modes", VALUES["total_rejected_or_pending"]),
        ("counted_ballots", "in_person", "G. In person ballots counted", "in_person_all_periods", VALUES["in_person_ballots_counted"]),
        ("counted_ballots", "mail", "H. Mail ballot counted", "mail", VALUES["mail_ballots_counted"]),
        ("counted_ballots", "total", "I. Total ballots counted (G+H)", "all_reported_modes", VALUES["total_ballots_counted"]),
        ("reconciliation", "difference", "J. Difference between voters and ballot (C-F-I)", "all_reported_modes", VALUES["voter_ballot_difference"]),
        ("could_be_added", "mail", "N. Mail ballots not returned or pending voter action", "mail", VALUES["mail_not_returned_or_pending_voter_action"]),
        ("could_be_added", "provisional", "O. Estimated Provisional Ballots", "provisional", VALUES["estimated_provisional_ballots"]),
    ]
    rows = []
    for category, mode, native_label, mode_scope, value in definitions:
        rows.append(
            {
                **common,
                "category": category,
                "mode": mode,
                "mode_scope": mode_scope,
                "native_label": native_label,
                "count": value,
            }
        )
    return rows


def build_outputs():
    OUTPUT.mkdir(exist_ok=True)
    rows = measure_rows()
    with (OUTPUT / "county-participation.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    participant_rate = Decimal(VALUES["total_voters"]) * 100 / Decimal(VALUES["registered_voters"])
    counted_rate = Decimal(VALUES["total_ballots_counted"]) * 100 / Decimal(VALUES["registered_voters"])
    payload = {
        "jurisdiction": {"state": "TX", "county": "Harris", "county_fips": "48201"},
        "election": {
            "native_name": "General and Special Elections",
            "date": "2026-11-03",
        },
        "source": {
            "status_native": "Preliminary Election Reconciliation - Unofficial Totals",
            "report_date_native": "11/4/2026",
            "report_time_native": None,
            "timezone_native": None,
            "http_last_modified_utc": "2026-11-04T16:23:10Z",
            "url": "https://www.harrisvotes.com/Portals/harrisvotes/Documents/2026/Reports/1126%20Preliminary%20Election%20Reconciliation%20-%20Unofficial%20Totals.pdf?ver=UZziX2HoKRKkYolHPwg9EQ%3D%3D",
            "bytes": EXPECTED_BYTES,
            "sha256": EXPECTED_SHA256,
        },
        "denominator": {
            "native_label": "Registered Voters",
            "count": VALUES["registered_voters"],
            "active_inactive_or_suspense_scope": "not_declared_in_report",
        },
        "primary_participation_observation": {
            "native_label": "C. Total Voters (A+B)",
            "count": VALUES["total_voters"],
            "source_basis": "election rosters",
            "derived_registered_voter_fraction_percent": str(participant_rate),
        },
        "counted_ballots": {
            "native_label": "I. Total ballots counted (G+H)",
            "count": VALUES["total_ballots_counted"],
            "source_basis": "tabulation software",
            "derived_registered_voter_fraction_percent": str(counted_rate),
        },
        "measures": rows,
        "remaining_and_pending_scope": {
            "provisional_rejected_or_pending": VALUES["provisional_rejected_or_pending"],
            "mail_rejected_or_pending": VALUES["mail_rejected_or_pending"],
            "mail_not_returned_or_pending_voter_action": VALUES["mail_not_returned_or_pending_voter_action"],
            "estimated_provisional_ballots": VALUES["estimated_provisional_ballots"],
            "overseas_or_military_scope": "not_declared_in_report",
            "finality": "preliminary_unofficial_subject_to_change",
        },
        "availability": {
            "demographic_or_party_group_participation": None,
            "linked_cross_election_history": None,
            "candidate_choice": None,
        },
    }
    (OUTPUT / "county-participation.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return payload


def verify_arithmetic(payload):
    assert VALUES["in_person_voters"] + VALUES["by_mail_voters"] == VALUES["total_voters"]
    assert (
        VALUES["provisional_rejected_or_pending"] + VALUES["mail_rejected_or_pending"]
        == VALUES["total_rejected_or_pending"]
    )
    assert (
        VALUES["in_person_ballots_counted"] + VALUES["mail_ballots_counted"]
        == VALUES["total_ballots_counted"]
    )
    difference = (
        VALUES["total_voters"]
        - VALUES["total_rejected_or_pending"]
        - VALUES["total_ballots_counted"]
    )
    assert difference == VALUES["voter_ballot_difference"]
    difference_pct = Decimal(difference) * 100 / Decimal(
        VALUES["total_voters"] - VALUES["total_rejected_or_pending"]
    )
    assert difference_pct.quantize(Decimal("0.001")) == Decimal("-0.294")
    assert len(payload["measures"]) == 13
    return difference_pct


def main():
    if "--skip-ocr" not in sys.argv:
        run_ocr()
    verify_source_and_ocr()
    payload = build_outputs()
    difference_pct = verify_arithmetic(payload)
    verification = {
        "status": "pass",
        "source_bytes": EXPECTED_BYTES,
        "source_sha256": EXPECTED_SHA256,
        "aggregate_rows": len(payload["measures"]),
        "person_rows": 0,
        "primary_participants": VALUES["total_voters"],
        "counted_ballots": VALUES["total_ballots_counted"],
        "registered_voters": VALUES["registered_voters"],
        "difference_percentage_derived": str(difference_pct),
        "candidate_totals_used": False,
        "county_only": True,
        "preliminary_unofficial": True,
    }
    (OUTPUT / "verification.json").write_text(
        json.dumps(verification, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(verification, sort_keys=True))


if __name__ == "__main__":
    main()
