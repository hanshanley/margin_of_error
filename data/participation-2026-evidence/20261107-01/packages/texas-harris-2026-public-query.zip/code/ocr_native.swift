import AppKit
import Foundation
import PDFKit
import Vision

guard CommandLine.arguments.count == 3 else {
    fputs("usage: swift ocr_native.swift INPUT.pdf OUTPUT.txt\n", stderr)
    exit(2)
}

let inputURL = URL(fileURLWithPath: CommandLine.arguments[1])
let outputURL = URL(fileURLWithPath: CommandLine.arguments[2])

guard let document = PDFDocument(url: inputURL),
      document.pageCount == 1,
      let page = document.page(at: 0) else {
    fputs("expected one readable PDF page\n", stderr)
    exit(1)
}

let bounds = page.bounds(for: .mediaBox)
let scale: CGFloat = 4
let width = Int(bounds.width * scale)
let height = Int(bounds.height * scale)

guard let context = CGContext(
    data: nil,
    width: width,
    height: height,
    bitsPerComponent: 8,
    bytesPerRow: 0,
    space: CGColorSpaceCreateDeviceRGB(),
    bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
) else {
    fputs("could not create render context\n", stderr)
    exit(1)
}

context.setFillColor(NSColor.white.cgColor)
context.fill(CGRect(x: 0, y: 0, width: width, height: height))
context.saveGState()
context.scaleBy(x: scale, y: scale)
page.draw(with: .mediaBox, to: context)
context.restoreGState()

guard let image = context.makeImage() else {
    fputs("could not render PDF page\n", stderr)
    exit(1)
}

let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
request.recognitionLanguages = ["en-US"]
request.usesLanguageCorrection = false

try VNImageRequestHandler(cgImage: image, options: [:]).perform([request])
let observations = (request.results ?? []).sorted {
    let firstY = $0.boundingBox.midY
    let secondY = $1.boundingBox.midY
    if abs(firstY - secondY) > 0.008 {
        return firstY > secondY
    }
    return $0.boundingBox.minX < $1.boundingBox.minX
}
let lines = observations.compactMap { $0.topCandidates(1).first?.string }
try (lines.joined(separator: "\n") + "\n").write(
    to: outputURL,
    atomically: true,
    encoding: .utf8
)
print("ocr_lines=\(lines.count)")
