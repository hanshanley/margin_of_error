#!/usr/bin/env python3
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

REVIEW = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


subprocess.run(["python3", str(REVIEW / "code/review_harris.py")], check=True)
manifest = json.loads((REVIEW / "manifest.json").read_text(encoding="utf-8"))
for item in manifest["files"]:
    path = REVIEW / item["path"]
    assert path.is_file(), item["path"]
    assert path.stat().st_size == item["bytes"], item["path"]
    assert sha256(path) == item["sha256"], item["path"]

archive = REVIEW / "complete-query.zip"
if archive.exists():
    with zipfile.ZipFile(archive) as handle:
        bad = handle.testzip()
        assert bad is None, bad

print(f"PASS manifest_files={len(manifest['files'])}")
