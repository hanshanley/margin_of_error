#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

REVIEW = Path(__file__).resolve().parents[1]
EXCLUDED = {"manifest.json", "complete-query.zip"}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


files = []
for path in sorted(REVIEW.rglob("*")):
    if not path.is_file() or path.name in EXCLUDED:
        continue
    files.append(
        {
            "path": str(path.relative_to(REVIEW)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
    )

manifest = {
    "review_id": "texas-harris-turnout-20261107-01",
    "files": files,
}
(REVIEW / "manifest.json").write_text(
    json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(f"manifest_files={len(files)}")
