# Minimal integration proposal

## Proposed diagnostic

**Title:** Butler County current-registrant participation-record presence

**Subtitle:** Current registration records updated November 7, 2026; general-election credit tokens for November 5, 2024 and November 3, 2026.

Render the four-cell table from `public/credit-presence-matrix.csv`:

| 2024 credit record | 2026 credit record | Current registration records |
|---|---|---:|
| Present | Present | 132,229 |
| Present | Not observed | 44,306 |
| Not observed | Present | 16,340 |
| Not observed | Not observed | 56,231 |

## Required language

- “Not observed” means no exact date-specific credit token in the current file.
- It does not mean nonvote, abstention, never-voted, removal, death, or migration.
- This is a current-registrant panel, not the original 2024 voter universe.
- 2024 current-credit count is 9,269 below official 2024 ballots.
- 2026 current-credit count is 115 below the current official-unofficial ballot control.
- The diagnostic does not infer candidate choice from party registration, primary history, or voting method.

## Optional detail

An expandable status table may use `public/status-credit-presence-matrix.csv`. Keep the status definition limited to the county’s current `Active` and `Inactive` labels. Do not publish status reasons or person-level examples.

## Data contract

Use `public/current-registrant-diagnostic.json` as the canonical aggregate payload. Publication must fail closed unless:

1. all four matrix cells are present and sum to 249,106;
2. the exact date tokens remain `11/05/2024` and `11/03/2026`;
3. control differences remain −9,269 and −115 unless the official controls or source snapshot are explicitly versioned;
4. `public/verification.json` reports `pass`;
5. no person-level file is copied into a public directory.

No repository integration was performed.
