# Butler current-registrant diagnostic — v03

This version separates the genuine v01 current-frame evidence from the unidentified original-cohort cells in v02. It makes no original-2024-retention claim.

## Public-safe result

The private November 7, 2026 Butler voter record contains 249,106 unique current registration records: 216,978 Active and 32,128 Inactive. State Voter ID is complete and unique, but no identifier is emitted.

Exact general-election history tokens are parsed from `Election-Party-Method`:

- 2024 General: `11/05/2024`
- 2026 General: `11/03/2026`

| 2024 credit | 2026 credit | Current records |
|---|---|---:|
| present | present | 132,229 |
| present | not observed | 44,306 |
| not observed | present | 16,340 |
| not observed | not observed | 56,231 |

Marginals:

- 2024 credit present: 176,535; not observed: 72,571.
- 2026 credit present: 148,569; not observed: 100,537.

Official-control differences remain native and unclamped:

- 2024: 176,535 current records with credit versus 185,804 official ballots = **−9,269**.
- 2026: 148,569 current records with credit versus 148,684 official-unofficial ballots = **−115**.

The 2024 comparison is not original-voter coverage: its numerator is limited to people still in the November 2026 current registration file. A missing credit is not a measured nonvote, abstention, or never-voted classification. Removal, death, migration, and late posting are unresolved without a separate historical frame.

No candidate choice is inferred from party registration, primary history, or method.

## January 25 clarification

The requested date was **exactly January 25, 2025**, not an unspecified January 2025 snapshot.

- Twenty-two months after January 25, 2025 is November 25, 2026.
- Twenty-two months after the November 5, 2024 election is September 5, 2026.
- A minimum-retention period is not proof that a file is physically gone.

The observed SOS route returned HTTP 403 at 2026-11-07 22:43:02 UTC. It was stopped. The qualified result is only: the exact January 25 file was not acquired and its physical availability was not determined. v03 made no route attempts.

## Package

- `public/current-registrant-diagnostic.json`: complete aggregate result and definitions.
- `public/credit-presence-matrix.csv`: four-cell matrix.
- `public/status-credit-presence-matrix.csv`: coarse Active/Inactive matrix.
- `public/control-comparison.csv`: official-control differences.
- `public/query-spec.json`: entire permitted query set.
- `public/verification.json`: identity, privacy, date, partition, and control tests.
- `provenance.json`: private-original hash and official-source instructions.
- `integration-proposal.md`: minimal, unimplemented publication proposal.
- `code/`: reproducible aggregation and verification.

No raw person IDs, names, dates of birth, addresses, person rows, fine status reasons, or demographic cells are included.
