import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path


VERSION = Path(__file__).resolve().parents[1]
PARENT = VERSION.parent
PUBLIC = VERSION / "public"
PUBLIC.mkdir(exist_ok=True)

PRIVATE_INPUT = PARENT / "originals" / "butler-voter-record-2026-11-07.csv"
PRIVATE_RECEIPT = PRIVATE_INPUT.with_suffix(PRIVATE_INPUT.suffix + ".receipt.json")
HISTORY_PATTERN = re.compile(
    r"(\d{2}/\d{2}/\d{4}) - ([^-]+?) - ([A-Z]+)(?=\s{3}|$)"
)
GENERAL_2024 = "11/05/2024"
GENERAL_2026 = "11/03/2026"
OFFICIAL_2024_BALLOTS = 185_804
OFFICIAL_2026_UNOFFICIAL_BALLOTS = 148_684
PUBLIC_MIN_POSITIVE_CELL = 10


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def public_count(value):
    if value == 0 or value >= PUBLIC_MIN_POSITIVE_CELL:
        return value
    return None


frame_rows = 0
state_ids = Counter()
status_counts = Counter()
matrix = Counter()
status_matrix = Counter()
duplicate_date_token_rows = Counter()

with PRIVATE_INPUT.open(
    "r", encoding="utf-8-sig", errors="replace", newline=""
) as handle:
    reader = csv.DictReader(handle)
    for row in reader:
        frame_rows += 1
        state_id = row["State Voter ID"].strip()
        state_ids[state_id] += 1
        status = row["Voter Status"].strip()
        status_counts[status] += 1

        history = HISTORY_PATTERN.findall(row["Election-Party-Method"])
        tokens_2024 = [token for token in history if token[0] == GENERAL_2024]
        tokens_2026 = [token for token in history if token[0] == GENERAL_2026]
        has_2024 = bool(tokens_2024)
        has_2026 = bool(tokens_2026)
        if len(tokens_2024) > 1:
            duplicate_date_token_rows["2024"] += 1
        if len(tokens_2026) > 1:
            duplicate_date_token_rows["2026"] += 1

        matrix[(has_2024, has_2026)] += 1
        status_matrix[(status, has_2024, has_2026)] += 1

credit_2024 = matrix[(True, False)] + matrix[(True, True)]
credit_2026 = matrix[(False, True)] + matrix[(True, True)]
no_credit_2024 = frame_rows - credit_2024
no_credit_2026 = frame_rows - credit_2026

diagnostic = {
    "diagnostic_name": "Butler County current-registrant general-election credit-record presence",
    "publication_status": "public_safe_aggregate",
    "frame": {
        "snapshot_role": "current county voter-registration record",
        "declared_update_local": "2026-11-07 04:03",
        "records": frame_rows,
        "statuses": dict(status_counts),
        "status_definition": (
            "Active and Inactive are current-file registration-status labels. "
            "No Cancelled records occur in this file."
        ),
        "not_original_2024_frame": True,
    },
    "identity_tests": {
        "state_voter_id_missing_rows": state_ids[""],
        "duplicate_nonblank_state_voter_id_values": sum(
            1 for value, count in state_ids.items() if value and count > 1
        ),
        "maximum_state_voter_id_multiplicity": max(state_ids.values()),
        "use": (
            "IDs establish one row per current registration record only. "
            "No IDs are emitted."
        ),
    },
    "field_mapping": {
        "source_field": "Election-Party-Method",
        "parser": HISTORY_PATTERN.pattern,
        "2024_general_election_date_token": GENERAL_2024,
        "2026_general_election_date_token": GENERAL_2026,
        "presence_rule": (
            "A record is positive when at least one parsed history token exactly "
            "matches the general-election date. Method and party values are not "
            "used for this diagnostic."
        ),
        "duplicate_date_token_rows": dict(duplicate_date_token_rows),
    },
    "credit_record_presence_matrix": {
        "2024_present_2026_present": matrix[(True, True)],
        "2024_present_2026_not_observed": matrix[(True, False)],
        "2024_not_observed_2026_present": matrix[(False, True)],
        "2024_not_observed_2026_not_observed": matrix[(False, False)],
        "total": frame_rows,
    },
    "marginals": {
        "2024_credit_present": credit_2024,
        "2024_credit_not_observed": no_credit_2024,
        "2026_credit_present": credit_2026,
        "2026_credit_not_observed": no_credit_2026,
    },
    "official_control_comparison": {
        "2024": {
            "official_final_ballots_cast": OFFICIAL_2024_BALLOTS,
            "current_records_with_credit": credit_2024,
            "difference_current_credit_minus_official": (
                credit_2024 - OFFICIAL_2024_BALLOTS
            ),
            "ratio_percent": round(
                100 * credit_2024 / OFFICIAL_2024_BALLOTS, 4
            ),
            "universe_warning": (
                "The numerator is 2026 current-registration records carrying a 2024 "
                "credit, not the original 2024 voter universe."
            ),
        },
        "2026": {
            "official_unofficial_ballots_cast": OFFICIAL_2026_UNOFFICIAL_BALLOTS,
            "current_records_with_credit": credit_2026,
            "difference_current_credit_minus_official": (
                credit_2026 - OFFICIAL_2026_UNOFFICIAL_BALLOTS
            ),
            "ratio_percent": round(
                100 * credit_2026 / OFFICIAL_2026_UNOFFICIAL_BALLOTS, 4
            ),
            "posting_warning": (
                "The official control is still unofficial and history posting is "
                "incomplete. No equality is forced."
            ),
        },
    },
    "interpretation_limits": {
        "credit_not_observed": (
            "No date-specific credit token observed in this current file. It is not "
            "a measured nonvote, abstention, or never-voted classification."
        ),
        "removed_deceased_migrated": (
            "People absent from the current file cannot be measured here. Removal, "
            "death, and migration require a separate historical frame."
        ),
        "late_posting": (
            "The 2026 control exceeds current credit records by 115; missing 2026 "
            "credit remains UNKNOWN."
        ),
        "party_candidate_choice": (
            "Party registration, primary history, and method codes are not used to "
            "infer candidate choice."
        ),
        "scope": (
            "This is a current-registrant record-presence diagnostic, not original "
            "2024 voter retention and not candidate-choice validation."
        ),
    },
    "privacy": {
        "person_rows_emitted": False,
        "person_identifiers_emitted": False,
        "minimum_positive_public_cell": PUBLIC_MIN_POSITIVE_CELL,
        "fine_grained_status_reasons_emitted": False,
        "demographic_cells_emitted": False,
    },
}

(PUBLIC / "current-registrant-diagnostic.json").write_text(
    json.dumps(diagnostic, indent=2) + "\n"
)

with (PUBLIC / "credit-presence-matrix.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "credit_2024_general",
            "credit_2026_general",
            "current_registration_records",
        ]
    )
    for has_2024, has_2026 in (
        (True, True),
        (True, False),
        (False, True),
        (False, False),
    ):
        writer.writerow(
            [
                "present" if has_2024 else "not_observed",
                "present" if has_2026 else "not_observed",
                matrix[(has_2024, has_2026)],
            ]
        )

with (PUBLIC / "status-credit-presence-matrix.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "current_registration_status",
            "credit_2024_general",
            "credit_2026_general",
            "current_registration_records",
        ]
    )
    for status in sorted(status_counts):
        for has_2024, has_2026 in (
            (True, True),
            (True, False),
            (False, True),
            (False, False),
        ):
            writer.writerow(
                [
                    status,
                    "present" if has_2024 else "not_observed",
                    "present" if has_2026 else "not_observed",
                    public_count(status_matrix[(status, has_2024, has_2026)]),
                ]
            )

with (PUBLIC / "control-comparison.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "election",
            "official_ballots",
            "current_records_with_credit",
            "credit_minus_official",
            "ratio_percent",
            "control_finality",
        ]
    )
    writer.writerow(
        [
            "2024-11-05 General",
            OFFICIAL_2024_BALLOTS,
            credit_2024,
            credit_2024 - OFFICIAL_2024_BALLOTS,
            diagnostic["official_control_comparison"]["2024"]["ratio_percent"],
            "official final",
        ]
    )
    writer.writerow(
        [
            "2026-11-03 General",
            OFFICIAL_2026_UNOFFICIAL_BALLOTS,
            credit_2026,
            credit_2026 - OFFICIAL_2026_UNOFFICIAL_BALLOTS,
            diagnostic["official_control_comparison"]["2026"]["ratio_percent"],
            "official unofficial",
        ]
    )

query_spec = {
    "private_input": {
        "role": "current Butler County voter record",
        "relative_path_from_parent": str(PRIVATE_INPUT.relative_to(PARENT)),
        "bytes": PRIVATE_INPUT.stat().st_size,
        "sha256": sha256(PRIVATE_INPUT),
        "receipt_sha256": json.loads(PRIVATE_RECEIPT.read_text())["sha256"],
    },
    "queries": [
        {
            "name": "frame_and_identity",
            "group_by": [],
            "outputs": [
                "row count",
                "status totals",
                "missing State Voter ID count",
                "duplicate State Voter ID count",
            ],
        },
        {
            "name": "general_credit_presence_matrix",
            "group_by": [
                "has exact 11/05/2024 history token",
                "has exact 11/03/2026 history token",
            ],
            "output": "current registration record count",
        },
        {
            "name": "status_credit_presence_matrix",
            "group_by": [
                "current Voter Status",
                "2024 credit presence",
                "2026 credit presence",
            ],
            "output": "current registration record count",
            "public_positive_cell_minimum": PUBLIC_MIN_POSITIVE_CELL,
        },
        {
            "name": "official_control_differences",
            "operations": [
                "current credit count minus official ballot count",
                "current credit count divided by official ballot count",
            ],
            "forced_equality_or_clamp": False,
        },
    ],
    "excluded_fields_and_analyses": [
        "names",
        "addresses",
        "dates of birth",
        "person identifiers",
        "registration-party cohorts",
        "candidate choice",
        "fine-grained status reasons",
        "demographic cells",
        "removal/death/migration assignment",
    ],
}
(PUBLIC / "query-spec.json").write_text(json.dumps(query_spec, indent=2) + "\n")

print(json.dumps(diagnostic, indent=2))
