import csv
import hashlib
import json
import re
from pathlib import Path


VERSION = Path(__file__).resolve().parents[1]
PARENT = VERSION.parent
PUBLIC = VERSION / "public"
diagnostic = json.loads((PUBLIC / "current-registrant-diagnostic.json").read_text())
query_spec = json.loads((PUBLIC / "query-spec.json").read_text())


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


with (PUBLIC / "credit-presence-matrix.csv").open(newline="") as handle:
    matrix_rows = list(csv.DictReader(handle))
with (PUBLIC / "status-credit-presence-matrix.csv").open(newline="") as handle:
    status_rows = list(csv.DictReader(handle))

frame = diagnostic["frame"]["records"]
matrix_total = sum(int(row["current_registration_records"]) for row in matrix_rows)
positive_status_cells = [
    int(row["current_registration_records"])
    for row in status_rows
    if row["current_registration_records"] not in ("", "0")
]

public_text = "\n".join(
    path.read_text(errors="replace")
    for path in PUBLIC.iterdir()
    if path.is_file()
).lower()
csv_headers = []
for path in PUBLIC.glob("*.csv"):
    with path.open(newline="") as handle:
        csv_headers.extend(next(csv.reader(handle)))
forbidden_header_terms = ("id", "name", "address", "birth", "phone", "ssn", "dln")

private_input = PARENT / query_spec["private_input"]["relative_path_from_parent"]
checks = {
    "four_matrix_cells_present": len(matrix_rows) == 4,
    "matrix_sums_to_current_frame": matrix_total == frame,
    "identity_unique": (
        diagnostic["identity_tests"]["state_voter_id_missing_rows"] == 0
        and diagnostic["identity_tests"]["duplicate_nonblank_state_voter_id_values"]
        == 0
        and diagnostic["identity_tests"]["maximum_state_voter_id_multiplicity"] == 1
    ),
    "exact_2024_date_mapping": (
        diagnostic["field_mapping"]["2024_general_election_date_token"]
        == "11/05/2024"
    ),
    "exact_2026_date_mapping": (
        diagnostic["field_mapping"]["2026_general_election_date_token"]
        == "11/03/2026"
    ),
    "2024_difference_preserved": (
        diagnostic["official_control_comparison"]["2024"][
            "difference_current_credit_minus_official"
        ]
        == -9269
    ),
    "2026_difference_preserved": (
        diagnostic["official_control_comparison"]["2026"][
            "difference_current_credit_minus_official"
        ]
        == -115
    ),
    "no_small_positive_status_cells": all(value >= 10 for value in positive_status_cells),
    "private_hash_matches": (
        sha256(private_input) == query_spec["private_input"]["sha256"]
    ),
    "no_state_voter_id_values_in_public_text": not re.search(
        r"\boh\d{10}\b", public_text
    ),
    "no_person_fields_in_public_csv_headers": not any(
        any(term in header.lower() for term in forbidden_header_terms)
        for header in csv_headers
    ),
    "scope_is_current_registrant_only": (
        diagnostic["frame"]["not_original_2024_frame"] is True
        and "current-registrant" in diagnostic["diagnostic_name"].lower()
    ),
}

proof = {"status": "pass" if all(checks.values()) else "fail", "checks": checks}
(PUBLIC / "verification.json").write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps(proof, indent=2))
if proof["status"] != "pass":
    raise SystemExit(1)
