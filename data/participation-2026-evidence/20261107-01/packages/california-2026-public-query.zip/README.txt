California 2026 participation qualification

Qualified current native observation:
- voterTurnout: 10,098,551
- totalRegisteredVoters: 23,273,590
- native printed turnout: 43.4%
- native last report: November 6, 2026, 11:00 p.m. (timezone not declared)
- prior observation: 8,928,966
- exact increase: 1,169,585 (13.10%); +5.0 percentage points

Scope:
- voterTurnout is the publisher's native participation measure, not candidate votes.
- It is provisional, uncertified, and not proven to be a final all-mode unique-ballot count.
- The November 3 VoteCal mode snapshot is separate and older. Its native TOTAL BALLOTS
  CAST equals returned VBM plus cast in-person, while its printed definition says accepted;
  therefore it is not joined to the current voterTurnout observation.
- No official matched-denominator group participation or aggregate repeat-participation
  table qualified. No personal voter records were requested or acquired.

Verification:
python3 build_query_package.py --verify
