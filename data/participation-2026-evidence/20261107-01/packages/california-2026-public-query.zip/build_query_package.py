import argparse
import csv
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile

import pdfplumber


ROOT = Path(__file__).parent
QUERY = ROOT / "query"
BASELINE = ROOT / "reused-baseline-20261106"
STATUS_FIELDS = (
    "reportTypeCode",
    "reportNumber",
    "correctionReportnumber",
    "precinctsReporting",
    "precinctsTotal",
    "precinctsReportingPercent",
    "voterTurnout",
    "totalRegisteredVoters",
    "voterTurnoutPercentage",
    "firstReportTimestamp",
    "lastReportTimestamp",
)
BSR_FIELDS = (
    "vbm_issued_distinct_voters",
    "vbm_returned_drop_box",
    "vbm_returned_drop_off_location",
    "vbm_returned_vote_center_drop_off",
    "vbm_returned_mail",
    "vbm_returned_fax",
    "vbm_returned_other",
    "vbm_returned_total",
    "vbm_accepted_total",
    "vbm_accepted_percent_of_returned",
    "in_person_regular",
    "in_person_provisional_non_cvr",
    "in_person_conditional_cvr",
    "in_person_instant_cvr",
    "in_person_cast_total",
    "in_person_accepted_total",
    "in_person_accepted_percent_of_registration",
    "native_total_ballots_cast",
    "native_percent_ballots_cast",
)
INTEGER_BSR_FIELDS = tuple(
    field for field in BSR_FIELDS if "percent" not in field
)
OLD_STATUS_SHA256 = "31bcdfc73ff50e303b917179dc5a4125ef4f5d3996795d2449ea689f7cedfbd4"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def document(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def table(rows, fields=None):
    rows = list(rows)
    require(rows or fields, "CSV requires rows or explicit fields")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(
        stream, fieldnames=fields or list(rows[0]), lineterminator="\n"
    )
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode()


def records(body):
    return list(csv.DictReader(io.StringIO(body.decode())))


def integer(value):
    return int(str(value).replace(",", "").replace(" ", ""))


def percentage(numerator, denominator, places):
    return (
        Decimal(numerator) * 100 / Decimal(denominator)
    ).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)


def verify_receipt(name):
    body = (ROOT / name).read_bytes()
    receipt = json.loads((ROOT / f"{name}.receipt.json").read_text())
    require(receipt["status"] == 200, f"Non-200 receipt: {name}")
    require(receipt["bytes"] == len(body), f"Byte mismatch: {name}")
    require(
        receipt["sha256"] == hashlib.sha256(body).hexdigest(),
        f"Hash mismatch: {name}",
    )
    return body, receipt


def parse_status():
    status_body, status_receipt = verify_receipt("status_GG.json")
    text_body, text_receipt = verify_receipt("V26GG.txt")
    status = json.loads(status_body)
    require(len(status) == 59, "Expected 58 counties plus statewide")
    require(
        {int(row["county"]) for row in status} == set(range(1, 60)),
        "Missing or duplicate native county code",
    )
    status_by_code = {int(row["county"]): row for row in status}
    lines = text_body.decode("utf-8-sig").splitlines()
    require(lines[0].startswith("[B|CAS|1|") and lines[60].startswith("[E|CAS|61|"),
            "Changed V26GG participation framing")
    begin = lines[0][1:-1].split("|")
    end = lines[60][1:-1].split("|")
    require(begin[1] == end[1] and begin[3:] == end[3:],
            "V26GG participation frame clocks differ")
    a_rows = [line[1:-1].split("|") for line in lines if line.startswith("[A|")]
    require(len(a_rows) == 59, "Expected 59 native participation A records")
    for fields in a_rows:
        code = integer(fields[3])
        row = status_by_code[code]
        require(fields[1] == "CAS", "Changed source identity")
        require(tuple(fields[4:]) == tuple(row[field] for field in STATUS_FIELDS),
                f"JSON/text mismatch for native county code {code}")
    for field in ("voterTurnout", "totalRegisteredVoters",
                  "precinctsReporting", "precinctsTotal"):
        require(
            sum(integer(status_by_code[code][field]) for code in range(1, 59))
            == integer(status_by_code[59][field]),
            f"County/statewide mismatch for {field}",
        )
    rows = []
    for code in range(1, 60):
        source = status_by_code[code]
        turnout = integer(source["voterTurnout"])
        registered = integer(source["totalRegisteredVoters"])
        require(
            percentage(turnout, registered, 1)
            == Decimal(source["voterTurnoutPercentage"]),
            f"Turnout arithmetic mismatch for native county code {code}",
        )
        rows.append(
            {
                "year": 2026,
                "election_date": "2026-11-03",
                "state_code": "CA",
                "geography_level": "statewide" if code == 59 else "county",
                "native_county_code": code,
                "county": source["countyName"],
                "county_fips": "",
                "reported_participation": turnout,
                "registered_voters": registered,
                "native_participation_measure_literal": "voterTurnout",
                "native_denominator_measure_literal": "totalRegisteredVoters",
                "native_printed_turnout": source["voterTurnoutPercentage"],
                "native_report_type": source["reportType"],
                "native_report_type_code": source["reportTypeCode"],
                "precincts_reporting": source["precinctsReporting"],
                "precincts_total": source["precinctsTotal"],
                "native_reporting_percent": source["precinctsReportingPercent"],
                "native_first_report_timestamp": source["firstReportTimestamp"],
                "native_last_report_timestamp": source["lastReportTimestamp"],
                "native_timestamp_literal": source["timestamp"],
                "declared_timezone": "",
                "counting_complete": "false",
                "certified": "false",
                "all_mode_unique_ballot_count_proven": "false",
            }
        )
    frame = begin
    return rows, {
        "status_receipt": status_receipt,
        "v26_receipt": text_receipt,
        "v26_generation_date": frame[3],
        "v26_generation_time_literal": frame[4],
        "declared_timezone": None,
    }


def parse_bsr():
    pdf_body, receipt = verify_receipt("bsr-statistics-11-03-26.pdf")
    with pdfplumber.open(io.BytesIO(pdf_body)) as pdf:
        require(len(pdf.pages) == 2, "Changed BSR page count")
        extracted = pdf.pages[0].extract_tables()
        require(len(extracted) == 1, "Changed BSR table count")
        raw = extracted[0]
        require(len(raw) == 62 and len(raw[1]) == 21, "Changed BSR table dimensions")
        source_rows = raw[2:60]
        total_row = raw[60]
        definitions = pdf.pages[1].extract_text() or ""
    require(len(source_rows) == 58, "Expected all 58 BSR county rows")
    rows = []
    for raw_row in source_rows:
        require(len(raw_row) == 21, "Changed BSR row width")
        county, county_type = raw_row[:2]
        values = raw_row[2:]
        parsed = {}
        for field, literal in zip(BSR_FIELDS, values):
            parsed[field] = (
                literal.rstrip("%")
                if "percent" in field
                else integer(literal)
            )
        returned_sum = sum(
            parsed[field]
            for field in (
                "vbm_returned_drop_box",
                "vbm_returned_drop_off_location",
                "vbm_returned_vote_center_drop_off",
                "vbm_returned_mail",
                "vbm_returned_fax",
                "vbm_returned_other",
            )
        )
        in_person_sum = sum(
            parsed[field]
            for field in (
                "in_person_regular",
                "in_person_provisional_non_cvr",
                "in_person_conditional_cvr",
                "in_person_instant_cvr",
            )
        )
        require(returned_sum == parsed["vbm_returned_total"],
                f"VBM return arithmetic mismatch: {county}")
        require(in_person_sum == parsed["in_person_cast_total"],
                f"In-person cast arithmetic mismatch: {county}")
        require(
            parsed["vbm_returned_total"] + parsed["in_person_cast_total"]
            == parsed["native_total_ballots_cast"],
            f"Native total arithmetic mismatch: {county}",
        )
        accepted_components = (
            parsed["vbm_accepted_total"] + parsed["in_person_accepted_total"]
        )
        rows.append(
            {
                "year": 2026,
                "election_date": "2026-11-03",
                "state_code": "CA",
                "as_of_date_literal": "Tuesday, November 3, 2026",
                "as_of_time_literal": "",
                "declared_timezone": "",
                "county": county,
                "county_type": county_type,
                **parsed,
                "accepted_components_sum": accepted_components,
                "native_total_minus_accepted_components": (
                    parsed["native_total_ballots_cast"] - accepted_components
                ),
                "native_total_definition_conflict": "true",
                "counting_complete": "false",
            }
        )
    totals = {
        field: sum(row[field] for row in rows)
        for field in INTEGER_BSR_FIELDS
    }
    printed_totals = {
        field: integer(value)
        for field, value in zip(BSR_FIELDS, total_row[2:])
        if field in INTEGER_BSR_FIELDS
    }
    require(totals == printed_totals, "County sums do not reproduce BSR total row")
    require(
        "This count indicates the total number of ballots accepted" in definitions,
        "Missing native BSR total definition",
    )
    require(
        totals["native_total_ballots_cast"]
        == totals["vbm_returned_total"] + totals["in_person_cast_total"],
        "BSR total does not use returned/cast components",
    )
    require(
        totals["native_total_ballots_cast"]
        != totals["vbm_accepted_total"] + totals["in_person_accepted_total"],
        "Expected native BSR definition/arithmetic conflict disappeared",
    )
    statewide = {
        "year": 2026,
        "election_date": "2026-11-03",
        "state_code": "CA",
        "geography_level": "statewide",
        "as_of_date_literal": "Tuesday, November 3, 2026",
        "as_of_time_literal": "",
        "declared_timezone": "",
        **totals,
        "accepted_components_sum": (
            totals["vbm_accepted_total"] + totals["in_person_accepted_total"]
        ),
        "native_total_minus_accepted_components": (
            totals["native_total_ballots_cast"]
            - totals["vbm_accepted_total"]
            - totals["in_person_accepted_total"]
        ),
        "native_total_definition_literal": (
            "This count indicates the total number of ballots accepted including "
            "VBM ballots, regular ballots, provisional ballots (non-CVR), "
            "conditional ballots (CVR), and instant CVR ballots."
        ),
        "observed_native_total_arithmetic": (
            "vbm_returned_total + in_person_cast_total"
        ),
        "native_total_definition_conflict": "true",
        "counting_complete": "false",
    }
    return rows, statewide, receipt


def parse_unprocessed_release():
    body, receipt = verify_receipt("unprocessed-ballot-report-2026-11-05.html")
    text = body.decode("utf-8")
    processed = re.search(r"processed and counted ([\d,]+) ballots", text)
    remaining = re.search(r"estimate ([\d,]+) outstanding ballots", text)
    require(processed and remaining, "Missing unprocessed-ballot release totals")
    require("November 5, 2026" in text, "Missing release date")
    require("no later than 7 days after Election Day" in text,
            "Missing late-arriving VBM scope")
    return {
        "release_date": "2026-11-05",
        "processed_and_counted_ballots": integer(processed.group(1)),
        "estimated_outstanding_ballots": integer(remaining.group(1)),
        "estimate_scope": "Compilation of estimates from county elections officials.",
        "late_vbm_scope": (
            "VBM ballots postmarked on or before Election Day and received no later "
            "than seven days after Election Day must be processed."
        ),
        "exact_source_time": None,
        "declared_timezone": None,
        "not_contemporaneous_with_current_status_feed": True,
    }, receipt


def baseline():
    county_body = (BASELINE / "county-participation.csv").read_bytes()
    statewide_body = (BASELINE / "statewide-participation.csv").read_bytes()
    audit_body = (BASELINE / "audit.json").read_bytes()
    old_counties = records(county_body)
    old_statewide = records(statewide_body)
    require(len(old_counties) == 58 and len(old_statewide) == 1,
            "Changed reused baseline dimensions")
    return old_counties, old_statewide[0], {
        "source_directory": (
            "data/county-source-reviews/20261106-california-facts-01"
        ),
        "files": {
            "county-participation.csv": {
                "bytes": len(county_body),
                "sha256": hashlib.sha256(county_body).hexdigest(),
            },
            "statewide-participation.csv": {
                "bytes": len(statewide_body),
                "sha256": hashlib.sha256(statewide_body).hexdigest(),
            },
            "audit.json": {
                "bytes": len(audit_body),
                "sha256": hashlib.sha256(audit_body).hexdigest(),
            },
        },
        "old_status_GG_sha256": OLD_STATUS_SHA256,
    }


def source_receipts(new_receipts, baseline_manifest):
    rows = []
    for name, receipt in new_receipts.items():
        rows.append({"source_file": name, "disposition": "new permitted aggregate original",
                     **receipt})
    for name, metadata in baseline_manifest["files"].items():
        rows.append(
            {
                "source_file": f"reused-baseline-20261106/{name}",
                "disposition": "reused existing public-safe frozen query; not reacquired",
                "url": "",
                "final_url": "",
                "status": "",
                "content_type": "",
                "last_modified": "",
                "date_header": "",
                "bytes": metadata["bytes"],
                "sha256": metadata["sha256"],
                "fetched_at_utc": "",
            }
        )
    return rows


def build_outputs():
    participation, status_meta = parse_status()
    mode_rows, mode_statewide, bsr_receipt = parse_bsr()
    unprocessed, release_receipt = parse_unprocessed_release()
    old_counties, old_statewide, baseline_manifest = baseline()
    current_by_name = {row["county"]: row for row in participation[:-1]}
    old_by_name = {row["county"]: row for row in old_counties}
    require(set(current_by_name) == set(old_by_name), "Baseline/current county names differ")
    county_change = []
    for county in sorted(current_by_name):
        current = current_by_name[county]
        old = old_by_name[county]
        old_value = integer(old["reported_participation"])
        new_value = integer(current["reported_participation"])
        county_change.append(
            {
                "county": county,
                "native_measure": "voterTurnout",
                "old_native_last_report_timestamp": old["native_last_report_timestamp"],
                "old_reported_participation": old_value,
                "new_native_last_report_timestamp": current[
                    "native_last_report_timestamp"
                ],
                "new_reported_participation": new_value,
                "absolute_change": new_value - old_value,
                "percent_change_from_old": (
                    Decimal(new_value - old_value) * 100 / Decimal(old_value)
                ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
                "scope_match": "same native measure and registration base",
            }
        )
    current_statewide = participation[-1]
    old_value = integer(old_statewide["reported_participation"])
    new_value = integer(current_statewide["reported_participation"])
    comparison = [
        {
            "comparison": "current native voterTurnout vs reused prior observation",
            "old_value": old_value,
            "new_value": new_value,
            "absolute_change": new_value - old_value,
            "percent_change_from_old": (
                Decimal(new_value - old_value) * 100 / Decimal(old_value)
            ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            "old_turnout_percent": old_statewide["native_printed_turnout"],
            "new_turnout_percent": current_statewide["native_printed_turnout"],
            "turnout_percentage_point_change": (
                Decimal(current_statewide["native_printed_turnout"])
                - Decimal(old_statewide["native_printed_turnout"])
            ),
            "registration_base_old": old_statewide["registered_voters"],
            "registration_base_new": current_statewide["registered_voters"],
            "scope_note": (
                "Exact same native voterTurnout/totalRegisteredVoters measure; "
                "neither observation proves a certified all-mode unique-ballot total."
            ),
        }
    ]
    group_disposition = [
        {
            "dimension": "registration party",
            "participation_numerator": "",
            "matched_denominator": "",
            "publication_value": "",
            "disposition": (
                "NULL: registration denominators exist, but no official 2026 general "
                "participation numerator by registration party was located."
            ),
        },
        {
            "dimension": "race/age/gender",
            "participation_numerator": "",
            "matched_denominator": "",
            "publication_value": "",
            "disposition": (
                "NULL: California SOS states it does not collect voter race, age, or "
                "gender statistics."
            ),
        },
        {
            "dimension": "county election-administration type",
            "participation_numerator": "native_total_ballots_cast",
            "matched_denominator": "vbm_issued_distinct_voters",
            "publication_value": "",
            "disposition": (
                "NOT PROMOTED: VCA/All Mail/Polling Place classifies counties, not "
                "voter groups; the native total also has a definition/arithmetic conflict."
            ),
        },
        {
            "dimension": "repeat participation across elections",
            "participation_numerator": "",
            "matched_denominator": "",
            "publication_value": "",
            "disposition": (
                "NULL: no normally released 2026 aggregate linked-history table observed."
            ),
        },
    ]
    history_gap = {
        "observation_date": "2026-11-07",
        "normally_released_aggregate_repeat_participation_table_found": False,
        "exact_observed_gap": (
            "The SOS statistics index exposes historical election-level totals and "
            "single-election county participation tables, but no table linking the same "
            "people across elections. The general-election historical table currently "
            "ends in 2025, and the county participation index currently ends with the "
            "November 5, 2024 general election."
        ),
        "actual_voter_participation_history_frame": (
            "VoteCal stores voter-linked election date/type/method records. Regulations "
            "require near-real-time county transmission and display each voter's own "
            "history on My Voter Status. A broader History File is available only through "
            "a qualified voter-registration-file request and is personal voter-linked data."
        ),
        "personal_records_acquired": False,
        "request_or_payment_attempted": False,
        "first_ever_voter_claim_supported": False,
        "missing_histories_treatment": "UNKNOWN",
        "normally_declared_remaining_input": (
            "After certification, the 2026 General Election Statement of Vote should "
            "supply the normal single-election county participation table; it will not "
            "by itself establish repeat participation across elections."
        ),
        "official_evidence_urls": [
            "https://www.sos.ca.gov/elections/statistics",
            "https://www.sos.ca.gov/elections/statistics/voter-participation-stats-county",
            "https://www.sos.ca.gov/administration/regulations/current-regulations/elections/statewide-voter-registration-system",
            "https://www.sos.ca.gov/elections/voter-registration/voter-registration-information-file-request",
        ],
    }
    access_disposition = {
        "route": "https://electionresults.sos.ca.gov/unprocessed-ballots-status",
        "observed_result": (
            "Request unsuccessful; Incapsula challenge/incident response returned."
        ),
        "incident_id": "2212000060377301561-128383504699621794",
        "stopped_after_denial": True,
        "alternate_client_host_mirror_cache_partner_copy_attempted": False,
        "numeric_fallback_used": (
            "Official November 5, 2026 SOS press release, downloaded once with receipt."
        ),
    }
    receipts = source_receipts(
        {
            "status_GG.json": status_meta["status_receipt"],
            "V26GG.txt": status_meta["v26_receipt"],
            "bsr-statistics-11-03-26.pdf": bsr_receipt,
            "unprocessed-ballot-report-2026-11-05.html": release_receipt,
        },
        baseline_manifest,
    )
    audit = {
        "state": "California",
        "election": "November 3, 2026 General Election",
        "qualified_newer_native_observation": True,
        "current_native_statewide_voterTurnout": new_value,
        "current_totalRegisteredVoters": integer(
            current_statewide["registered_voters"]
        ),
        "current_native_turnout_percent": current_statewide[
            "native_printed_turnout"
        ],
        "prior_native_statewide_voterTurnout": old_value,
        "absolute_change": new_value - old_value,
        "percent_change_from_prior": str(comparison[0]["percent_change_from_old"]),
        "turnout_percentage_point_change": str(
            comparison[0]["turnout_percentage_point_change"]
        ),
        "native_last_report_timestamp": current_statewide[
            "native_last_report_timestamp"
        ],
        "native_timestamp_literal": current_statewide["native_timestamp_literal"],
        "source_timezone_declared": False,
        "v26_generation": {
            "date": status_meta["v26_generation_date"],
            "time_literal": status_meta["v26_generation_time_literal"],
            "timezone": None,
        },
        "county_rows": 58,
        "mode_rows": 58,
        "county_sums_match_statewide": True,
        "status_json_matches_native_v26_a_records": True,
        "all_mode_unique_ballot_count_proven": False,
        "mode_observation": mode_statewide,
        "mode_observation_disposition": (
            "Retain as a separate November 3 VoteCal snapshot. Do not join its modes "
            "to the November 6 voterTurnout observation and do not promote its native "
            "total as a clean accepted-ballot count because its printed definition and "
            "observed arithmetic conflict."
        ),
        "unprocessed_ballot_scope": unprocessed,
        "provisional_scope": (
            "The November 3 mode snapshot separately reports provisional non-CVR, "
            "conditional CVR, and instant CVR counts. The current voterTurnout feed "
            "does not break them out."
        ),
        "overseas_scope": (
            "No separate overseas-participation numerator is supplied. Fax is a return "
            "channel and is not promoted as an overseas-voter group."
        ),
        "group_participation_promoted": False,
        "repeat_participation_promoted": False,
        "candidate_votes_used_as_ballots": False,
        "registration_party_used_as_candidate_choice": False,
        "unsupported_demographic_turnout_first_time_or_coalition_claims": None,
        "counting_complete": False,
        "certified": False,
        "publication_approval_status": (
            "APPROVED for integration as an explicitly provisional native "
            "voterTurnout update with stated scope; mode snapshot approved only as "
            "separate diagnostic evidence; no group or repeat-history publication."
        ),
    }
    integration_proposal = {
        "current_published_main": "f57cc94570d9f086875bbff022ef1487bbb95f58",
        "repository_modified": False,
        "proposal": [
            (
                "Add the new county-participation.csv and statewide-participation.csv "
                "as a dated provisional California observation; retain the prior "
                "8,928,966 snapshot for audit history rather than overwriting it."
            ),
            (
                "Render 10,098,551 only under the literal native measure voterTurnout, "
                "with 23,273,590 registered voters, 43.4%, native clock November 6, "
                "2026, 11:00 p.m., timezone unknown, counting incomplete, uncertified, "
                "and all-mode unique-ballot status unproven."
            ),
            (
                "Keep the November 3 VoteCal county-mode snapshot in a separate "
                "diagnostic table. Do not allocate those modes to the November 6 "
                "voterTurnout total and do not publish its TOTAL BALLOTS CAST as a "
                "clean accepted-ballot measure."
            ),
            (
                "Leave group, demographic, repeat-participation, first-time-voter, "
                "coalition, and candidate-behavior fields null."
            ),
            (
                "For any later repository patch, start from verified remote main and "
                "stage only the reviewed California package and directly related "
                "validation; do not publish the old dirty feature branch."
            ),
        ],
        "publication_approval": (
            "APPROVED for a surgical provisional participation update subject to the "
            "scope labels above. NOT APPROVED for mode-to-current joins, group claims, "
            "repeat-history claims, certification language, or publication from the "
            "old dirty feature branch."
        ),
    }
    readme = f"""California 2026 participation qualification

Qualified current native observation:
- voterTurnout: {new_value:,}
- totalRegisteredVoters: {integer(current_statewide['registered_voters']):,}
- native printed turnout: {current_statewide['native_printed_turnout']}%
- native last report: {current_statewide['native_timestamp_literal']} (timezone not declared)
- prior observation: {old_value:,}
- exact increase: {new_value - old_value:,} ({comparison[0]['percent_change_from_old']}%); +{comparison[0]['turnout_percentage_point_change']} percentage points

Scope:
- voterTurnout is the publisher's native participation measure, not candidate votes.
- It is provisional, uncertified, and not proven to be a final all-mode unique-ballot count.
- The November 3 VoteCal mode snapshot is separate and older. Its native TOTAL BALLOTS
  CAST equals returned VBM plus cast in-person, while its printed definition says accepted;
  therefore it is not joined to the current voterTurnout observation.
- No official matched-denominator group participation or aggregate repeat-participation
  table qualified. No personal voter records were requested or acquired.

Verification:
python3 build_query_package.py --verify
"""
    outputs = {
        "county-participation.csv": table(participation[:-1]),
        "statewide-participation.csv": table(participation[-1:]),
        "county-change-vs-prior.csv": table(county_change),
        "statewide-comparison.csv": table(comparison),
        "county-mode-snapshot-2026-11-03.csv": table(mode_rows),
        "statewide-mode-snapshot-2026-11-03.csv": table([mode_statewide]),
        "group-participation-disposition.csv": table(group_disposition),
        "history-gap.json": document(history_gap),
        "access-disposition.json": document(access_disposition),
        "source-receipts.csv": table(receipts),
        "audit.json": document(audit),
        "integration-proposal.json": document(integration_proposal),
        "README.txt": readme.encode(),
        "build_query_package.py": Path(__file__).read_bytes(),
    }
    manifest_rows = [
        {
            "file": name,
            "bytes": len(body),
            "sha256": hashlib.sha256(body).hexdigest(),
        }
        for name, body in sorted(outputs.items())
    ]
    outputs["package-manifest.csv"] = table(manifest_rows)
    return outputs


def zip_bytes(outputs):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, body in sorted(outputs.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, body, compresslevel=9)
    return stream.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    require(args.build != args.verify, "Choose exactly one of --build or --verify")
    outputs = build_outputs()
    archive = zip_bytes(outputs)
    if args.build:
        QUERY.mkdir(exist_ok=True)
        require(not any(QUERY.iterdir()), "Query directory must be empty for build")
        for name, body in outputs.items():
            (QUERY / name).write_bytes(body)
        (ROOT / "complete-query.zip").write_bytes(archive)
        print(
            json.dumps(
                {
                    "query_files": len(outputs),
                    "zip_bytes": len(archive),
                    "zip_sha256": hashlib.sha256(archive).hexdigest(),
                },
                indent=2,
            )
        )
    else:
        require(QUERY.is_dir(), "Missing query directory")
        require({path.name for path in QUERY.iterdir()} == set(outputs),
                "Query file inventory mismatch")
        for name, body in outputs.items():
            require((QUERY / name).read_bytes() == body, f"Query mismatch: {name}")
        require((ROOT / "complete-query.zip").read_bytes() == archive,
                "Complete query ZIP mismatch")
        print(
            json.dumps(
                {
                    "verified_query_files": len(outputs),
                    "verified_county_rows": 58,
                    "verified_mode_rows": 58,
                    "zip_bytes": len(archive),
                    "zip_sha256": hashlib.sha256(archive).hexdigest(),
                    "result": "PASS",
                },
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
