#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    args = parser.parse_args()
    package = args.package.resolve()
    work = args.work.resolve()
    if work.exists():
        shutil.rmtree(work)
    subprocess.run([
        sys.executable,
        str(package / "review-colorado-returned-ballots.py"),
        "--input", str(package / "originals"),
        "--output", str(work),
    ], check=True)
    expected = json.loads((package / "checksums.json").read_text())["files"]
    for item in expected:
        selected = package / item["path"]
        reproduced = work / item["path"]
        assert selected.stat().st_size == item["bytes"]
        assert digest(selected) == item["sha256"]
        assert reproduced.read_bytes() == selected.read_bytes(), item["path"]
    county = list(csv.DictReader((work / "county-participation.csv").open()))
    party = list(csv.DictReader((work / "state-party-mode-marginals.csv").open()))
    audit = json.loads((work / "audit.json").read_text())
    assert len(county) == 64
    assert sum(int(row["returned_ballots"]) for row in county) == 2_761_449
    assert len(party) == 33
    assert audit["approvals"]["counted_or_accepted_ballot_label"] is False
    assert audit["approvals"]["age_turnout_rates"] is False
    assert audit["approvals"]["gender_turnout_rates"] is False
    print(json.dumps({"portable_files_reproduced": len(expected), "tests_passed": 7}, indent=2))


if __name__ == "__main__":
    main()
