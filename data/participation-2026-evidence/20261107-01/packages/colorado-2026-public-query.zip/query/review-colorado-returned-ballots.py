#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path

import openpyxl
from pypdf import PdfReader


PARTY_NAMES = {
    "ACN": "American Constitution Party",
    "APV": "Approval Voting Party",
    "CTR": "Colorado Center Party",
    "DEM": "Colorado Democratic Party",
    "FWD": "Colorado Forward Party",
    "GRN": "Green Party of Colorado",
    "LBR": "Libertarian Party of Colorado",
    "NOL": "No Labels Colorado Party",
    "REP": "Colorado Republican Party",
    "UAF": "Unaffiliated",
    "UNI": "Unity Party of Colorado",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def percentage(numerator, denominator):
    return f"{numerator * 100 / denominator:.6f}" if denominator else ""


def write_csv(path, rows, fields):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def county_sheet(workbook, name):
    sheet = workbook[name]
    headers = list(next(sheet.iter_rows(min_row=2, max_row=2, values_only=True))[:13])
    rows, total = {}, None
    for row in sheet.iter_rows(min_row=3, values_only=True):
        if row[0] == "Grand Total":
            total = dict(zip(headers[1:], row[1:13]))
            break
        if row[0] is not None:
            rows[str(row[0])] = dict(zip(headers[1:], row[1:13]))
    return headers[1:], rows, total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    originals = args.input
    output = args.output
    output.mkdir(parents=True, exist_ok=False)

    activity_path = originals / "20261105GenElectionActivity.xlsx"
    registration_path = originals / "OctoberStatistics2026.xlsx"
    release_path = originals / "PR20261106BallotReturns.html"
    summary_path = originals / "20261106GeneralElectionBallotReturn.pdf"
    rules_path = originals / "ColoradoElectionRules-current.pdf"
    statute_path = originals / "ColoradoRevisedStatutes2026-Title1.pdf"
    receipts = json.loads((originals / "source-receipts.json").read_text())

    workbook = openpyxl.load_workbook(activity_path, data_only=True, read_only=True)
    counts = workbook["Voter_Counts"]
    party_codes = list(next(counts.iter_rows(min_row=3, max_row=3, values_only=True))[1:12])
    active_row = list(next(counts.iter_rows(min_row=4, max_row=4, values_only=True))[1:13])
    inactive_row = list(next(counts.iter_rows(min_row=5, max_row=5, values_only=True))[1:13])
    eligible_row = list(next(counts.iter_rows(min_row=6, max_row=6, values_only=True))[1:13])
    active = dict(zip(party_codes, active_row[:11]))
    inactive = dict(zip(party_codes, inactive_row[:11]))
    eligible = dict(zip(party_codes, eligible_row[:11]))
    active_total, inactive_total, eligible_total = active_row[-1], inactive_row[-1], eligible_row[-1]
    assert sum(active.values()) == active_total
    assert sum(inactive.values()) == inactive_total
    assert sum(eligible.values()) == eligible_total == active_total + inactive_total

    headers, all_counties, all_total = county_sheet(workbook, "All_Returned_Ballots_By_County")
    mail_headers, mail_counties, mail_total = county_sheet(workbook, "Returned_Mail_Ballots_By_County")
    person_headers, person_counties, person_total = county_sheet(workbook, "In_Person_Ballots_By_County")
    assert headers == mail_headers == person_headers
    assert set(all_counties) == set(mail_counties) == set(person_counties)
    assert len(all_counties) == 64
    for county in all_counties:
        for field in headers:
            assert all_counties[county][field] == mail_counties[county][field] + person_counties[county][field]
    for field in headers:
        assert sum(row[field] for row in all_counties.values()) == all_total[field]
        assert sum(row[field] for row in mail_counties.values()) == mail_total[field]
        assert sum(row[field] for row in person_counties.values()) == person_total[field]
        assert all_total[field] == mail_total[field] + person_total[field]

    returned_total = all_total["Grand Total"]
    returned_mail = mail_total["Grand Total"]
    returned_person = person_total["Grand Total"]
    assert (returned_total, returned_mail, returned_person) == (2_761_449, 2_618_985, 142_464)

    statewide = [{
        "year": 2026,
        "election_date": "2026-11-03",
        "state_code": "CO",
        "geography_level": "statewide",
        "participation_measure_kind": "official_returned_and_processed_ballots",
        "participation_measure_literal": "ALL RETURNED BALLOTS - MAIL AND IN PERSON COMBINED",
        "returned_ballots": returned_total,
        "returned_mail_ballots": returned_mail,
        "in_person_ballots": returned_person,
        "eligible_registered_voters": eligible_total,
        "active_eligible_registered_voters": active_total,
        "inactive_eligible_registered_voters": inactive_total,
        "returned_per_eligible_registered_pct": percentage(returned_total, eligible_total),
        "source_period_end": "11:59 PM November 5, 2026",
        "source_timezone": "",
        "publication_date": "2026-11-06",
        "source_status": "preliminary returned-and-processed ballot activity",
        "counted_or_accepted_ballots_claimed": "false",
        "certified_or_final_claimed": "false",
        "analysis_rate_approved": "true",
        "map_approved": "false",
    }]
    write_csv(output / "statewide-participation.csv", statewide, list(statewide[0]))

    county_rows = []
    for county in sorted(all_counties):
        county_rows.append({
            "year": 2026,
            "election_date": "2026-11-03",
            "state_code": "CO",
            "native_county": county,
            "geography_level": "county",
            "participation_measure_kind": "official_returned_and_processed_ballots",
            "participation_measure_literal": "ALL RETURNED BALLOTS - MAIL AND IN PERSON COMBINED",
            "returned_ballots": all_counties[county]["Grand Total"],
            "returned_mail_ballots": mail_counties[county]["Grand Total"],
            "in_person_ballots": person_counties[county]["Grand Total"],
            "eligible_registered_voters": "",
            "returned_per_eligible_registered_pct": "",
            "source_period_end": "11:59 PM November 5, 2026",
            "source_timezone": "",
            "publication_date": "2026-11-06",
            "source_status": "preliminary returned-and-processed ballot activity",
            "native_fips": "",
            "analysis_rate_approved": "false",
            "map_approved": "false",
        })
    write_csv(output / "county-participation.csv", county_rows, list(county_rows[0]))

    denominator_rows = []
    mode_rows = []
    modes = [
        ("all_returned", all_total),
        ("returned_mail", mail_total),
        ("in_person", person_total),
    ]
    for code in party_codes:
        denominator_rows.append({
            "party_code": code,
            "party_name": PARTY_NAMES[code],
            "active_eligible_registered": active[code],
            "inactive_eligible_registered": inactive[code],
            "total_eligible_registered": eligible[code],
            "source_definition": "Total Eligible Registered Voter Counts; includes preregistrants who will be 18 by 11/03/2026",
        })
        for mode, totals in modes:
            mode_rows.append({
                "party_code": code,
                "party_name": PARTY_NAMES[code],
                "mode": mode,
                "returned_ballots": totals[code],
                "same_report_total_eligible_registered": eligible[code],
                "returned_per_eligible_registered_pct": percentage(totals[code], eligible[code])
                    if mode == "all_returned" else "",
                "rate_scope": "source-matched all-returned numerator and eligible-registered denominator"
                    if mode == "all_returned" else "channel count only; no channel rate published",
            })
    write_csv(
        output / "state-party-eligible-denominators.csv",
        denominator_rows,
        list(denominator_rows[0]),
    )
    write_csv(output / "state-party-mode-marginals.csv", mode_rows, list(mode_rows[0]))

    county_party_rows = []
    for county in sorted(all_counties):
        for code in party_codes:
            for mode, source in [
                ("all_returned", all_counties),
                ("returned_mail", mail_counties),
                ("in_person", person_counties),
            ]:
                county_party_rows.append({
                    "state_code": "CO",
                    "native_county": county,
                    "party_code": code,
                    "party_name": PARTY_NAMES[code],
                    "mode": mode,
                    "returned_ballots": source[county][code],
                    "eligible_registered_voters": "",
                    "returned_per_eligible_registered_pct": "",
                    "interpretation": "count marginal only; source supplies no county-party registered denominator",
                })
    write_csv(output / "county-party-mode-marginals.csv", county_party_rows, list(county_party_rows[0]))

    gender_sheet = workbook["All_Returned_Ballots_GenderAge"]
    gender_totals, age_totals, current_gender = {}, {
        "<18": 0, "18-24": 0, "25-34": 0, "35-44": 0,
        "45-54": 0, "55-64": 0, "65-74": 0, "75 AND OVER": 0,
    }, None
    for row in gender_sheet.iter_rows(min_row=3, max_row=38, values_only=True):
        label, value = row[0], row[-1]
        if label in {"Female", "Male", "Not Disclosed", "X"}:
            current_gender = label
            gender_totals[label] = value
        elif label in age_totals:
            assert current_gender is not None
            age_totals[label] += value
    assert sum(gender_totals.values()) == sum(age_totals.values()) == returned_total
    age_rows = [{
        "age_range": label,
        "returned_ballots": value,
        "share_of_returned_ballots_pct": percentage(value, returned_total),
        "turnout_rate": "",
        "limitation": "composition only; no same-report registered-age denominator",
    } for label, value in age_totals.items()]
    gender_rows = [{
        "gender_recorded": label,
        "returned_ballots": value,
        "share_of_returned_ballots_pct": percentage(value, returned_total),
        "turnout_rate": "",
        "limitation": "composition only; no same-report registered-gender denominator",
    } for label, value in gender_totals.items()]
    write_csv(output / "age-composition.csv", age_rows, list(age_rows[0]))
    write_csv(output / "gender-composition.csv", gender_rows, list(gender_rows[0]))

    native_cells, sheet_inventory = [], []
    for sheet in workbook.worksheets:
        nonempty = 0
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value is None:
                    continue
                nonempty += 1
                native_cells.append({
                    "sheet": sheet.title,
                    "cell": cell.coordinate,
                    "row": cell.row,
                    "column": cell.column,
                    "value_type": "number" if isinstance(cell.value, (int, float)) else "text",
                    "value": cell.value,
                })
        sheet_inventory.append({
            "sheet": sheet.title,
            "max_row": sheet.max_row,
            "max_column": sheet.max_column,
            "nonempty_cells": nonempty,
        })
    write_csv(output / "source-native-cells.csv", native_cells, list(native_cells[0]))
    write_csv(output / "source-sheet-inventory.csv", sheet_inventory, list(sheet_inventory[0]))

    registration = openpyxl.load_workbook(registration_path, data_only=True, read_only=True)
    registration_total = next(
        row for row in registration["Status"].iter_rows(min_row=3, values_only=True) if row[0] == "Total"
    )
    nov1_active, nov1_inactive, nov1_prereg, nov1_total = registration_total[1:5]
    assert nov1_active + nov1_inactive + nov1_prereg == nov1_total
    assert eligible_total - (nov1_active + nov1_inactive) == 8_407

    release_text = release_path.read_text(errors="replace")
    for expected in ["2,761,449", "20261105GenElectionActivity.xlsx",
                     "All data as of 11:59 PM November 5, 2026"]:
        assert expected in release_text
    pdf_text = "\n".join(page.extract_text() or "" for page in PdfReader(summary_path).pages)
    for expected in ["2,761,449", "2,618,985", "142,464", "11/5/2026"]:
        assert expected in pdf_text
    rules_text = "\n".join(page.extract_text() or "" for page in PdfReader(rules_path).pages)
    statute_text = "\n".join(page.extract_text() or "" for page in PdfReader(statute_path).pages)
    assert "inactive registration status to active" in rules_text
    assert 'registration record is marked "Inactive" is eligible to vote' in statute_text

    qualification = {
        "schema_version": 1,
        "election": "Colorado 2026 General Election",
        "publisher": "Colorado Secretary of State",
        "publication_date": "2026-11-06",
        "source_period_end": "11:59 PM November 5, 2026",
        "source_timezone": None,
        "measure": "Returned and processed ballots; mail and in-person combined",
        "not_measure": [
            "certified final ballots cast",
            "all accepted ballots",
            "all counted ballots",
            "candidate selections",
            "demographic turnout rates",
        ],
        "denominator": {
            "literal": "Total Eligible Registered Voter Counts (Includes Pre-Registrants who will be 18 by 11/03/2026)",
            "active": active_total,
            "inactive": inactive_total,
            "total": eligible_total,
            "use": "statewide and party all-returned fractions only",
            "county_denominators_supplied": False,
            "age_denominators_supplied": False,
            "gender_denominators_supplied": False,
        },
        "registration_status": {
            "inactive_eligible_if_otherwise_qualified": True,
            "statute": "2026 C.R.S. 1-2-605(3)-(5)",
            "rule": "8 CCR 1505-1 Rule 2.6.1",
        },
        "sources": receipts,
        "privacy": "Aggregate public data only; no person records or voter IDs.",
    }
    (output / "source-qualification.json").write_text(json.dumps(qualification, indent=2) + "\n")

    audit = {
        "row_counts": {
            "county-participation.csv": len(county_rows),
            "state-party-eligible-denominators.csv": len(denominator_rows),
            "state-party-mode-marginals.csv": len(mode_rows),
            "county-party-mode-marginals.csv": len(county_party_rows),
            "age-composition.csv": len(age_rows),
            "gender-composition.csv": len(gender_rows),
            "source-native-cells.csv": len(native_cells),
            "source-sheet-inventory.csv": len(sheet_inventory),
        },
        "statewide": {
            "returned_all": returned_total,
            "returned_mail": returned_mail,
            "in_person": returned_person,
            "active_eligible_registered": active_total,
            "inactive_eligible_registered": inactive_total,
            "total_eligible_registered": eligible_total,
            "returned_per_eligible_registered_pct": percentage(returned_total, eligible_total),
        },
        "checks": {
            "all_64_counties_present": len(county_rows) == 64,
            "every_county_party_all_equals_mail_plus_in_person": True,
            "county_sums_equal_every_native_state_party_and_mode_total": True,
            "state_party_denominators_sum_to_native_status_totals": True,
            "gender_composition_sums_to_state_total": True,
            "age_composition_sums_to_state_total": True,
            "press_release_period_and_workbook_link_verified": True,
            "pdf_totals_independently_verified": True,
            "nov1_snapshot_not_substituted_for_nov5_county_denominators": True,
            "age_and_gender_rates_withheld": True,
        },
        "approvals": {
            "statewide_all_returned_registered_fraction": True,
            "party_all_returned_registered_fractions": True,
            "county_registered_fractions": False,
            "age_turnout_rates": False,
            "gender_turnout_rates": False,
            "maps": False,
            "counted_or_accepted_ballot_label": False,
        },
    }
    (output / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")

    methods = {
        "schema_version": 1,
        "scope": "Complete numerical review of the Colorado Secretary of State November 6 returned-ballot workbook.",
        "input": "All seven workbook sheets, all 64 counties, eleven party-registration groups, three mode scopes, same-workbook statewide eligible registration denominators, and age/gender returned-ballot compositions.",
        "arithmetic": "Require every county-party all-returned cell to equal mail plus in-person; reproduce every native statewide party/mode total from 64 counties; independently sum age and gender compositions.",
        "measure_separation": "Preserve returned-and-processed ballots as a distinct measure. Never relabel as accepted, counted, certified, final, ballots cast, or unique voters.",
        "denominators": "Use the same workbook's eligible registered voter totals only for statewide and party all-returned fractions. County, age, gender, and channel-specific rates remain withheld.",
        "clocks": "Use the source-declared 11:59 PM November 5, 2026 activity period and November 6 publication date. The source declares no timezone; fetch and HTTP clocks are provenance only.",
        "geography": "Source county names contain no native FIPS. Any atlas identity join is a separate contextual review and does not change source map approval.",
        "privacy": "Aggregate public data only.",
        "reproduction": "Run this script against the cached originals into a new empty directory.",
    }
    (output / "methods.json").write_text(json.dumps(methods, indent=2) + "\n")

    files = []
    for path in sorted(output.iterdir()):
        if path.is_file() and path.name != "checksums.json":
            files.append({"path": path.name, "bytes": path.stat().st_size, "sha256": digest(path)})
    (output / "checksums.json").write_text(json.dumps({"files": files}, indent=2) + "\n")


if __name__ == "__main__":
    main()
