# Colorado 2026 append-only integration proposal

## New versus existing

The captured official source is **genuinely newer and a missing measure**, not a duplicate.

| Scope | Current repo, source date Nov. 4 | Official period ending Nov. 5, 11:59 PM | Raw difference |
|---|---:|---:|---:|
| Returned mail | 2,543,484 | 2,618,985 | +75,501 |
| In-person | 138,130 (`in_person_early`) | 142,464 (`In Person Ballots`) | +4,334 |
| Two channels / official all returned | 2,681,614, not stored as an official combined measure | 2,761,449 | +79,835 |

The current snapshot marks Colorado `official_status=not_yet_ingested`, has no official reporting row, and supplies no source-defined eligible-registration denominator. The new workbook supplies 4,106,918 active plus 521,022 inactive eligible registrants = **4,627,940**, yielding **59.669075% returned / eligible registered**.

The in-person labels are not treated as identical: the current `in_person_early` query remains immutable, while the official post-election `In Person Ballots` measure is appended separately.
The official source gives the period as 11:59 PM November 5 but declares no timezone.

## Proposed delivery

- Complete proposed repo directory: `proposed-data/county-source-reviews/20261107-colorado-returned-ballots-01/`
- Registry object: `proposed-review-registry-entry.json`
- Integration contract: `proposed-integration-plan.json`
- Existing/current comparison: `current-vs-official-comparison.json`
- All 64 county raw differences: `county-mode-comparison.csv`
- Exact joins to the existing Colorado atlas: `proposed-existing-atlas-joins.csv`
- Proposed measure-specific coverage row: `proposed-source-coverage-row.json`

The complete query ZIP is 5,687,210 bytes, SHA-256 `496130ffb917f970acf100eb9aeb5183c0d36e6bd6741a684013d6be75e22b3d`.

## Measure safeguards

- Preserve **returned and processed ballots** as distinct from accepted, counted, certified, final, ballots cast, or unique voters.
- Do not overwrite or relabel the Nov. 4 civicAPI queries.
- Do not derive county rates: the source supplies no county eligible-registration denominators.
- Age and gender are returned-ballot composition only; no group turnout rates or inferred denominators.
- Party is registration affiliation, not candidate choice.
- Reuse the existing 64-county Colorado atlas by exact aliases; native FIPS and source map approval remain absent/false.
- Keep context25 immutable; any atlas integration is a successor append-only version, not a replacement and not a new UI card.

## Validation

The source-review reproducer preserves every nonempty cell from all seven official workbook sheets, all 64 counties, 11 party denominators, 33 statewide party/mode marginals and 2,112 county-party-mode marginals. Portable regeneration reproduced all 12 selected numerical files byte-for-byte and passed seven package assertions.
