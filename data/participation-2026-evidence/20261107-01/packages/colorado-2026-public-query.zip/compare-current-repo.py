#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, records):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo, package, output = args.repo.resolve(), args.package.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)

    pointer_path = repo / "public/participation-current/latest.json"
    pointer = json.loads(pointer_path.read_text())
    current = repo / "public/participation-current" / pointer["snapshot_id"]
    coverage_path = current / "coverage.csv"
    early_path = current / "early_voting.csv"
    demographics_path = current / "demographics.csv"
    snapshot_path = current / "snapshot.json"
    registry_path = repo / "public/participation-source-reviews.json"
    context25_review = repo / "public/participation-county-context/20261106-25/review.json"
    context25_zip = repo / "public/participation-county-context/20261106-25/complete-county-participation-context-25.zip"
    atlas_path = repo / "public/participation-context/20261104T183601Z/geometry/county-CO.geojson"

    coverage = next(row for row in rows(coverage_path) if row["state_code"] == "CO")
    current_early = [row for row in rows(early_path) if row["state_code"] == "CO"]
    current_demographics = [row for row in rows(demographics_path) if row["state_code"] == "CO"]
    current_state = {(row["mode"], row["geography"]): row for row in current_early
                     if row["geography_level"] == "state"}
    current_county = {(row["mode"], row["geography"]): row for row in current_early
                      if row["geography_level"] == "source_region"}
    assert len(current_county) == 128
    old_mail = int(current_state[("mail_returned", "STATEWIDE")]["ballots"])
    old_person = int(current_state[("in_person_early", "STATEWIDE")]["ballots"])
    assert old_mail == sum(int(row["ballots"]) for row in current_county.values()
                           if row["mode"] == "mail_returned")
    assert old_person == sum(int(row["ballots"]) for row in current_county.values()
                             if row["mode"] == "in_person_early")

    statewide = rows(package / "statewide-participation.csv")[0]
    new_counties = rows(package / "county-participation.csv")
    new_mail = int(statewide["returned_mail_ballots"])
    new_person = int(statewide["in_person_ballots"])
    new_all = int(statewide["returned_ballots"])
    new_denominator = int(statewide["eligible_registered_voters"])
    assert len(new_counties) == 64
    assert new_all == new_mail + new_person

    deltas = []
    for row in new_counties:
        county = row["native_county"]
        old_county_mail = int(current_county[("mail_returned", county)]["ballots"])
        old_county_person = int(current_county[("in_person_early", county)]["ballots"])
        new_county_mail = int(row["returned_mail_ballots"])
        new_county_person = int(row["in_person_ballots"])
        deltas.append({
            "county": county,
            "current_20261104_mail_returned": old_county_mail,
            "official_20261105_returned_mail": new_county_mail,
            "mail_raw_difference": new_county_mail - old_county_mail,
            "current_20261104_in_person_early": old_county_person,
            "official_20261105_in_person": new_county_person,
            "in_person_raw_difference": new_county_person - old_county_person,
            "current_two_channel_sum_not_stored_as_official_all_returned": old_county_mail + old_county_person,
            "official_all_returned": int(row["returned_ballots"]),
            "combined_raw_difference": int(row["returned_ballots"]) - old_county_mail - old_county_person,
            "comparison_limit": "mail is a newer cumulative returned-mail count; in-person label/scope changed, so its difference is descriptive only",
        })
    assert all(int(row["mail_raw_difference"]) > 0 for row in deltas)
    assert all(int(row["in_person_raw_difference"]) >= 0 for row in deltas)
    assert sum(int(row["official_all_returned"]) for row in deltas) == new_all
    write_csv(output / "county-mode-comparison.csv", deltas)

    atlas = json.loads(atlas_path.read_text())
    alias_map = {}
    for feature in atlas["features"]:
        properties = feature["properties"]
        for alias in properties["aliases"]:
            assert alias not in alias_map
            alias_map[alias] = properties
    joins = []
    for row in new_counties:
        native = row["native_county"]
        properties = alias_map[native]
        joins.append({
            "native_county": native,
            "existing_atlas_key": properties["key"],
            "existing_atlas_name": properties["name"],
            "existing_boundary_year": properties["boundary_year"],
            "join_basis": "exact existing alias",
            "new_geometry_required": "false",
            "source_map_approved": "false",
            "contextual_join_proposed": "true",
        })
    assert len(joins) == 64
    assert len({row["existing_atlas_key"] for row in joins}) == 64
    write_csv(output / "proposed-existing-atlas-joins.csv", joins)

    registry = json.loads(registry_path.read_text())
    assert not any("colorado" in (review["id"] + " " + review["label"]).lower()
                   for review in registry["reviews"])
    source_workbook = package / "originals/20261105GenElectionActivity.xlsx"
    source_workbook_sha256 = digest(source_workbook)
    same_name = [str(path.relative_to(repo)) for base in (repo / "data", repo / "public")
                 for path in base.rglob("20261105GenElectionActivity*")]
    same_bytes = []
    for base in (repo / "data", repo / "public"):
        for path in base.rglob("*"):
            if path.is_file() and path.stat().st_size == source_workbook.stat().st_size \
                    and digest(path) == source_workbook_sha256:
                same_bytes.append(str(path.relative_to(repo)))
    assert not same_name and not same_bytes
    context = json.loads(context25_review.read_text())
    assert not any(row.get("state_code") == "CO" for row in context["observations"])
    assert not any(row.get("state_code") == "CO" for row in context["source_selections"])

    comparison = {
        "classification": "genuine_newer_missing_official_measure",
        "duplicate_version": False,
        "duplicate_detection": {
            "official_workbook_sha256": source_workbook_sha256,
            "matching_repo_filenames": same_name,
            "matching_repo_bytes": same_bytes,
            "existing_colorado_source_review_entries": 0,
        },
        "current_repo": {
            "pointer": str(pointer_path.relative_to(repo)),
            "snapshot_id": pointer["snapshot_id"],
            "snapshot_retrieved_at": pointer["retrieved_at"],
            "source_date": sorted({row["source_date"] for row in current_early}),
            "source_retrieved_at": sorted({row["source_retrieved_at"] for row in current_early}),
            "coverage": coverage,
            "statewide": {
                "mail_returned": old_mail,
                "in_person_early": old_person,
                "two_channel_sum_not_stored_as_official_all_returned": old_mail + old_person,
                "official_ballots_row": None,
                "source_defined_eligible_registered_denominator": None,
            },
            "demographic_scope": {
                "rows": len(current_demographics),
                "dimensions": sorted({row["dimension"] for row in current_demographics}),
                "interpretation": "counts/composition only; no group turnout rates",
            },
        },
        "captured_official": {
            "publication_date": statewide["publication_date"],
            "source_period_end": statewide["source_period_end"],
            "source_timezone": statewide["source_timezone"] or None,
            "statewide": {
                "all_returned": new_all,
                "returned_mail": new_mail,
                "in_person": new_person,
                "eligible_registered": new_denominator,
                "returned_per_eligible_registered_pct": statewide["returned_per_eligible_registered_pct"],
            },
            "raw_differences_from_current_two_channels": {
                "returned_mail": new_mail - old_mail,
                "in_person_scope_changed": new_person - old_person,
                "combined": new_all - old_mail - old_person,
            },
            "county_rows": len(new_counties),
            "party_denominator_rows": len(rows(package / "state-party-eligible-denominators.csv")),
            "party_mode_rows": len(rows(package / "state-party-mode-marginals.csv")),
            "county_party_mode_rows": len(rows(package / "county-party-mode-marginals.csv")),
        },
        "why_not_identical": [
            "Current repo source_date is 2026-11-04; official report period ends 11:59 PM 2026-11-05 and was published 2026-11-06.",
            "Current repo marks Colorado official_status not_yet_ingested and has no official reporting row.",
            "Current repo has separate civicAPI mail_returned and in_person_early counts but no source-defined all-returned measure or eligible-registered denominator.",
            "Official source supplies all returned, returned mail, in-person, party marginals, and same-workbook eligible active/inactive registration denominators.",
        ],
        "measure_limits": [
            "Returned-and-processed ballots remain distinct from accepted, counted, certified, final, ballots cast, or unique voters.",
            "The existing in_person_early label is retained; the official in-person measure is appended rather than substituted under that label.",
            "Age and gender remain returned-ballot composition only; no age/gender registered denominators or turnout rates are derived.",
            "County registered denominators are absent, so county rates remain withheld.",
        ],
        "existing_assets_preserved": {
            "current_snapshot": str(current.relative_to(repo)),
            "context25_review_sha256": digest(context25_review),
            "context25_zip_sha256": digest(context25_zip),
            "source_review_registry_sha256": digest(registry_path),
            "existing_colorado_atlas_sha256": digest(atlas_path),
            "context25_has_colorado_source_rows": False,
            "existing_atlas_counties_joined": len(joins),
        },
        "current_repo_file_receipts": {
            str(path.relative_to(repo)): {"bytes": path.stat().st_size, "sha256": digest(path)}
            for path in [pointer_path, coverage_path, early_path, demographics_path, snapshot_path,
                         registry_path, context25_review, context25_zip, atlas_path]
        },
    }
    (output / "current-vs-official-comparison.json").write_text(
        json.dumps(comparison, indent=2) + "\n"
    )

    coverage_proposal = {
        "state_code": "CO",
        "state": "Colorado",
        "existing_snapshot_status": coverage,
        "append_only_official_source": {
            "status": "reported_official_returned_ballots",
            "measure": "returned_and_processed_ballots",
            "all_returned": new_all,
            "returned_mail": new_mail,
            "in_person": new_person,
            "source_period_end": "11:59 PM November 5, 2026",
            "source_timezone": None,
            "publication_date": "2026-11-06",
            "eligible_registered": new_denominator,
            "registered_fraction_pct": statewide["returned_per_eligible_registered_pct"],
            "county_rates": None,
            "demographic_rates": None,
        },
        "instruction": "Create a new pinned source version; do not mutate snapshot 20261104T220424Z or relabel its modes.",
    }
    (output / "proposed-source-coverage-row.json").write_text(
        json.dumps(coverage_proposal, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
