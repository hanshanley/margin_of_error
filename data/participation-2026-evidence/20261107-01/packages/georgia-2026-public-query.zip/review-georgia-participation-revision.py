import csv
import gzip
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path


def digest(body):
    return hashlib.sha256(body).hexdigest()


def rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def english(values):
    return next(
        (value["text"] for value in values if value.get("languageId") == "en"),
        values[0]["text"],
    )


def parse_voters(text):
    header = re.search(
        r"^Last Updated ([^\n]+)$.*?^Totals$\nVoters\n([\d,]+)\n"
        r"Ballots Cast\n([\d,]+)\nVoter Turnout\n([\d.]+)%$",
        text,
        re.MULTILINE | re.DOTALL,
    )
    assert header
    counties = {}
    for match in re.finditer(
        r"^(.+ County)\nVoters: ([\d,]+)\nBallots Cast: ([\d,]+)\n"
        r"Voter Turnout: ?([\d.]*%?)$",
        text,
        re.MULTILINE,
    ):
        county, voters, ballots, rate = match.groups()
        assert county not in counties
        counties[county] = {
            "voters": int(voters.replace(",", "")),
            "ballots": int(ballots.replace(",", "")),
            "turnout": rate,
        }
    assert len(counties) == 159
    return {
        "updated": header.group(1),
        "voters": int(header.group(2).replace(",", "")),
        "ballots": int(header.group(3).replace(",", "")),
        "turnout": header.group(4),
        "counties": counties,
    }


def verify(root=None, verify_archive=True):
    root = Path(root or Path(__file__).parent)
    api = json.loads((root / "originals/results-api.json").read_bytes())
    rendered = parse_voters((root / "originals/voters-page.txt").read_text())
    current = rows(root / "county-participation.csv")
    prior = rows(root / "references/20261106-county-participation.csv")
    statewide = rows(root / "statewide-participation.csv")
    deltas = rows(root / "county-deltas-from-20261106.csv")
    changed = rows(root / "changed-county-deltas-from-20261106.csv")
    statuses = rows(root / "native-reporting-statuses.csv")
    clocks = rows(root / "source-clocks.csv")
    denominators = rows(root / "denominator-qualifications.csv")
    audit = json.loads((root / "audit.json").read_text())
    context = json.loads((root / "identity-context-reference.json").read_text())
    source = json.loads(
        gzip.decompress((root / "source-records.json.gz").read_bytes())
    )

    assert len(current) == len(prior) == len(deltas) == 159
    assert len(changed) == 42
    assert len(statuses) == 636
    assert len(clocks) == 481
    assert len(denominators) == 160
    assert len({row["county"] for row in current}) == 159
    assert len({row["native_uuid"].lower() for row in current}) == 159
    assert [row["county"] for row in current] == [row["county"] for row in prior]

    children = {
        english(item["name"]): item
        for item in api["jurisdiction"]["childLocalities"]
    }
    registrations = {
        english(item["localityName"]): item for item in api["voterRegistration"]
    }
    names = {
        item["id"].lower(): english(item["name"])
        for item in api["jurisdiction"]["childLocalities"]
    }
    localities = {
        names[item["jurisdictionId"].lower()]: item
        for item in api["localityElections"]
    }
    assert (
        set(children)
        == set(registrations)
        == set(localities)
        == set(rendered["counties"])
        == {row["county"] for row in current}
    )

    prior_by_county = {row["county"]: row for row in prior}
    current_by_county = {row["county"]: row for row in current}
    delta_by_county = {row["county"]: row for row in deltas}
    incomplete = set()
    for county, row in current_by_county.items():
        child = children[county]
        registration = registrations[county]
        locality = localities[county]
        page = rendered["counties"][county]
        ballots = int(float(row["native_ballots_cast"]))
        voters = int(float(row["native_total_voters"]))
        assert row["year"] == "2026" and row["state_code"] == "GA"
        assert row["native_uuid"].lower() == child["id"].lower()
        assert row["source_fips"] == ""
        assert row["maps_approved"] == row["counting_complete"] == "False"
        assert ballots == int(locality["ballotsCast"]) == page["ballots"]
        assert voters == int(locality["totalVoters"]) == registration["total"] == page["voters"]
        assert int(row["native_registration_total"]) == voters
        assert row["native_is_official_results"] == (
            "True" if locality["isOfficialResults"] else "False"
        )
        if voters:
            assert row["usable_native_fraction"] == "True"
            assert row["native_printed_turnout"] == page["turnout"]
            assert abs(float(row["native_fraction"]) - ballots / voters) < 0.0000001
            assert abs(float(page["turnout"].rstrip("%")) - ballots / voters * 100) <= 0.005000001
        else:
            assert row["usable_native_fraction"] == "False"
            assert row["native_fraction"] == row["native_printed_turnout"] == ""
        prior_ballots = int(float(prior_by_county[county]["native_ballots_cast"]))
        delta = delta_by_county[county]
        assert int(delta["prior_ballots_cast"]) == prior_ballots
        assert int(delta["current_ballots_cast"]) == ballots
        assert int(delta["ballot_delta"]) == ballots - prior_ballots >= 0
        assert (delta["changed"] == "True") == (ballots != prior_ballots)
        native_statuses = {
            english(item["groupName"]): item["reportingStatusClientTextKey"]
            for item in locality["groupReportingStatus"]
        }
        source_statuses = {
            item["mode"]: item["native_status"]
            for item in statuses
            if item["county"] == county
        }
        assert source_statuses == native_statuses
        if any(
            value.endswith("partially-reported")
            or value.endswith("not-reported")
            for value in native_statuses.values()
        ):
            incomplete.add(county)

    assert sum(int(float(row["native_ballots_cast"])) for row in current) == 4_214_671
    assert sum(int(float(row["native_total_voters"])) for row in current) == 7_516_484
    assert sum(int(row["ballot_delta"]) for row in deltas) == 4_516
    assert sum(row["native_is_official_results"] == "True" for row in current) == 24
    assert incomplete == {
        "Columbia County",
        "Decatur County",
        "Fannin County",
        "Fulton County",
        "Gilmer County",
        "Gordon County",
        "Union County",
    }
    assert sorted(
        row["county"] for row in current if row["native_total_voters"] == "0.0"
    ) == ["Jeff Davis County", "Screven County"]

    assert len(statewide) == 1
    state = statewide[0]
    assert state["ballots"] == str(rendered["ballots"]) == "4214671"
    assert state["voters"] == str(rendered["voters"]) == "7516484"
    assert state["printed_turnout"] == rendered["turnout"] == "56.07"
    assert state["validated_rate"] == ""
    assert state["missing_county_registration_denominators"] == "2"
    assert state["incomplete_mode_counties"] == "7"
    assert state["official_counties"] == "24"
    assert state["original_conflicting_api_root_ballots"] == "0"
    assert state["statewide_is_official_results"] == "False"

    statewide_denominator = next(
        row for row in denominators if row["geography_level"] == "statewide"
    )
    assert statewide_denominator["reported_rate_approved"] == "False"
    assert statewide_denominator["denominator_usable"] == "False"
    assert "two counties" in statewide_denominator["qualification"]
    assert len(
        [
            row
            for row in denominators
            if row["geography_level"] == "county"
            and row["denominator_usable"] == "False"
        ]
    ) == 2
    assert audit["validated_statewide_rate"] is None
    assert sorted(audit["incomplete_mode_counties"]) == sorted(incomplete)
    assert audit["prior_package_rewritten"] is False
    assert context["frozen_context_id"] == "20261106-25"
    assert context["georgia_observations"] == 159
    assert context["geometry"]["features"] == 159
    assert (
        context["geometry"]["sha256"]
        == "6a51d15e3a8241c280ac3d95cbee1159fd03e724d667c6990a30dd22f2bbbb54"
    )
    assert source["review_id"] == "georgia-bulk-participation-20261107-02"
    assert len(source["county_participation"]) == 159

    manifest = json.loads((root / "checksums.json").read_text())
    for expected in manifest["files"]:
        path = root / expected["path"]
        body = path.read_bytes()
        assert len(body) == expected["bytes"]
        assert digest(body) == expected["sha256"]

    if verify_archive:
        archive_path = root / "complete-query.zip"
        with zipfile.ZipFile(archive_path) as archive:
            assert sorted(archive.namelist()) == sorted(
                [expected["path"] for expected in manifest["files"]]
                + ["checksums.json"]
            )
            for name in archive.namelist():
                assert archive.read(name) == (root / name).read_bytes()

    return {
        "county_rows": len(current),
        "changed_counties": len(changed),
        "ballots": 4_214_671,
        "delta": 4_516,
        "official_counties": 24,
        "incomplete_mode_counties": len(incomplete),
        "zero_denominator_counties": 2,
        "validated_statewide_rate": None,
    }


if __name__ == "__main__":
    package = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent
    print(json.dumps(verify(package), indent=2))
