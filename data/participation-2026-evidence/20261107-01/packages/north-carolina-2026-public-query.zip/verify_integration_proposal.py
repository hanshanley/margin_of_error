#!/usr/bin/env python3

import csv
import hashlib
import json
import sys
import zipfile
from pathlib import Path


PACKAGE = (
    Path(sys.argv[1]).resolve()
    if len(sys.argv) > 1
    else Path(__file__).resolve().parent / "integration-proposal-01"
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(name):
    with (PACKAGE / name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def main():
    checks = 0
    inventory = json.loads((PACKAGE / "checksums.json").read_text())
    for name, metadata in inventory.items():
        path = PACKAGE / name
        assert path.stat().st_size == metadata["bytes"]
        assert digest(path) == metadata["sha256"]
        checks += 2

    observations = json.loads((PACKAGE / "statewide-observations.json").read_text())
    assert len(observations) == 2
    assert observations[0]["ballots"] == 4_223_102
    assert observations[1]["ballots"] == 4_223_355
    assert observations[0]["denominator"] == observations[1]["denominator"] == 7_885_046
    assert observations[1]["source_update_label"] == "November 6, 2026 5:02 pm"
    checks += 5

    comparison = json.loads((PACKAGE / "new-vs-existing.json").read_text())
    assert comparison["status"] == "genuinely_newer_same_official_source_observation"
    assert comparison["ballot_delta"] == 253
    assert comparison["denominator_delta"] == 0
    assert comparison["count_changed_counties"] == [
        {"county": "HYDE", "ballot_delta": 216},
        {"county": "PAMLICO", "ballot_delta": 37},
    ]
    checks += 4

    reporting = read_csv("pipeline-reporting-row.csv")
    assert len(reporting) == 1
    assert list(reporting[0]) == [
        "state_code", "state", "source_date", "source_update_label",
        "source_retrieved_at", "status", "source_url", "source_snapshot",
        "quality", "reported_units", "total_units", "reporting_unit",
        "ballots", "denominator", "denominator_basis", "published_pct",
        "validated_pct",
    ]
    assert reporting[0]["ballots"] == "4223355"
    assert reporting[0]["denominator"] == "7885046"
    checks += 4

    counties = read_csv("pipeline-counties.csv")
    assert len(counties) == 100
    assert list(counties[0]) == [
        "year", "state_code", "county_id", "county", "ballots", "denominator",
        "denominator_basis", "reported_pct", "reported_units", "total_units",
        "source_update_label", "source_url", "county_source_url",
        "source_retrieved_at", "source_sha256", "county_source_sha256",
        "quality", "source_rows", "precinct_rows", "rows_reconcile",
        "ballot_difference", "denominator_difference",
    ]
    assert sum(int(row["ballots"]) for row in counties) == 4_223_355
    assert sum(int(row["denominator"]) for row in counties) == 7_885_046
    assert sum(int(row["reported_units"]) for row in counties) == 2_626
    assert sum(int(row["total_units"]) for row in counties) == 2_626
    checks += 6

    scope = json.loads((PACKAGE / "scope-and-inclusion.json").read_text())
    modes = scope["mode_accounting"]
    assert modes["accepted_absentee_and_early_total"] == 2_837_351
    assert sum(modes["accepted_absentee_and_early_modes"].values()) == 2_837_351
    assert modes["provisional_ballots_reported_cast"] == 36_788
    assert scope["history_disposition"]["data_rows"] == 0
    assert scope["privacy"] == {
        "person_records_in_package": False,
        "persistent_ids_in_package": False,
        "aggregate_only": True,
    }
    checks += 5

    with zipfile.ZipFile(PACKAGE / "originals/history_stats_20261103.zip") as archive:
        lines = archive.read("history_stats_20261103.txt").decode("utf-8-sig").splitlines()
    assert len(lines) == 1
    checks += 1

    with zipfile.ZipFile(PACKAGE / "complete-query.zip") as archive:
        names = set(archive.namelist())
        assert "checksums.json" in names
        assert "originals/enr-20261103-county-20261106T1702ET.txt" in names
        assert "scope-and-inclusion.json" in names
        assert "verify_integration_proposal.py" in names
        assert all(not name.endswith("complete-query.zip") for name in names)
    checks += 5

    text_outputs = "\n".join(
        path.read_text(errors="ignore")
        for path in PACKAGE.rglob("*")
        if path.is_file() and path.suffix in {".json", ".csv", ".md", ".txt", ".py"}
        and path.name not in {
            "layout_ncvhis.txt",
            "verify_integration_proposal.py",
            "build_integration_proposal.py",
        }
    )
    assert '"ncid":' not in text_outputs.lower()
    assert '"voter_reg_num":' not in text_outputs.lower()
    checks += 2
    print(json.dumps({"status": "passed", "checks": checks}))


if __name__ == "__main__":
    main()
