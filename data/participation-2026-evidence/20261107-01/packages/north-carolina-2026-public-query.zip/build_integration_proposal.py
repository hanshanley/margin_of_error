#!/usr/bin/env python3

import csv
import hashlib
import json
import os
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CAPTURE = ROOT / "source"
RECEIPTS = json.loads((ROOT / "source-receipts.json").read_text())
REPO = Path(os.environ["MARGIN_OF_ERROR_REPO"])
EXISTING_DIR = REPO / "public/participation-current/20261104T220424Z"
EXISTING_ARCHIVE = EXISTING_DIR / "complete-snapshot.zip"
EXISTING_MEMBER = "sources/20261104T220425Z/NC-official.json"
OUTPUT = ROOT / "integration-proposal-01"
SOURCE_URL = "https://er.ncsbe.gov/enr/20261103/data/county.txt"


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def digest_path(path):
    return digest_bytes(path.read_bytes())


def integer(value):
    text = str(value).strip()
    if not text.isdigit():
        raise ValueError(f"Invalid source integer: {value!r}")
    return int(text)


def pct(ballots, denominator):
    return 100 * ballots / denominator


def validate_rows(rows):
    if len(rows) != 101:
        raise ValueError("Expected statewide row plus all 100 counties")
    by_id = {}
    for row in rows:
        county_id = row["cid"]
        if county_id in by_id:
            raise ValueError("Duplicate county identity")
        by_id[county_id] = row
        for field in ("prt", "ptl", "bct", "rtl"):
            integer(row[field])
        if integer(row["prt"]) > integer(row["ptl"]):
            raise ValueError("Reported precincts exceed total precincts")
        if integer(row["bct"]) > integer(row["rtl"]):
            raise ValueError("Ballots exceed source registration denominator")
        if abs(float(row["bpt"].rstrip("%")) - pct(integer(row["bct"]), integer(row["rtl"]))) > 0.01:
            raise ValueError("Printed turnout percentage does not reconcile")
    if set(by_id) != {str(index) for index in range(101)}:
        raise ValueError("Expected source county identities 0 through 100")
    state = by_id["0"]
    counties = [by_id[str(index)] for index in range(1, 101)]
    if state["cnm"] != "STATE" or state["tle"] != (
        "11/03/2026 UNOFFICIAL GENERAL ELECTION RESULTS - STATEWIDE"
    ):
        raise ValueError("Wrong election or statewide identity")
    if sum(integer(row["bct"]) for row in counties) != integer(state["bct"]):
        raise ValueError("County ballots do not sum to statewide ballots")
    if sum(integer(row["rtl"]) for row in counties) != integer(state["rtl"]):
        raise ValueError("County registrations do not sum to statewide registrations")
    if sum(integer(row["prt"]) for row in counties) != integer(state["prt"]):
        raise ValueError("County reported precincts do not sum statewide")
    if sum(integer(row["ptl"]) for row in counties) != integer(state["ptl"]):
        raise ValueError("County precinct totals do not sum statewide")
    return by_id


def observation(row, source_sha256, retrieved_at, snapshot, selected):
    ballots = integer(row["bct"])
    denominator = integer(row["rtl"])
    return {
        "observation_id": snapshot,
        "state_code": "NC",
        "state": "North Carolina",
        "election_date": "2026-11-03",
        "status": "reported",
        "certification_status": "unofficial",
        "numerator_field": "bct",
        "numerator_measure": "source-reported ballots cast across reported election-result modes",
        "ballots": ballots,
        "denominator_field": "rtl",
        "denominator": denominator,
        "denominator_basis": "active_and_inactive_registered_voters",
        "published_pct": float(row["bpt"].rstrip("%")),
        "validated_pct": round(pct(ballots, denominator), 6),
        "reported_units": integer(row["prt"]),
        "total_units": integer(row["ptl"]),
        "reporting_unit": "precincts",
        "source_upload_label": row["imp"],
        "source_update_label": row["sub"],
        "source_url": SOURCE_URL,
        "source_retrieved_at": retrieved_at,
        "source_sha256": source_sha256,
        "source_snapshot": snapshot,
        "selected_current_proposal": selected,
        "quality": [
            "Unofficial; complete precinct reporting does not establish completed canvass, certification, or disposition of every provisional, cure, or timely overseas ballot."
        ],
    }


def write_rows(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def inventory(directory):
    return {
        path.relative_to(directory).as_posix(): {
            "bytes": path.stat().st_size,
            "sha256": digest_path(path),
        }
        for path in sorted(directory.rglob("*"))
        if path.is_file() and path.name not in {"checksums.json", "complete-query.zip"}
    }


def main():
    if OUTPUT.exists():
        raise FileExistsError(f"Append-only output already exists: {OUTPUT}")
    OUTPUT.mkdir(mode=0o700)
    originals = OUTPUT / "originals"
    originals.mkdir()

    with zipfile.ZipFile(EXISTING_ARCHIVE) as archive:
        old_raw = archive.read(EXISTING_MEMBER)
    new_raw = (CAPTURE / "enr-20261103-county.txt").read_bytes()
    old_rows = json.loads(old_raw)
    new_rows = json.loads(new_raw)
    old = validate_rows(old_rows)
    new = validate_rows(new_rows)

    old_name = "existing-NC-official-20261104.json"
    new_name = "enr-20261103-county-20261106T1702ET.txt"
    (originals / old_name).write_bytes(old_raw)
    (originals / new_name).write_bytes(new_raw)
    copied = [
        "history_stats_20261103.zip",
        "voter_stats_20261103.zip",
        "absentee_counts_state_20261103.csv",
        "absentee_spoiled_outstanding_20261103.zip",
        "2026-11-07-daily-absentee-stats-report.pdf",
        "2026-november-provisionals-cast-by-voting-method.pdf",
        "layout_history_stats.txt",
        "layout_voter_stats.txt",
        "layout_ncvhis.txt",
        "layout_absentee_counts_state.txt",
    ]
    for name in copied:
        shutil.copyfile(CAPTURE / name, originals / name)
    shutil.copyfile(
        ROOT / "extracted/2026-11-07-daily-absentee-stats-report.txt",
        originals / "2026-11-07-daily-absentee-stats-report.txt",
    )
    shutil.copyfile(
        ROOT / "extracted/2026-november-provisionals-cast-by-voting-method.txt",
        originals / "2026-november-provisionals-cast-by-voting-method.txt",
    )

    existing_snapshot = json.loads((EXISTING_DIR / "snapshot.json").read_text())
    old_source = next(
        source for source in existing_snapshot["sources"]
        if source.get("file") == "NC-official.json"
    )
    capture_receipt = RECEIPTS["sources"]["enr_county_20261103"]
    observations = [
        observation(
            old["0"],
            digest_bytes(old_raw),
            old_source["retrieved_at"],
            old_source["snapshot_id"],
            False,
        ),
        observation(
            new["0"],
            digest_bytes(new_raw),
            RECEIPTS["captured_at"],
            "nc-2026-linked-history-01",
            True,
        ),
    ]
    (OUTPUT / "statewide-observations.json").write_text(
        json.dumps(observations, indent=2) + "\n"
    )
    write_rows(OUTPUT / "statewide-observations.csv", observations)

    warning = observations[-1]["quality"]
    county_rows = []
    for county_id in range(1, 101):
        row = new[str(county_id)]
        ballots = integer(row["bct"])
        denominator = integer(row["rtl"])
        county_rows.append({
            "year": 2026,
            "state_code": "NC",
            "county_id": row["cid"],
            "county": row["cnm"],
            "ballots": ballots,
            "denominator": denominator,
            "denominator_basis": "active_and_inactive_registered_voters",
            "reported_pct": pct(ballots, denominator),
            "reported_units": integer(row["prt"]),
            "total_units": integer(row["ptl"]),
            "source_update_label": row["sub"],
            "source_url": SOURCE_URL,
            "county_source_url": "",
            "source_retrieved_at": RECEIPTS["captured_at"],
            "source_sha256": digest_bytes(new_raw),
            "county_source_sha256": "",
            "quality": json.dumps(warning),
            "source_rows": 0,
            "precinct_rows": 0,
            "rows_reconcile": "",
            "ballot_difference": "",
            "denominator_difference": "",
        })
    write_rows(OUTPUT / "pipeline-counties.csv", county_rows)
    (OUTPUT / "pipeline-counties.json").write_text(
        json.dumps(county_rows, indent=2) + "\n"
    )

    pipeline_row = {
        "state_code": "NC",
        "state": "North Carolina",
        "source_date": "",
        "source_update_label": new["0"]["sub"],
        "source_retrieved_at": RECEIPTS["captured_at"],
        "status": "reported",
        "source_url": SOURCE_URL,
        "source_snapshot": "nc-2026-linked-history-01",
        "quality": json.dumps(warning),
        "reported_units": integer(new["0"]["prt"]),
        "total_units": integer(new["0"]["ptl"]),
        "reporting_unit": "precincts",
        "ballots": integer(new["0"]["bct"]),
        "denominator": integer(new["0"]["rtl"]),
        "denominator_basis": "active_and_inactive_registered_voters",
        "published_pct": float(new["0"]["bpt"].rstrip("%")),
        "validated_pct": round(pct(integer(new["0"]["bct"]), integer(new["0"]["rtl"])), 3),
    }
    write_rows(OUTPUT / "pipeline-reporting-row.csv", [pipeline_row])
    (OUTPUT / "pipeline-reporting-row.json").write_text(
        json.dumps(pipeline_row, indent=2) + "\n"
    )

    changes = []
    for county_id in range(101):
        prior = old[str(county_id)]
        current = new[str(county_id)]
        ballot_delta = integer(current["bct"]) - integer(prior["bct"])
        denominator_delta = integer(current["rtl"]) - integer(prior["rtl"])
        if ballot_delta or denominator_delta or prior["imp"] != current["imp"] or prior["sub"] != current["sub"]:
            changes.append({
                "county_id": current["cid"],
                "county": current["cnm"],
                "prior_ballots": integer(prior["bct"]),
                "current_ballots": integer(current["bct"]),
                "ballot_delta": ballot_delta,
                "prior_denominator": integer(prior["rtl"]),
                "current_denominator": integer(current["rtl"]),
                "denominator_delta": denominator_delta,
                "prior_source_update_label": prior["sub"],
                "current_source_update_label": current["sub"],
                "count_changed": bool(ballot_delta or denominator_delta),
            })
    write_rows(OUTPUT / "source-row-changes.csv", changes)
    (OUTPUT / "source-row-changes.json").write_text(
        json.dumps(changes, indent=2) + "\n"
    )

    absentee = json.loads((ROOT / "aggregate-results.json").read_text())
    history = absentee["current_2026_general_history_release"]
    comparison = {
        "status": "genuinely_newer_same_official_source_observation",
        "existing_repo_pointer": str(EXISTING_DIR / "snapshot.json"),
        "existing_source_archive": str(EXISTING_ARCHIVE),
        "existing_source_member": EXISTING_MEMBER,
        "existing_source_sha256": digest_bytes(old_raw),
        "captured_source_sha256": digest_bytes(new_raw),
        "same_source_url": True,
        "same_election_identity": old["0"]["tle"] == new["0"]["tle"],
        "existing_source_update_label": old["0"]["sub"],
        "captured_source_update_label": new["0"]["sub"],
        "existing_ballots_cast": integer(old["0"]["bct"]),
        "captured_ballots_cast": integer(new["0"]["bct"]),
        "ballot_delta": integer(new["0"]["bct"]) - integer(old["0"]["bct"]),
        "existing_denominator": integer(old["0"]["rtl"]),
        "captured_denominator": integer(new["0"]["rtl"]),
        "denominator_delta": integer(new["0"]["rtl"]) - integer(old["0"]["rtl"]),
        "count_changed_counties": [
            {"county": row["county"], "ballot_delta": row["ballot_delta"]}
            for row in changes if row["county_id"] != "0" and row["count_changed"]
        ],
        "clock_only_changed_counties": [
            row["county"] for row in changes
            if row["county_id"] != "0" and not row["count_changed"]
        ],
        "selection": "captured observation is newer; preserve existing observation and append this one",
    }
    (OUTPUT / "new-vs-existing.json").write_text(
        json.dumps(comparison, indent=2) + "\n"
    )

    scope = {
        "selected_observation": {
            "ballots_cast": integer(new["0"]["bct"]),
            "registration_denominator": integer(new["0"]["rtl"]),
            "published_turnout_pct": float(new["0"]["bpt"].rstrip("%")),
            "validated_turnout_pct": pct(integer(new["0"]["bct"]), integer(new["0"]["rtl"])),
            "source_clock": {
                "last_county_upload": new["0"]["imp"],
                "last_county_submit": new["0"]["sub"],
                "http_last_modified": capture_receipt["remote_headers"]["last_modified"],
            },
            "unit": (
                "NCSBE Election Night Reporting field bct: source-reported Ballots Cast. "
                "Use as reported ballots, not candidate selections or a linked voter-history count."
            ),
            "denominator": (
                "NCSBE Election Night Reporting field rtl, preserved under the existing pipeline "
                "label active_and_inactive_registered_voters. It is the same-report operational "
                "denominator and must not be replaced by differently dated voter-stats totals."
            ),
        },
        "mode_accounting": {
            "accepted_absentee_and_early_total": absentee[
                "2026_absentee_early_observation"
            ]["aggregate_csv"]["total"],
            "accepted_absentee_and_early_modes": absentee[
                "2026_absentee_early_observation"
            ]["aggregate_csv"]["request_type_totals"],
            "provisional_ballots_reported_cast": absentee[
                "2026_provisional_status"
            ]["total_cast"],
            "rules": [
                "The 2,837,351 accepted absentee/early total is a component of the all-mode ENR Ballots Cast observation, not an additional count.",
                "Military and overseas accepted mail are already included in the accepted absentee/early total and must not be added again.",
                "The 36,788 provisional ballots reported cast are a processing workload, not an accepted/countable total, and must not be added to ENR.",
                "Because the aggregate sources have different clocks and no full common mode decomposition, the ENR-minus-absentee residual must not be labeled Election Day turnout.",
                "Complete precinct reporting does not establish completed provisional, cure, or timely overseas counting.",
            ],
        },
        "history_disposition": {
            "source": "history_stats_20261103.zip",
            "data_rows": history["data_rows"],
            "header": history["header"],
            "status": "header_only_no_2026_general_history_credits",
            "integration_rule": (
                "Keep as an explicit unavailable-history disposition. Never encode the absent "
                "rows as zero participation, nonvoting, prior-only, or first-ever status."
            ),
        },
        "privacy": {
            "person_records_in_package": False,
            "persistent_ids_in_package": False,
            "aggregate_only": True,
        },
    }
    (OUTPUT / "scope-and-inclusion.json").write_text(
        json.dumps(scope, indent=2) + "\n"
    )

    provenance = {
        "existing": {
            "repo_snapshot": str(EXISTING_DIR / "snapshot.json"),
            "repo_snapshot_sha256": digest_path(EXISTING_DIR / "snapshot.json"),
            "complete_snapshot_zip": str(EXISTING_ARCHIVE),
            "complete_snapshot_zip_sha256": digest_path(EXISTING_ARCHIVE),
            "member": EXISTING_MEMBER,
            "member_bytes": len(old_raw),
            "member_sha256": digest_bytes(old_raw),
            "source_receipt": old_source,
        },
        "captured": {
            name: RECEIPTS["sources"][name]
            for name in [
                "enr_county_20261103",
                "history_stats_20261103",
                "voter_stats_20261103",
                "absentee_counts_state_20261103",
                "outstanding_absentee_20261103",
                "daily_absentee_report_20261107",
                "provisional_by_method",
            ]
        },
    }
    (OUTPUT / "source-provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n"
    )

    audit = {
        "status": "append_only_newer_nc_statewide_observation_qualified_unofficial",
        "checks": 24,
        "source_rows": 101,
        "county_rows": 100,
        "county_ballot_sum_matches_state": sum(integer(new[str(i)]["bct"]) for i in range(1, 101))
        == integer(new["0"]["bct"]),
        "county_denominator_sum_matches_state": sum(integer(new[str(i)]["rtl"]) for i in range(1, 101))
        == integer(new["0"]["rtl"]),
        "county_precincts_sum_matches_state": sum(integer(new[str(i)]["ptl"]) for i in range(1, 101))
        == integer(new["0"]["ptl"]),
        "new_vs_existing": comparison,
        "history_header_only": history["data_rows"] == 0,
        "raw_person_records_used": False,
        "candidate_votes_used_as_participation": False,
        "mode_counts_added_to_enr": False,
        "public_release_qualified": True,
        "certified_or_final": False,
    }
    (OUTPUT / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")

    registry = {
        "id": "north-carolina-statewide-participation-20261107-01",
        "label": "North Carolina 2026: newer statewide reported ballots and history-release disposition",
        "data_directory": "data/participation-source-reviews/20261107-north-carolina-statewide-01",
        "review_status": "complete_aggregate_query_reviewed_unofficial",
        "maps_approved": False,
        "scope_note": (
            "Append-only newer NCSBE ENR observation: 4,223,355 source-reported Ballots Cast / "
            "7,885,046 same-report active-and-inactive registered-voter denominator, printed 53.56%, "
            "last county submit November 6, 2026 5:02 pm. This is 253 ballots above the preserved "
            "November 4 observation, entirely Hyde +216 and Pamlico +37; denominator unchanged. "
            "Accepted absentee/early 2,837,351, including military/overseas mail, is already a component "
            "and is not added. Provisional 36,788 cast is not an accepted/countable total and is not added. "
            "The 2026 history-stats ZIP is header-only with zero rows; missing history is unknown, not nonvoting. "
            "Unofficial, not certified or proven complete for provisional/cure/timely-overseas disposition."
        ),
        "tables": [
            {"file": "statewide-observations.csv", "label": "Preserved prior and newer statewide observations"},
            {"file": "pipeline-reporting-row.csv", "label": "Newer row normalized to statewide participation schema"},
            {"file": "pipeline-counties.csv", "label": "All 100 newer county aggregate rows"},
            {"file": "new-vs-existing.json", "label": "Exact source, count, denominator and clock comparison"},
            {"file": "scope-and-inclusion.json", "label": "Numerator, denominator, mode and history disposition"},
            {"file": "source-provenance.json", "label": "Original receipts, hashes and preserved prior pointer"},
            {"file": "audit.json", "label": "Aggregate reconciliation and qualification"},
            {"file": "checksums.json", "label": "Complete package byte inventory"},
        ],
    }
    (OUTPUT / "registry-entry.json").write_text(json.dumps(registry, indent=2) + "\n")

    proposal = {
        "shared_repo_edits_performed": False,
        "recommended_append_only_addition": (
            "data/participation-source-reviews/20261107-north-carolina-statewide-01"
        ),
        "registry_target": "public/participation-source-reviews.json",
        "current_snapshot_rule": (
            "Do not mutate public/participation-current/20261104T220424Z. "
            "Use pipeline-reporting-row.csv and pipeline-counties.csv only in a new immutable "
            "participation-current snapshot created by the existing collector/integrator."
        ),
        "no_new_version_if_identical_rule": (
            "The observation is not identical: it is 253 ballots newer with a November 6 clock. "
            "If a parent snapshot already contains source SHA256 "
            f"{digest_bytes(new_raw)}, do not create another version."
        ),
        "package_copy_rule": (
            "Copy the complete package directory after verification; do not cherry-pick "
            "only the normalized row and omit its scope/provenance/history disposition."
        ),
        "required_integration_files": [
            "pipeline-reporting-row.csv",
            "pipeline-counties.csv",
            "statewide-observations.json",
            "new-vs-existing.json",
            "scope-and-inclusion.json",
            "source-provenance.json",
            "audit.json",
            "checksums.json",
            "registry-entry.json",
            "verify_integration_proposal.py",
            "originals/",
        ],
    }
    (OUTPUT / "integration-proposal.json").write_text(
        json.dumps(proposal, indent=2) + "\n"
    )
    (OUTPUT / "proposed-patch.txt").write_text(
        "APPEND-ONLY PROPOSAL; NO SHARED REPOSITORY EDITS WERE MADE\n\n"
        "1. Add this reviewed package at:\n"
        "   data/participation-source-reviews/20261107-north-carolina-statewide-01/\n"
        "2. Append registry-entry.json to public/participation-source-reviews.json.\n"
        "3. Preserve public/participation-current/20261104T220424Z unchanged.\n"
        "4. In the next new immutable participation-current snapshot, select\n"
        "   pipeline-reporting-row.csv and pipeline-counties.csv through the existing\n"
        "   collector/integrator. Do not copy them into the old snapshot.\n"
        "5. If the parent already has source SHA256 "
        + digest_bytes(new_raw)
        + ", make no new version.\n"
        "6. Keep scope-and-inclusion.json beside the selected observation so accepted\n"
        "   absentee/early and provisional counts cannot be added to ENR Ballots Cast,\n"
        "   and the header-only history release cannot be interpreted as nonvoting.\n"
    )
    (OUTPUT / "README.md").write_text(
        "# North Carolina 2026 append-only participation proposal\n\n"
        "This complete aggregate-only query qualifies a newer observation from the same\n"
        "official source already used by the statewide pipeline. It preserves the prior\n"
        "November 4 observation and proposes 4,223,355 Ballots Cast / 7,885,046 under\n"
        "the existing active-and-inactive registered-voter denominator label, source\n"
        "clock November 6, 2026 5:02 p.m. The increase is 253: Hyde +216 and Pamlico\n"
        "+37. No other county count or denominator changed.\n\n"
        "The accepted absentee/early count and provisional workload are components or\n"
        "separate processing measures, not additions to the ENR total. The 2026 history\n"
        "file is header-only and remains an explicit unavailable-history disposition.\n"
        "Run `python3 verify_integration_proposal.py .` from this directory to verify\n"
        "all hashes, schemas, sums, mode rules, privacy assertions, and archive members.\n"
    )

    shutil.copyfile(Path(__file__), OUTPUT / "build_integration_proposal.py")
    shutil.copyfile(
        ROOT / "verify_integration_proposal.py",
        OUTPUT / "verify_integration_proposal.py",
    )
    checksums = inventory(OUTPUT)
    (OUTPUT / "checksums.json").write_text(json.dumps(checksums, indent=2) + "\n")
    archive_path = OUTPUT / "complete-query.zip"
    with zipfile.ZipFile(archive_path, "x", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUTPUT.rglob("*")):
            if not path.is_file() or path == archive_path:
                continue
            info = zipfile.ZipInfo(path.relative_to(OUTPUT).as_posix())
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    print(json.dumps({
        "output": str(OUTPUT),
        "ballots": integer(new["0"]["bct"]),
        "denominator": integer(new["0"]["rtl"]),
        "delta": comparison["ballot_delta"],
        "archive_bytes": archive_path.stat().st_size,
        "archive_sha256": digest_path(archive_path),
    }, indent=2))


if __name__ == "__main__":
    main()
