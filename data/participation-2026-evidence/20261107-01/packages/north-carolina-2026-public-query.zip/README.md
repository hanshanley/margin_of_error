# North Carolina 2026 append-only participation proposal

This complete aggregate-only query qualifies a newer observation from the same
official source already used by the statewide pipeline. It preserves the prior
November 4 observation and proposes 4,223,355 Ballots Cast / 7,885,046 under
the existing active-and-inactive registered-voter denominator label, source
clock November 6, 2026 5:02 p.m. The increase is 253: Hyde +216 and Pamlico
+37. No other county count or denominator changed.

The accepted absentee/early count and provisional workload are components or
separate processing measures, not additions to the ENR total. The 2026 history
file is header-only and remains an explicit unavailable-history disposition.
Run `python3 verify_integration_proposal.py .` from this directory to verify
all hashes, schemas, sums, mode rules, privacy assertions, and archive members.
