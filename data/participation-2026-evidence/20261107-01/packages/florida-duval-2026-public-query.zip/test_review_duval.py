#!/usr/bin/env python3
import csv
import hashlib
import json
import subprocess
import sys
import zipfile
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(ROOT / "review-duval.py")], check=True, capture_output=True, text=True)

row = next(csv.DictReader((ROOT / "county-participation.csv").open(encoding="utf-8")))
assert row["native_county"] == "Duval"
assert row["native_county_code"] == "DUV"
assert row["election_date"] == "2026-11-03"
assert int(row["reported_participants"]) == 361032
assert int(row["registered_voters"]) == 655219
assert row["native_denominator_label"] == "Registered Voters"
assert row["native_turnout_percentage"] == "55.1%"
assert row["native_source_update_literal"] == "11/07/2026 11:48:36 am"
assert row["source_timezone"] == ""
assert row["native_provisional_scope"] == "Includes VBM cures and provisionals"
assert row["native_10_day_overseas_scope"] == "Partially includes 10 day overseas ballots"

fraction = Decimal(361032) * Decimal(100) / Decimal(655219)
assert fraction.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP) == Decimal("55.1")

comparison = json.loads((ROOT / "comparison-to-existing.json").read_text())
assert comparison["genuinely_changed_observation"] is True
assert comparison["deltas"]["ballots"] == 192
assert comparison["deltas"]["denominator"] == 7
assert comparison["prior"]["source_update"] is None

qualification = json.loads((ROOT / "source-qualification.json").read_text())
assert qualification["denominator"]["not_derived_from_rounded_rate"] is True
assert qualification["reporting"]["provisionals"] == "included; completion not separately declared"
assert qualification["reporting"]["ten_day_overseas"] == "partially included"
assert qualification["privacy"]["person_rows"] == 0

manifest = json.loads((ROOT / "checksums.json").read_text())
for expected in manifest["files"]:
    body = (ROOT / expected["path"]).read_bytes()
    assert len(body) == expected["bytes"]
    assert hashlib.sha256(body).hexdigest() == expected["sha256"]

package = json.loads((ROOT / "package.json").read_text())
zip_body = (ROOT / "complete-query.zip").read_bytes()
assert len(zip_body) == package["complete_query_bytes"]
assert hashlib.sha256(zip_body).hexdigest() == package["complete_query_sha256"]
with zipfile.ZipFile(ROOT / "complete-query.zip") as archive:
    assert len(archive.namelist()) == package["zip_members"]
    assert archive.testzip() is None

print("PASS 24 Duval source-review checks")
