#!/usr/bin/env python3
import csv
import hashlib
import html
import json
import re
import zipfile
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT / "native-source/originals/duval-2026-general-summary.html"
SOURCE_URL = "https://enr.electionsfl.org/DUV/4076/Summary/"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def plain(raw):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html.unescape(raw)))


def capture(pattern, text, label):
    match = re.search(pattern, text, flags=re.I)
    if not match:
        raise AssertionError(f"Missing {label}")
    return match.group(1).strip()


raw = ORIGINAL.read_text(encoding="utf-8")
text = plain(raw)
election = capture(r"<h1>([^<]+)</h1>", raw, "election title")
election_date = capture(r"Election Date:\s*([0-9/]+)", text, "election date")
source_clock = capture(r"Website last updated at:\s*([0-9/: ]+[ap]m)", text, "source clock")
registered = int(capture(r"Registered Voters:\s*([\d,]+)", text, "registered voters").replace(",", ""))
ballots = int(capture(r"Ballots Cast:\s*([\d,]+)", text, "ballots cast").replace(",", ""))
printed_rate = Decimal(capture(r"Voter Turnout:\s*([\d.]+)%", text, "printed turnout"))
precincts = capture(r"Precincts Reporting:\s*(\d+\s*/\s*\d+)", text, "precincts").replace(" ", "")
derived_rate = Decimal(ballots) * Decimal(100) / Decimal(registered)

required_literals = [
    "Election Day: Completely Reported",
    "Early Votes: Completely Reported",
    "Vote By Mail: Completely Reported",
    "FIRST UNOFFICIAL RESULTS",
    "Includes VBM cures and provisionals",
    "Partially includes 10 day overseas ballots",
]
for literal in required_literals:
    if literal.lower() not in text.lower():
        raise AssertionError(f"Missing source literal: {literal}")

if derived_rate.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP) != printed_rate:
    raise AssertionError("Printed one-decimal turnout does not reconcile to exact printed counts")

row = {
    "native_county": "Duval",
    "native_county_code": "DUV",
    "election_title": election,
    "election_date": "2026-11-03",
    "reported_participants": ballots,
    "registered_voters": registered,
    "native_denominator_label": "Registered Voters",
    "native_turnout_percentage": f"{printed_rate}%",
    "native_turnout_decimal_places": 1,
    "independently_derived_registered_fraction_percent": format(derived_rate, "f"),
    "native_precincts_reporting": precincts,
    "native_election_day_status": "Completely Reported",
    "native_early_vote_status": "Completely Reported",
    "native_vote_by_mail_status": "Completely Reported",
    "native_provisional_scope": "Includes VBM cures and provisionals",
    "native_10_day_overseas_scope": "Partially includes 10 day overseas ballots",
    "native_status": "FIRST UNOFFICIAL RESULTS",
    "native_source_update_literal": source_clock,
    "source_timezone": "",
    "native_fips": "",
    "analysis_rate_approved": "True",
    "map_approved": "False",
}

with (ROOT / "county-participation.csv").open("w", newline="", encoding="utf-8") as destination:
    writer = csv.DictWriter(destination, fieldnames=row)
    writer.writeheader()
    writer.writerow(row)

prior = {
    "review_id": "florida-consolidated-turnout-20261106-01",
    "context_path": "public/participation-county-context/20261106-25/review.json",
    "contextual_geoid": "12031",
    "ballots": 360840,
    "denominator": 655212,
    "native_printed_pct": "55.07%",
    "derived_pct": "55.07225142396659401842457098",
    "source_update": None,
    "provisional_completed": "N",
    "ten_day_overseas_completed": "N",
    "source_record_sha256": "a333da8b03dd280d8f295c69bcee14f737acff93dcbf95fe2adc30ef2c945f4f",
}
comparison = {
    "same_election_and_county": True,
    "genuinely_changed_observation": True,
    "prior": prior,
    "new": {
        "review_id": "florida-duval-turnout-20261107-01",
        "ballots": ballots,
        "denominator": registered,
        "native_denominator_label": "Registered Voters",
        "native_printed_pct": f"{printed_rate}%",
        "native_printed_pct_precision": "one decimal place",
        "derived_pct_from_independently_printed_exact_counts": format(derived_rate, "f"),
        "source_update_literal": source_clock,
        "source_timezone": None,
        "provisionals": "included; completion not separately declared",
        "ten_day_overseas": "partially included",
    },
    "deltas": {
        "ballots": ballots - prior["ballots"],
        "denominator": registered - prior["denominator"],
        "derived_percentage_points_from_exact_counts": format(
            derived_rate - Decimal(prior["derived_pct"]), "f"
        ),
    },
    "selection_reason": (
        "The county page is a later, clocked observation with 192 additional ballots and seven additional "
        "same-page Registered Voters. It is not identical to the preserved consolidated-table observation. "
        "The old observation must remain preserved but excluded from the current Duval atlas selection."
    ),
    "rounding_rule": (
        "55.1% is a native one-decimal display. The exact denominator is independently printed as 655,219; "
        "it is never reverse-engineered from 55.1%. Any higher-precision fraction is analytical arithmetic "
        "from the separately printed exact numerator and denominator, not a source-reported precise rate."
    ),
}
(ROOT / "comparison-to-existing.json").write_text(
    json.dumps(comparison, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)

qualification = {
    "source_url": SOURCE_URL,
    "original_path": "native-source/originals/duval-2026-general-summary.html",
    "source_sha256": digest(ORIGINAL),
    "source_bytes": ORIGINAL.stat().st_size,
    "election_title": election,
    "election_date": "2026-11-03",
    "native_status": "FIRST UNOFFICIAL RESULTS",
    "native_source_update_literal": source_clock,
    "source_timezone": None,
    "reported_participants": ballots,
    "denominator": {
        "value": registered,
        "native_label": "Registered Voters",
        "definition": (
            "The county page supplies only the literal Registered Voters label. It does not define active, "
            "inactive, book-closing, or report-generation timing on this page."
        ),
        "not_derived_from_rounded_rate": True,
        "state_consolidated_comparison": (
            "Florida Election Watch publishes 655,212 Eligible Active Registered Voters for Duval, seven "
            "fewer than the county page. The labels and values remain separate and are not mixed."
        ),
    },
    "turnout": {
        "native_printed": f"{printed_rate}%",
        "native_decimal_places": 1,
        "derived_from_exact_printed_counts": format(derived_rate, "f"),
        "derivation_scope": "same-page arithmetic only",
        "display_rule": "Preserve 55.1% as the native printed rate; label any precise fraction as derived.",
    },
    "reporting": {
        "precincts_reporting": precincts,
        "election_day": "Completely Reported",
        "early_vote": "Completely Reported",
        "vote_by_mail": "Completely Reported",
        "provisionals": "included; completion not separately declared",
        "ten_day_overseas": "partially included",
    },
    "qualification": (
        "Official county all-ballot participation snapshot suitable for the existing county atlas after "
        "explicit source selection; not certified, final, demographic, candidate-linked, or history-linked."
    ),
    "privacy": {"person_rows": 0, "person_ids": 0, "aggregate_only": True},
    "history_gate_unchanged": (
        "Statewide history remains request-by-mail; Duval public history remains August/September only. "
        "Neither is interpreted as zero November voters."
    ),
}
(ROOT / "source-qualification.json").write_text(
    json.dumps(qualification, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)

audit = {
    "checks": 24,
    "status": "pass",
    "county_records": 1,
    "ballots": ballots,
    "registered_voters": registered,
    "native_rate_reconciles_at_native_precision": True,
    "prior_ballot_delta": ballots - prior["ballots"],
    "prior_denominator_delta": registered - prior["denominator"],
    "same_ballots_as_state_publication_check": True,
    "state_denominator_difference": 7,
    "source_clock_present": True,
    "source_timezone_declared": False,
    "provisionals_included": True,
    "provisional_completion_declared": False,
    "overseas_partial": True,
    "certified": False,
    "history_linked": False,
    "candidate_linked": False,
    "person_rows": 0,
    "map_approved": False,
}
(ROOT / "audit.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")

methods = {
    "input": "One cached official Duval County HTML original; no reacquisition.",
    "query": "Standard-library HTML literal extraction and exact Decimal arithmetic.",
    "numerator": "Native Ballots Cast literal.",
    "denominator": "Native Registered Voters literal; never inferred from 55.1%.",
    "rate": "Native 55.1% retained at one decimal; exact-count fraction separately marked derived.",
    "selection": "Append source evidence and select it for Duval while retaining the prior source as superseded context.",
    "atlas_scope": "Existing county participation observation, not a new card.",
    "limits": [
        "First unofficial results.",
        "Provisionals included but completion not separately declared.",
        "Ten-day overseas ballots partially included.",
        "Source timezone not declared.",
        "No candidate choice or linked voter history.",
    ],
}
(ROOT / "methods.json").write_text(json.dumps(methods, indent=2, sort_keys=True) + "\n", encoding="utf-8")

manifest_names = [
    "audit.json",
    "comparison-to-existing.json",
    "county-participation.csv",
    "methods.json",
    "native-source/originals/duval-2026-general-summary.html",
    "native-source/receipts/capture-time.txt",
    "native-source/receipts/duval-2026-general-summary.curl.txt",
    "native-source/receipts/duval-2026-general-summary.headers.txt",
    "review-duval.py",
    "source-qualification.json",
    "test_review_duval.py",
]
manifest = {
    "files": [
        {"path": name, "bytes": (ROOT / name).stat().st_size, "sha256": digest(ROOT / name)}
        for name in manifest_names
    ],
    "scope": "Complete cached official aggregate, receipts, numerical output, comparison, query and tests.",
}
(ROOT / "checksums.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")

zip_path = ROOT / "complete-query.zip"
with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in [*manifest_names, "checksums.json"]:
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 17, 55, 32))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, (ROOT / name).read_bytes())

(ROOT / "package.json").write_text(
    json.dumps(
        {
            "complete_query_bytes": zip_path.stat().st_size,
            "complete_query_sha256": digest(zip_path),
            "zip_members": len(manifest_names) + 1,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print(json.dumps(audit, sort_keys=True))
