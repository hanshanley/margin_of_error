﻿enrApp.controller('RaceController', function ($scope, $rootScope, $http) {
    $('#subTabsBar').hide();
    $scope.performSearch = function () {
        //added to minimise state wide tabs.
        $('strong[id^="plus_minus"]').text('+');
        $('table[id^="townwiseData"]').attr('class', 'hide_tbl');
        //end
        $scope.officeObj = [];
        if ($rootScope.officeList != undefined) {
            $.each($rootScope.officeList, function (k) {
                $.each($rootScope.officeList[k], function (i, value) {
                    $('input:checkbox[name="chkstateOffices"]').each(function () {
                        if (this.checked && $rootScope.officeList[k][i].ID == this.value)
                            $scope.officeObj.push($rootScope.officeList[k][i].ID);
                    });
                    if ($scope.Congressional != undefined) {
                        $.each($scope.Congressional, function (j) {
                            if ($rootScope.officeList[k][i].D == $scope.Congressional[j] && $rootScope.officeList[k][i].OT == "C")
                                $scope.officeObj.push($rootScope.officeList[k][i].ID);
                        })
                    }
                    if ($scope.Senatorial != undefined) {
                        $.each($scope.Senatorial, function (j) {
                            if ($rootScope.officeList[k][i].D == $scope.Senatorial[j] && $rootScope.officeList[k][i].OT == "S")
                                $scope.officeObj.push($rootScope.officeList[k][i].ID);
                        })
                    }
                    if ($scope.Assembly != undefined) {
                        $.each($scope.Assembly, function (j) {
                            if ($rootScope.officeList[k][i].D == $scope.Assembly[j] && $rootScope.officeList[k][i].OT == "A")
                                $scope.officeObj.push($rootScope.officeList[k][i].ID);
                        })
                    }
                    if ($scope.Probational != undefined) {
                        $.each($scope.Probational, function (j) {
                            if ($rootScope.officeList[k][i].D == $scope.Probational[j] && $rootScope.officeList[k][i].OT == "PD")
                                $scope.officeObj.push($rootScope.officeList[k][i].ID);
                        })
                    }
                })
            });
        }
        $('#tblRaces').show();
    }
    $scope.clearSearch = function () {
        $('input:checkbox[name="chkstateOffices"]').each(function () {
            this.checked = false;
        });
        $('#ddlCongressional option').attr('selected', false);
        $('#ddlSenatorial option').attr('selected', false);
        $('#ddlAssembly option').attr('selected', false);
        $('#ddlProbational option').attr('selected', false);
        $scope.officeObj = [];
        $scope.Congressional = undefined;
        $scope.Senatorial = undefined;
        $scope.Assembly = undefined;
        $scope.Probational = undefined;
        $('#tblRaces').hide();
    }

    //Add by AbdulSartaj Shaik
    $scope.init = function () {
        if ($rootScope.selectedStatewideOffice != undefined) {
            $scope.officeObj = [];
            if ($rootScope.selectedOfficeType == "SW")
                $scope.officeObj.push($rootScope.selectedStatewideOffice);
            else {
                if ($rootScope.officeList != undefined) {
                    $.each($rootScope.officeList, function (k) {
                        $.each($rootScope.officeList[k], function (i, value) {
                            if ($rootScope.selectedDistrictID != undefined) {
                                if ($rootScope.officeList[k][i].D == $rootScope.selectedDistrictID && $rootScope.officeList[k][i].OT == $rootScope.selectedOfficeType) {
                                    $scope.officeObj.push($rootScope.officeList[k][i].ID);
                                    switch ($rootScope.selectedOfficeType) {
                                        case "C":
                                            $scope.Congressional = [];
                                            $scope.Congressional.push($rootScope.selectedDistrictID);
                                            break;
                                        case "S":
                                            $scope.Senatorial = [];
                                            $scope.Senatorial.push($rootScope.selectedDistrictID);
                                            break;
                                        case "A":
                                            $scope.Assembly = [];
                                            $scope.Assembly.push($rootScope.selectedDistrictID);
                                            break;
                                        case "PD":
                                            $scope.Probational = [];
                                            $scope.Probational.push($rootScope.selectedDistrictID);
                                            break;
                                    }
                                }
                            }
                        });
                    });
                }
            }
            $('#tblRaces').show();
        }
    };

    $scope.dirtrictReport = function (officeId) {
        var towns = "";
        $.ajax({
            type: "POST",
            url: "Default.aspx/GetVotingDistrictValuesByOfficeID",
            data: '{electionID: "' + $rootScope.currentElectionID + '",townID: "' + towns + '",officeId:"' + officeId + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                window.location.href = "Default.aspx?action=VotingDistrictByOfficeID";
                return true;
            },
            failure: function (response) {
                return true;
            }
        });
    }
    $scope.CollapseChild = function (childId) {
        //to show and hide state wide count.
        var showHide = $('#townwiseData' + childId).attr('class');
        switch(showHide)
        {
            case 'show_tbl':
                $('#plus_minus' + childId).text('+');
                $('#townwiseData' + childId).attr('class', 'hide_tbl');
                break;
            case 'hide_tbl':
                //$('#plus_minus' + childId).attr('class', 'glyphicon glyphicon-minus');
                $('#plus_minus' + childId).text('-');
                $('#townwiseData' + childId).attr('class', 'show_tbl');
                break;
        }
    }
 
});