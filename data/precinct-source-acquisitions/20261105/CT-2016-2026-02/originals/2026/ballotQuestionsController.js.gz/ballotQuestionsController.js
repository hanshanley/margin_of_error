﻿enrApp.controller('ballotQuestionsController', function ($scope, $rootScope, $http, $location) {
    $('#subTabsBar').show();    
});