enrApp.controller('HomeController', function ($scope, $rootScope, $http, $location) {
    $('#subTabsBar').show();
    $scope.redirectToRaces = function (officeID, officeType, districtID) {
        $rootScope.selectedStatewideOffice = officeID;
        $rootScope.selectedOfficeType = officeType;
        $rootScope.selectedDistrictID = districtID;
        $location.path('/races');
    }
});