import importlib.util
from pathlib import Path
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('mn_reference',root/'scripts/minnesota-precinct-followup.py')
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
print(core.core.encoded(core.qualify(root)).decode(),end='')
