MINNESOTA: NATIVE TOTAL NUMBER VOTED,84 COMPLETE COUNTIES

COMPLETE CONTENTS
All34 sufficient pins, FULL current+previous native precinct-statistics
originals, full native layout/counties/precincts, all87 county decisions,
all4105 unit decisions, all87 previous/current comparisons, all26 unknown
units/60 component conflicts/seven electorate excesses/nine newly complete
counties. Every earlier retained query/component table/source qualification,
separate Estimated Voters observation, full87-county Census reference,
checksums/code/tests/numerical results and exact offline reproduction. All
three FULL native reference pages,4105 direct full-native reference decisions
and13619 native bbox-pair decisions; remaining8409841 pairs are bbox-disjoint
within all8423460 pairs. All full native shapes are valid with zero positive
overlaps. Sixteen invalid legacy generalizations are retained but not reused,
clipped or repaired. All full native coordinates stay unchanged.
No metadata-only replacement; earlier complete releases remain available.
Acquisition headers, raw page scripts, voter files and identifiers are excluded.
Native public precinct IDs/names are reporting units, not individual voters.

SOURCE MEANING
Unofficial native Total Number Voted, not candidate votes, independently
deduplicated people, certified cast ballots or demographic participation.
4079 of4105 source rows report;84 counties have complete statistics and
Fillmore/Hubbard/Wright remain partial with26 unreported rows. Their subtotals
are not complete county totals; original zero fields in unreported rows are
not observed zeros.2,827,091 is a reported-row subtotal, never an exact state
total or the separate page Estimated Voters2,852,528. Component conflicts and
excesses are unmodified.7AM+Election Day registration is its own source frame,
not November2 Registered-only3,927,036, preregistrations, VEP, CVAP or CPS.
71 county registration fractions pass complete-data/component/electorate
checks; all others are null. No normalized voting-mode/unique-person/first-ever/
eligibility/death/migration or nonparticipation-residual claim is made.
The results page prints11/07/26 5:18 PM; timezone remains unknown. The native
download receipt is separate, not an independently printed file-update clock.

GEOGRAPHY AND WEBSITE
Explicit native county names join the unmodified2026 Census county context
with only case and the County suffix normalized. Both names remain; native
county IDs are NOTFIPS(Becker03 is27005, not27003). Not certified2026 election
precincts. The separate September18,2026 native display-reference joins map
all4105 units:4079 native count reports and26 unknowns. Rates remain null.
Native countycode/pctcode and separate VTD/FIPS fields control identity;
all1723 names differing beyond case remain separate, not guessed aliases.
Current website opt-in selects this WHOLE snapshot over old75county records,
with matching unit tables. Frozen legacy readers/context-review hashes stay
unchanged. Provider early/returned frames are separate, never native-mode
allocations from roster or absentee components.
Packaged local proofs are not native Pages or live production acceptance.

REPRODUCE
Extract every member in an empty directory; no network/source acquisition.
  python reproduce.py > reproduced-queries.json
Output must equal queries.json byte-for-byte; this count reader is stdlib-only.
With pinned requirements for full geometry reproduction:
  python reproduce-precincts.py > reproduced-precinct-reference-queries.json
Output must equal precinct-reference-queries.json byte-for-byte.
  python scripts/test-minnesota-followup.py
  node --test scripts/minnesota-county-followup.test.mjs
  node --test scripts/minnesota-precinct-followup.test.mjs
The included integration/browser tests require the FULL website/other source
families and existing browser tooling. Node's cached-query reader validates
all sufficient pins and the exact prepared cache; Python recomputes from the
full native originals. manifest.json hashes every other member.
