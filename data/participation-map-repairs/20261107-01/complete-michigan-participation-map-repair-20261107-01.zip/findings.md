# Michigan 2026 participation disposition

## Result

- **58 of 63 native rows now have unique official 2026 precinct identities and exact source polygons.**
  - Bay: all 35 native Statistics sections match all 35 official 2026 Bay precinct features.
  - Isabella: 23 native positive rows match all 23 official 2026 Isabella precinct features.
- Those 58 rows retain **76,512 ballots** and **131,895 native registered-voter counts**.
- **Rates remain withheld for all 58.** The election sources provide same-row registration counts, but do not define their active/inactive components. The boundary layer separately supplies `RegisteredVoters` and `ActiveVoters`, and those snapshot values differ from the election counts; neither field is substituted.
- The exact geometry asset is counts-only: all 58 shapes are gray/selectable with ballots and denominators.

## Remaining five rows

- `City of Clare, Precinct 1`: 22 ballots / 43 registrations. The official 2026 feature is `WP-035-15920-00001`, CountyFIPS `035` (Clare), not an Isabella-only split. Assigning the Isabella container's counts to the whole polygon would overstate scope, so geometry and rate remain withheld.
- Four zero rows are confirmed official neighboring-county precincts, not Isabella precincts:
  - Pine River and Seville: CountyFIPS `057` (Gratiot).
  - Greendale and Jasper: CountyFIPS `111` (Midland).

## Bay's 43-versus-35 counter

The report's `43 of 43` Election Day counter is not used as a geographic inventory. The 35 complete native Statistics sections reconcile to the county summary and match the complete official 35-feature Bay inventory one-to-one. No overlapping containers are summed.

## Official references

- State item: `https://www.arcgis.com/sharing/rest/content/items/b7df95c78668407280a7dead8e26aad0`
- Feature service: `https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/VotingPrecinct/FeatureServer/0`
- Title: **2026 Voting Precincts**
- Authority: Michigan Department of State, Bureau of Elections; Center for Shared Solutions, DTMB.
- Item description says the data represent geography used for the **2026 election cycle**, collected from local election officials and GIS authorities.
- Item created May 19, 2026; modified June 2, 2026; preserved layer data edit timestamp September 29, 2026.
- Michigan's official 2026 election calendar says precinct boundaries were finalized January 6, 2026 and alterations could take effect no later than February 5, 2026:
  `https://www.michigan.gov/sos/-/media/Project/Websites/sos/Election-Administrators/Election-Dates.pdf`

The exact public query URLs, response bytes, hashes, and retrieval timestamps are in `sources/receipts.json`.

## Delivery and Pages budget

`verified/MI-2026-qualified-precinct-counts.geojson.gz` is **234,932 bytes**. It is intentionally unsimplified. Its minimum tar contribution would be **235,520 bytes**, but the accepted delivery keeps it under non-public `data/participation-map-repairs/20261107-01/` and fetches it through an immutable raw GitHub commit URL, so it consumes **no Pages geometry payload budget**.

## Integration recommendation

Apply `integration.patch`, copy the complete asset set under `integration-files/data/participation-map-repairs/20261107-01/`, replace the patch's `__PINNED_REVISION__` after committing the data, then run the targeted tests. The UI will expose 58 gray/selectable official 2026 precincts and keep all five unresolved rows in the sidebar/downloads.
