Michigan 2026 participation map repair — aggregate-only complete query package

Scope
-----
Bay and Isabella county native November 3, 2026 participation observations.
No voter-level or person-level records are present.

Disposition
-----------
63 native rows are retained:
  * 58 exact official 2026 precinct identity/polygon matches, counts only.
  * 1 positive City of Clare row excluded from geometry because the official
    polygon is whole CountyFIPS 035, not the Isabella-only source scope.
  * 4 zero rows excluded because official geography confirms they are in
    Gratiot or Midland counties.

The 58 mapped rows contain 76,512 ballots and 131,895 native registrations.
All rates are withheld because native registration components are not defined.
No county containers are summed and no totals are allocated to precincts.

Reproduce offline from preserved sources
----------------------------------------
python3 review_michigan_participation.py \
  --sources sources \
  --output reproduced

python3 verify_all_rows.py \
  --source sources/native-precinct-participation.csv \
  --output reproduced

Re-acquire current public bytes
-------------------------------
python3 acquire_michigan_participation_sources.py --output acquired-sources

The acquisition command requires every downloaded byte to match the preserved
expected SHA-256. A changed public source fails rather than silently replacing
the frozen evidence.

Primary delivery assets
-----------------------
MI-2026-qualified-precinct-counts.geojson.gz
  Exact official source coordinates for 58 features, augmented only with
  aggregate native counts, identity fields, and explicit missing-rate status.

complete-michigan-participation-map-repair-20261107-01.zip
  This complete package, including source bytes, receipts, scripts, proofs,
  permissions, all 63 dispositions, and the upstream complete aggregate query.

Intended repository paths
-------------------------
data/participation-map-repairs/20261107-01/
  MI-2026-qualified-precinct-counts.geojson.gz
  complete-michigan-participation-map-repair-20261107-01.zip
  index.json
  qualified-participation.csv
  withheld-participation.csv
  audit.json
  all-row-proof.json
  independent-verification.json
  checksums.json
  SOURCE-PERMISSIONS.json

The client should fetch the geometry from an immutable raw GitHub commit URL.
Nothing in this package needs to be copied into the Pages public payload.
