"""Acquire the public aggregate inputs for the Michigan 2026 participation map repair."""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen


FILES = {
    "native-precinct-participation.csv": (
        "https://raw.githubusercontent.com/hanshanley/margin_of_error/"
        "03b204adb7bd092e07e192706de2961119960d01/data/precinct-source-reviews/"
        "20261105/MI-2026-native-county-counts-01/precinct-participation.csv",
        "c171ee2a21e976ebb41826ecc95854201e74f8335f664d526d64e3f1e2dbf917",
    ),
    "native-audit.json": (
        "https://raw.githubusercontent.com/hanshanley/margin_of_error/"
        "03b204adb7bd092e07e192706de2961119960d01/data/precinct-source-reviews/"
        "20261105/MI-2026-native-county-counts-01/audit.json",
        "bb2edea0c9a2a1280d012218c7d1418171d409c40bf7d820819e9985739d7634",
    ),
    "native-checksums.json": (
        "https://raw.githubusercontent.com/hanshanley/margin_of_error/"
        "03b204adb7bd092e07e192706de2961119960d01/data/precinct-source-reviews/"
        "20261105/MI-2026-native-county-counts-01/checksums.json",
        "6dd725e7885628bd97a2e1248f2f012658251c78ba481e1c3c837442f2751805",
    ),
    "official-item-metadata.json": (
        "https://www.arcgis.com/sharing/rest/content/items/"
        "b7df95c78668407280a7dead8e26aad0?f=pjson",
        "36b32586aafee249dfa207c7be7d4e469ecb521ff6200dae27c35a63552123ff",
    ),
    "official-service-metadata.json": (
        "https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/"
        "VotingPrecinct/FeatureServer?f=pjson",
        "07c276da369cdeab4edfe937992955df53fc3683931eae1ca075d2eb3c6c046d",
    ),
    "official-layer-metadata.json": (
        "https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/"
        "VotingPrecinct/FeatureServer/0?f=pjson",
        "a0ea8091bb51ab028d0e4eda3ed00232619ee490b5f1cf5a5137f5c93b7a778b",
    ),
    "official-2026-bay-precincts.geojson": (
        "https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/VotingPrecinct/"
        "FeatureServer/0/query?f=geojson&where=CountyFIPS%3D%27017%27&outFields="
        "OBJECTID%2CPrecinctID%2CCountyFIPS%2CMCDFIPS%2CWard%2CPrecinct%2CPrecinctCode"
        "%2CVTD%2CPrecinctLongName%2CPrecinctShortName%2CJurisdictionName%2CElectionYear"
        "%2CRegisteredVoters%2CActiveVoters%2CShape__Area%2CShape__Length&returnGeometry="
        "true&outSR=4326&orderByFields=PrecinctID",
        "a60d4e58c25db21e0086b61dd0799e0dd76688b3514849cb185582300b77fd72",
    ),
    "official-2026-isabella-precincts.geojson": (
        "https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/VotingPrecinct/"
        "FeatureServer/0/query?f=geojson&where=CountyFIPS%3D%27073%27&outFields="
        "OBJECTID%2CPrecinctID%2CCountyFIPS%2CMCDFIPS%2CWard%2CPrecinct%2CPrecinctCode"
        "%2CVTD%2CPrecinctLongName%2CPrecinctShortName%2CJurisdictionName%2CElectionYear"
        "%2CRegisteredVoters%2CActiveVoters%2CShape__Area%2CShape__Length&returnGeometry="
        "true&outSR=4326&orderByFields=PrecinctID",
        "829c711e4450779374342710e22aa93a75e175bdec4586bee3cf7f63e6353e02",
    ),
    "official-2026-clare-query.json": (
        "https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/VotingPrecinct/"
        "FeatureServer/0/query?f=pjson&where=PrecinctLongName+LIKE+%27%25Clare%25%27+OR"
        "+JurisdictionName+LIKE+%27%25Clare%25%27&outFields=OBJECTID%2CPrecinctID%2C"
        "CountyFIPS%2CMCDFIPS%2CWard%2CPrecinct%2CPrecinctCode%2CVTD%2CPrecinctLongName"
        "%2CPrecinctShortName%2CJurisdictionName%2CElectionYear%2CRegisteredVoters%2C"
        "ActiveVoters%2CShape__Area%2CShape__Length&returnGeometry=false&orderByFields="
        "CountyFIPS%2CPrecinctID",
        "d2f3f16dab7918b065764bdc6685a223a67cd69adbbe6266403a4993ebd57b7d",
    ),
    "official-2026-neighbor-precinct-query.json": (
        "https://services3.arcgis.com/dxRQUfTDNtfqZ301/arcgis/rest/services/VotingPrecinct/"
        "FeatureServer/0/query?f=pjson&where=PrecinctLongName%3D%27Pine+River+Township"
        "%2C+Precinct+1%27+OR+PrecinctLongName%3D%27Seville+Township%2C+Precinct+1%27"
        "+OR+PrecinctLongName%3D%27Greendale+Township%2C+Precinct+1%27+OR+"
        "PrecinctLongName%3D%27Jasper+Township%2C+Precinct+1%27&outFields=OBJECTID%2C"
        "PrecinctID%2CCountyFIPS%2CMCDFIPS%2CWard%2CPrecinct%2CPrecinctCode%2CVTD%2C"
        "PrecinctLongName%2CJurisdictionName%2CElectionYear%2CRegisteredVoters%2C"
        "ActiveVoters&returnGeometry=false&orderByFields=CountyFIPS%2CPrecinctID",
        "da10195773d29f929fde990cbef68dbc085c5b4dba91b8f6a75ef4bb8b9fb75c",
    ),
}


def main(output):
    if output.exists():
        raise ValueError("Refusing to overwrite source directory")
    output.mkdir(parents=True)
    receipts = []
    for filename, (url, expected) in FILES.items():
        request = Request(url, headers={"User-Agent": "margin-of-error-public-source-review/1.0"})
        with urlopen(request, timeout=90) as response:
            body = response.read()
            receipt = {
                "file": filename,
                "url": url,
                "status": response.status,
                "content_type": response.headers.get("Content-Type"),
                "etag": response.headers.get("ETag"),
                "last_modified": response.headers.get("Last-Modified"),
                "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
                "retrieved_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }
        if receipt["status"] != 200 or receipt["sha256"] != expected:
            raise ValueError("Public source changed: " + filename)
        (output / filename).write_bytes(body)
        receipts.append(receipt)
    (output / "receipts.json").write_text(json.dumps(receipts, indent=2) + "\n")
    print(json.dumps({"files": len(receipts), "output": str(output)}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    main(args.output.resolve())
