"""Verify Michigan's two-county 2026 participation rows against official precinct geography."""

import csv
import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / "sources"
OUTPUT = ROOT / "verified"
GEOMETRY_ASSET = "MI-2026-qualified-precinct-counts.geojson.gz"
EXPECTED = {
    "native-precinct-participation.csv": "c171ee2a21e976ebb41826ecc95854201e74f8335f664d526d64e3f1e2dbf917",
    "official-item-metadata.json": "36b32586aafee249dfa207c7be7d4e469ecb521ff6200dae27c35a63552123ff",
    "official-layer-metadata.json": "a0ea8091bb51ab028d0e4eda3ed00232619ee490b5f1cf5a5137f5c93b7a778b",
    "official-2026-bay-precincts.geojson": "a60d4e58c25db21e0086b61dd0799e0dd76688b3514849cb185582300b77fd72",
    "official-2026-isabella-precincts.geojson": "829c711e4450779374342710e22aa93a75e175bdec4586bee3cf7f63e6353e02",
    "official-2026-clare-query.json": "d2f3f16dab7918b065764bdc6685a223a67cd69adbbe6266403a4993ebd57b7d",
    "official-2026-neighbor-precinct-query.json": "da10195773d29f929fde990cbef68dbc085c5b4dba91b8f6a75ef4bb8b9fb75c",
}
COUNTY_FIPS = {"bay": "017", "isabella": "073"}
COUNTY_NAMES = {"bay": "Bay County", "isabella": "Isabella County"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integer(value):
    require(re.fullmatch(r"\d+", value or "") is not None, "Missing or malformed native integer")
    return int(value)


def native_identity(row):
    name = row["precinct"]
    match = re.search(r"(?:Pct|Precinct) (\d+)", name)
    require(match is not None, "Missing native precinct number: " + name)
    precinct = int(match.group(1))
    ward_match = re.search(r"Ward (\d+)", name)
    ward = int(ward_match.group(1)) if ward_match else 0
    jurisdiction = name.split(",", 1)[0]
    jurisdiction = {
        "Auburn City": "Auburn",
        "Essexville City": "Essexville",
        "Pinconning City": "Pinconning",
        "Mt. Forest Twp.": "Mount Forest Township",
        "City of Mt. Pleasant": "Mount Pleasant",
        "Union Charter Township": "Union Township",
    }.get(jurisdiction, jurisdiction.replace(" Twp.", " Township"))
    return jurisdiction, ward, precinct


def official_identity(properties):
    return properties["JurisdictionName"], int(properties["Ward"]), int(properties["Precinct"])


def geometry_features(filename, county_fips):
    collection = json.loads((SOURCES / filename).read_text())
    require(collection["type"] == "FeatureCollection", "Official query is not GeoJSON")
    features = collection["features"]
    require(features and len({row["properties"]["PrecinctID"] for row in features}) == len(features),
            "Missing or duplicate official precinct ID")
    for feature in features:
        properties = feature["properties"]
        require(properties["CountyFIPS"] == county_fips and properties["ElectionYear"] == 2026,
                "Wrong official county or election year")
        require(feature["geometry"]["type"] in {"Polygon", "MultiPolygon"}
                and feature["geometry"]["coordinates"], "Missing official polygon")
    return features


def write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    for filename, digest in EXPECTED.items():
        path = SOURCES / filename
        require(path.is_file() and sha(path) == digest, "Changed or missing source: " + filename)
    item = json.loads((SOURCES / "official-item-metadata.json").read_text())
    layer = json.loads((SOURCES / "official-layer-metadata.json").read_text())
    require(item["id"] == "b7df95c78668407280a7dead8e26aad0"
            and item["title"] == "2026 Voting Precincts"
            and item["owner"] == "michigan_admin"
            and item["access"] == "public"
            and "represents the geography used for the 2026 election cycle" in item["description"],
            "Changed official item identity or scope")
    require(layer["serviceItemId"] == item["id"] and layer["name"] == "2026_Voting_Precincts"
            and layer["geometryType"] == "esriGeometryPolygon"
            and layer["displayField"] == "PrecinctLongName",
            "Changed official layer identity")
    aliases = {field["name"]: field["alias"] for field in layer["fields"]}
    require(aliases["RegisteredVoters"] == "Registered Voters"
            and aliases["ActiveVoters"] == "Active Voters"
            and aliases["ElectionYear"] == "Election Year",
            "Changed official electorate fields")

    native = list(csv.DictReader((SOURCES / "native-precinct-participation.csv").open()))
    require(len(native) == 63 and len({row["source_row_id"] for row in native}) == 63,
            "Incomplete or duplicate native participation rows")
    require({row["county_code"] for row in native} == {"bay", "isabella"},
            "Unexpected native county scope")

    official = {
        "bay": geometry_features("official-2026-bay-precincts.geojson", "017"),
        "isabella": geometry_features("official-2026-isabella-precincts.geojson", "073"),
    }
    require(len(official["bay"]) == 35 and len(official["isabella"]) == 23,
            "Changed official two-county precinct inventory")
    official_by_identity = {
        county: {official_identity(feature["properties"]): feature for feature in features}
        for county, features in official.items()
    }
    require(all(len(index) == len(official[county]) for county, index in official_by_identity.items()),
            "Duplicate official structured precinct identity")

    clare = json.loads((SOURCES / "official-2026-clare-query.json").read_text())["features"]
    clare = [row["attributes"] for row in clare
             if row["attributes"]["PrecinctLongName"] == "City of Clare, Precinct 1"]
    require(len(clare) == 1 and clare[0]["CountyFIPS"] == "035",
            "Official City of Clare county scope changed")
    neighbors = {
        row["attributes"]["PrecinctLongName"]: row["attributes"]
        for row in json.loads((SOURCES / "official-2026-neighbor-precinct-query.json").read_text())["features"]
    }
    require({name: row["CountyFIPS"] for name, row in neighbors.items()} == {
        "Pine River Township, Precinct 1": "057",
        "Seville Township, Precinct 1": "057",
        "Greendale Township, Precinct 1": "111",
        "Jasper Township, Precinct 1": "111",
    }, "Neighbor-county official identities changed")

    qualified, withheld, proof_rows, output_features = [], [], [], []
    matched_official = {"bay": set(), "isabella": set()}
    for row in native:
        ballots = integer(row["ballots_cast_total"])
        denominator = integer(row["registered_voters_total"])
        require(ballots <= denominator or denominator == 0 == ballots,
                "Native ballots exceed registration")
        if row["county_code"] == "bay":
            printed = float(row["native_turnout_percent"])
            require(math.isclose(printed, 100 * ballots / denominator, rel_tol=0,
                                 abs_tol=.005000001), "Bay native printed fraction differs")
        else:
            require(row["native_turnout_percent"] == "", "Unexpected Isabella native fraction")
        identity = native_identity(row)
        feature = official_by_identity[row["county_code"]].get(identity)
        if feature is not None:
            properties = feature["properties"]
            require(properties["PrecinctID"] not in matched_official[row["county_code"]],
                    "Official precinct matched more than once")
            matched_official[row["county_code"]].add(properties["PrecinctID"])
            output = {
                "year": 2026,
                "state_code": "MI",
                "county_code": row["county_code"],
                "county": row["county"],
                "precinct": row["precinct"],
                "source_row_id": row["source_row_id"],
                "official_precinct_id": properties["PrecinctID"],
                "official_county_fips": properties["CountyFIPS"],
                "official_mcd_fips": properties["MCDFIPS"],
                "official_ward": properties["Ward"],
                "official_precinct": properties["Precinct"],
                "official_vtd": properties["VTD"],
                "ballots_cast_total": ballots,
                "registered_voters_total": denominator,
                "native_turnout_percent": row["native_turnout_percent"],
                "turnout_rate": "",
                "geometry_approved": "true",
                "rate_approved": "false",
                "rate_withheld_reason": "native_registration_components_not_defined",
                "official_geometry_registered_voters": properties["RegisteredVoters"],
                "official_geometry_active_voters": properties["ActiveVoters"],
                "original_maps_approved": row["maps_approved"].lower(),
                "match_status": "qualified_exact_2026_official_precinct_identity",
            }
            qualified.append(output)
            proof_rows.append({**output, "disposition": "qualified_geometry_counts_only"})
            display_properties = {
                "schema": "participation-map-repair-feature-v1",
                "year": 2026,
                "state_code": "MI",
                "county_code": row["county_code"],
                "key": properties["PrecinctID"],
                "geometry_key": properties["PrecinctID"],
                "county": row["county"],
                "unit": row["precinct"],
                "county_id": "additional:MI:" + row["county_code"],
                "unit_key": row["source_row_id"],
                "unit_kind": "precinct",
                "ballots": ballots,
                "denominator": denominator,
                "participation_measure": "ballots_cast_total",
                "denominator_basis": "native_registered_voters_components_undefined",
                "reported_pct": None,
                "maps_approved": True,
                "rate_approved": False,
                "match_status": "qualified_exact_2026_official_precinct_identity",
                "rate_withheld_reason": "Native registration components are not defined; rate withheld.",
                "boundary_label": "Official State of Michigan 2026 election-cycle precinct boundary",
                "official_precinct_id": properties["PrecinctID"],
                "official_county_fips": properties["CountyFIPS"],
                "official_mcd_fips": properties["MCDFIPS"],
                "official_ward": properties["Ward"],
                "official_precinct": properties["Precinct"],
                "official_vtd": properties["VTD"],
                "source_url": ("https://raw.githubusercontent.com/hanshanley/margin_of_error/"
                               "03b204adb7bd092e07e192706de2961119960d01/data/"
                               "precinct-source-reviews/20261105/MI-2026-native-county-counts-01/"
                               "precinct-participation.csv"),
            }
            output_features.append({
                "type": "Feature",
                "properties": display_properties,
                "geometry": feature["geometry"],
            })
            continue

        base = {
            "year": 2026,
            "state_code": "MI",
            "county_code": row["county_code"],
            "county": row["county"],
            "precinct": row["precinct"],
            "source_row_id": row["source_row_id"],
            "ballots_cast_total": ballots,
            "registered_voters_total": denominator,
            "geometry_approved": "false",
            "rate_approved": "false",
        }
        if row["precinct"] == "City of Clare, Precinct 1":
            withheld_row = {
                **base,
                "official_precinct_id": clare[0]["PrecinctID"],
                "official_county_fips": clare[0]["CountyFIPS"],
                "withheld_reason": "official_geometry_is_whole_clare_county_035_scope_not_isabella_split",
            }
        else:
            literal = re.sub(r" \([^)]+\)$", "", row["precinct"])
            official_row = neighbors[literal]
            withheld_row = {
                **base,
                "official_precinct_id": official_row["PrecinctID"],
                "official_county_fips": official_row["CountyFIPS"],
                "withheld_reason": "official_geometry_confirms_neighbor_county_zero_row_outside_isabella",
            }
        withheld.append(withheld_row)
        proof_rows.append({**withheld_row, "disposition": "withheld_geometry_and_rate"})

    require(len(qualified) == 58 and len(withheld) == 5 and len(proof_rows) == 63,
            "Unexpected Michigan qualification totals")
    require({row["official_precinct_id"] for row in qualified}
            == matched_official["bay"] | matched_official["isabella"],
            "Qualified official ID inventory differs")
    require(len(matched_official["bay"]) == 35 and len(matched_official["isabella"]) == 23,
            "Not every official Bay/Isabella precinct matched exactly once")
    require(len(output_features) == len({row["properties"]["key"] for row in output_features}) == 58,
            "Duplicate or missing display feature")

    native_totals = {
        county: {
            "rows": len(rows),
            "ballots": sum(integer(row["ballots_cast_total"]) for row in rows),
            "registered_voters": sum(integer(row["registered_voters_total"]) for row in rows),
        }
        for county in COUNTY_FIPS
        for rows in [[row for row in native if row["county_code"] == county]]
    }
    qualified_totals = {
        county: {
            "rows": len(rows),
            "ballots": sum(row["ballots_cast_total"] for row in rows),
            "registered_voters": sum(row["registered_voters_total"] for row in rows),
            "official_geometry_registered_voters": sum(
                row["official_geometry_registered_voters"] for row in rows),
            "official_geometry_active_voters": sum(row["official_geometry_active_voters"] for row in rows),
        }
        for county in COUNTY_FIPS
        for rows in [[row for row in qualified if row["county_code"] == county]]
    }
    require(native_totals == {
        "bay": {"rows": 35, "ballots": 50246, "registered_voters": 87721},
        "isabella": {"rows": 28, "ballots": 26288, "registered_voters": 44217},
    }, "Native county totals changed")
    require(qualified_totals["isabella"]["ballots"] == 26266
            and qualified_totals["isabella"]["registered_voters"] == 44174,
            "Isabella qualified scope no longer isolates City of Clare")

    OUTPUT.mkdir(exist_ok=True)
    write_csv(OUTPUT / "qualified-participation.csv", qualified)
    write_csv(OUTPUT / "withheld-participation.csv", withheld)
    collection = {"type": "FeatureCollection", "features": output_features}
    raw_geojson = json.dumps(collection, separators=(",", ":"), ensure_ascii=True).encode()
    with (OUTPUT / GEOMETRY_ASSET).open("wb") as target:
        with gzip.GzipFile(filename="", mode="wb", fileobj=target, mtime=0, compresslevel=9) as archive:
            archive.write(raw_geojson)
    geometry_bytes = (OUTPUT / GEOMETRY_ASSET).stat().st_size
    geometry_sha256 = sha(OUTPUT / GEOMETRY_ASSET)
    proof = {
        "status": "all_63_native_rows_independently_disposed",
        "source_sha256": EXPECTED,
        "all_rows": proof_rows,
        "checks": {
            "source_rows": 63,
            "qualified_geometry_counts_only": 58,
            "withheld_geometry_and_rate": 5,
            "official_bay_features_matched_once": 35,
            "official_isabella_features_matched_once": 23,
            "qualified_ballots": sum(row["ballots_cast_total"] for row in qualified),
            "qualified_registered_voters": sum(row["registered_voters_total"] for row in qualified),
            "withheld_ballots": sum(row["ballots_cast_total"] for row in withheld),
            "withheld_registered_voters": sum(row["registered_voters_total"] for row in withheld),
            "analysis_rates_approved": 0,
        },
    }
    (OUTPUT / "all-row-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    state_metadata = {
        "MI": {
            "boundary_label": "Official State of Michigan 2026 election-cycle precinct boundaries",
            "boundary_source": item["url"],
            "boundary_item_id": item["id"],
            "geometry_file": GEOMETRY_ASSET,
            "geometry_bytes": geometry_bytes,
            "geometry_sha256": geometry_sha256,
            "count_features": 58,
            "rate_features": 0,
            "qualified_counties": ["Bay County", "Isabella County"],
            "withheld_rows": 5,
            "notes": ("Exact structured identities qualify all 35 Bay and 23 Isabella official precinct "
                      "features for direct native counts. Rates remain withheld because native registration "
                      "components are not defined. City of Clare's positive Isabella row cannot use the "
                      "whole CountyFIPS 035 official polygon; four zero rows are official Gratiot/Midland precincts."),
        }
    }
    index = {
        "schema": "participation-map-repair-index-v1",
        "year": 2026,
        "election_date": "2026-11-03",
        "states": {"MI": GEOMETRY_ASSET},
        "state_metadata": state_metadata,
        "boundary_features": 58,
        "matched_precincts": 58,
        "colored_precincts": 0,
        "minimum_electorate": None,
        "boundary_source": item["url"],
        "boundary_item_id": item["id"],
        "complete_download_file": "complete-michigan-participation-map-repair-20261107-01.zip",
        "source_permissions_file": "SOURCE-PERMISSIONS.json",
        "limitations": [
            "Counts are unofficial native election observations; no certification is inferred.",
            "All 58 matched shapes keep rates gray because native registration components are not defined.",
            "Official geometry RegisteredVoters and ActiveVoters are reference-layer fields, not substituted election denominators.",
            "City of Clare's 22 ballots / 43 registrations and four neighboring-county zero rows remain outside the map.",
            "No county containers are summed or allocated to precincts.",
        ],
    }
    (OUTPUT / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    audit = {
        "status": "partial_precinct_geometry_qualified_counts_only_rates_withheld",
        "official_reference": {
            "item_id": item["id"],
            "title": item["title"],
            "owner": item["owner"],
            "access_information": item["accessInformation"],
            "item_created_epoch_ms": item["created"],
            "item_modified_epoch_ms": item["modified"],
            "layer_data_last_edit_epoch_ms": layer["editingInfo"]["dataLastEditDate"],
            "feature_service": item["url"],
            "description": item["description"],
        },
        "native_totals": native_totals,
        "qualified_totals": qualified_totals,
        "qualified_rows": 58,
        "withheld_rows": 5,
        "qualified_ballots": sum(row["ballots_cast_total"] for row in qualified),
        "qualified_registered_voters": sum(row["registered_voters_total"] for row in qualified),
        "withheld_ballots": sum(row["ballots_cast_total"] for row in withheld),
        "withheld_registered_voters": sum(row["registered_voters_total"] for row in withheld),
        "rates_approved": 0,
        "maps_approved": 58,
        "bay_reporting_counter_disposition": (
            "The native 43 of 43 Election Day reporting counter is not treated as geographic inventory. "
            "The 35 native Statistics sections match all 35 official 2026 Bay precinct features one-to-one."
        ),
        "denominator_disposition": (
            "Native per-row Registered Voters - Total / voterRegistration counts are retained as counts. "
            "The official boundary layer's RegisteredVoters and ActiveVoters fields differ from the election "
            "snapshot and are not substituted or used to approve rates."
        ),
        "pages_budget": {
            "reported_headroom_bytes": 43520,
            "exact_joined_geojson_bytes": len(raw_geojson),
            "exact_joined_geojson_gzip_bytes": geometry_bytes,
            "exact_joined_geojson_minimum_tar_contribution_bytes": (
                geometry_bytes + 512 + (-geometry_bytes) % 512
            ),
            "minimum_additional_headroom_if_public_asset_bytes": (
                geometry_bytes + 512 + (-geometry_bytes) % 512 - 43520
            ),
            "recommended_delivery": (
                "Keep exact geometry under data/ and fetch it from a commit-pinned raw GitHub URL or release asset; "
                "do not add the gzip to the Pages public tree."
            ),
        },
    }
    (OUTPUT / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    checksums = {}
    for path in sorted(OUTPUT.iterdir()):
        if path.is_file() and path.name != "checksums.json":
            checksums[path.name] = {"bytes": path.stat().st_size, "sha256": sha(path)}
    (OUTPUT / "checksums.json").write_text(json.dumps(checksums, indent=2) + "\n")
    print(json.dumps({
        "qualified_rows": audit["qualified_rows"],
        "withheld_rows": audit["withheld_rows"],
        "qualified_ballots": audit["qualified_ballots"],
        "qualified_registered_voters": audit["qualified_registered_voters"],
        "rates_approved": audit["rates_approved"],
        "geometry_asset": GEOMETRY_ASSET,
        "geometry_gzip_bytes": audit["pages_budget"]["exact_joined_geojson_gzip_bytes"],
    }, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources", type=Path, default=SOURCES)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    SOURCES = args.sources.resolve()
    OUTPUT = args.output.resolve()
    main()
