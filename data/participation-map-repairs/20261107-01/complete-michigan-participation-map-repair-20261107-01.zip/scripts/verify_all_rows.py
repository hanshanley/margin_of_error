"""Independently verify every Michigan source row's final disposition."""

import csv
import argparse
import gzip
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "sources/native-precinct-participation.csv"
OUTPUT = ROOT / "verified"
GEOMETRY_ASSET = "MI-2026-qualified-precinct-counts.geojson.gz"


def main():
    source = {row["source_row_id"]: row for row in csv.DictReader(SOURCE.open())}
    qualified = {row["source_row_id"]: row
                 for row in csv.DictReader((OUTPUT / "qualified-participation.csv").open())}
    withheld = {row["source_row_id"]: row
                for row in csv.DictReader((OUTPUT / "withheld-participation.csv").open())}
    proof = json.loads((OUTPUT / "all-row-proof.json").read_text())
    geometry = json.loads(gzip.decompress((OUTPUT / GEOMETRY_ASSET).read_bytes()))
    geometry_rows = {feature["properties"]["unit_key"]: feature for feature in geometry["features"]}
    assert len(source) == 63
    assert len(qualified) == len(geometry_rows) == 58
    assert len(withheld) == 5
    assert set(source) == set(qualified) | set(withheld)
    assert not set(qualified) & set(withheld)
    assert len(proof["all_rows"]) == 63
    assert {row["source_row_id"] for row in proof["all_rows"]} == set(source)
    assert len({row["official_precinct_id"] for row in qualified.values()}) == 58
    assert {row["official_county_fips"] for row in qualified.values()} == {"017", "073"}
    assert sum(int(row["ballots_cast_total"]) for row in qualified.values()) == 76512
    assert sum(int(row["registered_voters_total"]) for row in qualified.values()) == 131895
    assert sum(int(row["ballots_cast_total"]) for row in withheld.values()) == 22
    assert sum(int(row["registered_voters_total"]) for row in withheld.values()) == 43
    assert all(row["turnout_rate"] == "" and row["rate_approved"] == "false"
               for row in qualified.values())
    assert all(feature["properties"]["reported_pct"] is None for feature in geometry["features"])
    for key, row in source.items():
        final = qualified.get(key) or withheld[key]
        assert int(row["ballots_cast_total"]) == int(final["ballots_cast_total"])
        assert int(row["registered_voters_total"]) == int(final["registered_voters_total"])
        if key in qualified:
            feature = geometry_rows[key]
            assert feature["properties"]["ballots"] == int(row["ballots_cast_total"])
            assert feature["properties"]["denominator"] == int(row["registered_voters_total"])
            assert feature["properties"]["official_precinct_id"] == qualified[key]["official_precinct_id"]
    result = {
        "status": "passed",
        "source_rows_checked": 63,
        "qualified_rows_checked": 58,
        "withheld_rows_checked": 5,
        "geometry_features_checked": 58,
        "qualified_ballots": 76512,
        "qualified_registered_voters": 131895,
        "withheld_ballots": 22,
        "withheld_registered_voters": 43,
        "rates_present": 0,
        "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "geometry_asset": GEOMETRY_ASSET,
        "geometry_sha256": hashlib.sha256((OUTPUT / GEOMETRY_ASSET).read_bytes()).hexdigest(),
        "proof_sha256": hashlib.sha256((OUTPUT / "all-row-proof.json").read_bytes()).hexdigest(),
    }
    (OUTPUT / "independent-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    SOURCE = args.source.resolve()
    OUTPUT = args.output.resolve()
    main()
