#!/usr/bin/env python3
"""Reacquire official responses and require exact frozen byte receipts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
from urllib.request import Request, urlopen


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: acquire-official-reference.py OUTPUT_DIRECTORY")
    root = Path(__file__).resolve().parent
    output = Path(sys.argv[1])
    if output.exists():
        raise SystemExit(f"refusing to overwrite: {output}")
    output.mkdir(parents=True)
    manifest = json.loads((root / "query-manifest.json").read_text())
    receipts = {}
    for record in manifest["requests"]:
        request = Request(record["url"], headers={"User-Agent": "margin-of-error-vermont-proof/1"})
        with urlopen(request, timeout=120) as response:
            body = response.read()
        digest = hashlib.sha256(body).hexdigest()
        if len(body) != record["bytes"] or digest != record["sha256"]:
            raise ValueError(
                f"official response changed: {record['file']} "
                f"({len(body)} bytes, {digest})"
            )
        path = output / record["file"]
        path.write_bytes(body)
        receipts[record["file"]] = {
            "url": record["url"],
            "bytes": len(body),
            "sha256": digest,
        }
    (output / "receipts.json").write_text(json.dumps(receipts, indent=2) + "\n")
    print(json.dumps({"verified_exact_responses": len(receipts)}, indent=2))


if __name__ == "__main__":
    main()
