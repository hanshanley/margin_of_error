# Proposed immutable publication

No GitHub write has been performed by this package builder.

## Proposed draft release

Repository: `hanshanley/margin_of_error`  
Tag: `voter-participation-vermont-municipal-20261107`

Release assets:

1. `complete-vermont-2026-municipal-participation.zip`
2. `vermont-municipal-participation.geojson.gz`

After the parent uploads and byte-verifies the draft, the intended public URLs
are:

`https://github.com/hanshanley/margin_of_error/releases/download/voter-participation-vermont-municipal-20261107/complete-vermont-2026-municipal-participation.zip`

`https://github.com/hanshanley/margin_of_error/releases/download/voter-participation-vermont-municipal-20261107/vermont-municipal-participation.geojson.gz`

The browser may use the release geometry URL only after the parent verifies
cross-origin `GET` behavior in production.

## Version-pinned raw fallback

If the release route is unsuitable for browser CORS, commit the standalone
geometry file at:

`data/participation-municipal/20261107-vermont-01/vermont-municipal-participation.geojson.gz`

Then use:

`https://raw.githubusercontent.com/hanshanley/margin_of_error/<IMMUTABLE_COMMIT_SHA>/data/participation-municipal/20261107-vermont-01/vermont-municipal-participation.geojson.gz`

`<IMMUTABLE_COMMIT_SHA>` must be replaced with the exact publishing commit;
never use a branch name. The final raw URL cannot be fixed before that parent
commit exists.

## Browser semantics

- Join by `properties.key` (`additional:VT:<town_id>`).
- Color only non-null `registered_turnout_pct`.
- Keep all six null rates gray and selectable with their native counts.
- Do not copy municipal values to the separate 2026 reporting-split layer.
- Do not include the nine unincorporated boundary-only polygons.
