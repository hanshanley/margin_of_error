# Vermont 2026 municipal participation

This immutable, aggregate-only package joins all 247 native Vermont municipal
participation rows to exact official VCGI town polygons.

## Qualified result

- 247 municipality rows and exact municipality geometries
- 241 reviewed registered-voter fractions
- six explicitly withheld rates retained as `null`
- 311,009 ballots and 506,512 source-reported registered voters
- zero positive-area overlaps among the 247 delivered municipalities
- no municipal totals assigned to House, Senate, ward, or other reporting splits
- no person-level or private records

The six withheld rates are Colchester, Grand Isle, Orwell, Rockingham, West
Rutland, and Winooski. Their native counts and review flags remain present.

## Contents

- `data/municipal-participation.json.gz`: all 247 frozen source observations
- `data/vermont-municipal-participation.geojson.gz`: all 247 observations plus
  their exact qualified municipality geometry
- `originals/vcgi-town-boundary-query/`: exact official query response and
  service, layer, count, item, and Essex identity responses
- `query-manifest.json`: exact request URLs, byte lengths, and SHA-256 receipts
- `verify.py`: checksum, identity, value, geometry, overlap, and privacy verifier
- `acquire-official-reference.py`: optional exact-response reacquisition check
- `proof/`: independent validation, join table, and retained-source audits
- `SOURCE-AND-PERMISSION.md`: source identity, permission, and limitations
- `PUBLICATION.md`: proposed immutable release and browser paths

## Verify

Use Python 3.11 or newer:

```bash
python -m pip install -r requirements.txt
python verify.py
```

The verifier never fetches the network. It compares all packaged files to
`checksums.json`, then independently compares every town ID, name, ballot
count, registration count, rate, quality flag, GEOID, and geometry.

## Reproduce the official query

The package already includes the exact qualified response. To check whether the
public official endpoints still return those exact bytes:

```bash
python acquire-official-reference.py reproduced-official-reference
```

The command refuses to overwrite an existing directory and fails if any
response differs from the frozen byte length or SHA-256 receipt. A later source
change does not invalidate this immutable package; it identifies a new source
version that requires a separate review.
