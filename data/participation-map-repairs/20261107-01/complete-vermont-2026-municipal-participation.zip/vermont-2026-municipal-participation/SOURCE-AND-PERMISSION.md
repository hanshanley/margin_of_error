# Source identity, permission, and limitations

## Qualified municipal reference

The delivered geometry comes from the official Vermont Center for Geographic
Information open-data FeatureServer:

`FS_VCGI_OPENDATA_Boundary_BNDHASH_poly_towns_SP_v1/FeatureServer/0`

Layer URL:

`https://services1.arcgis.com/BkFxaEFNwHqX3tAw/arcgis/rest/services/FS_VCGI_OPENDATA_Boundary_BNDHASH_poly_towns_SP_v1/FeatureServer/0`

Item metadata URL:

`https://www.arcgis.com/sharing/rest/content/items/3f464b0e1980450e9026430a635bff0a?f=pjson`

The complete exact query URL and its immutable byte receipt are recorded in
`query-manifest.json`.

ArcGIS item ID: `3f464b0e1980450e9026430a635bff0a`  
Owner: `Services_VCGI`  
Item title: `VT Data - Town Boundaries`  
Layer geometry: `esriGeometryPolygon`  
Native identity fields: `TOWNNAME`, `TOWNNAMEMC`, `TOWNGEOID`, `FIPS6`, `CNTY`

The item is public and identifies VCGI as the source. Its license text permits
general mapping use while disclaiming errors, misuse, merchantability, and
fitness for a particular purpose. VCGI states that BNDHASH is not a legally
definitive boundary product. This package therefore describes these as exact
copies of the qualified official reference—not legally controlling boundaries.

The frozen layer metadata reports `dataLastEditDate=1746207785933`
(May 2, 2025 UTC).

## Why `ESRICMP_BuildingFootprintsVT_v1/MapServer/0` can look unrelated

VCGI also publishes the same municipal-reference role through a MapServer
container whose parent service is named
`ESRICMP_BuildingFootprintsVT_v1`. ArcGIS layer identity is determined by the
layer metadata, not by the parent container name. Layer 0 reports:

- native layer name `Town Boundaries`
- polygon geometry
- display field `TOWNNAME`
- identity fields `OBJECTID`, `FIPS6`, `TOWNNAME`, `TOWNNAMEMC`, `CNTY`,
  and `TOWNGEOID`
- VCGI copyright and the BNDHASH municipal-boundary description

Thus the superficially unrelated service name is a legacy/container naming
artifact; layer 0 itself is the VCGI town-boundary layer. “Authoritative” here
means officially published by VCGI as Vermont's general-mapping municipal
reference, not legally definitive.

Alternate layer URL:

`https://maps.vcgi.vermont.gov/arcgis/rest/services/VCGI_services/ESRICMP_BuildingFootprintsVT_v1/MapServer/0`

For clarity and reproducibility, this package does **not** freeze or query that
misleadingly named container. It uses the transparently named official
BNDHASH town FeatureServer above. The alternate endpoint is explanatory only.

## Participation source

The 247 rows are the frozen aggregate municipal observations from the retained
Vermont 2026 election package. They contain municipality identifiers, aggregate
ballots, aggregate registrations, provisional fractions, reporting counters,
source URL, and review flags. They contain no voter names, addresses, contact
details, device identifiers, or person-level records.

The election observations and the VCGI boundary reference are separate sources.
The join never assigns a municipal value to a legislative reporting split.

## Essex identities

Two election names differ from the boundary names:

- `ESSEX TOWN` → `ESSEX`, GEOID `5000724175`
- `ESSEX JUNCTION CITY` → `ESSEX JUNCTION`, GEOID `5000724400`

Each alias is proven by a unique, complete matching House/Senate split set and
the official 2026 voting-area GEOID. No fuzzy alias or geometry proximity is
used.
