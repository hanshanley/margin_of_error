#!/usr/bin/env python3
"""Verify the immutable Vermont aggregate municipality package."""

from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

from shapely import coverage_is_valid
from shapely.geometry import shape
from shapely.strtree import STRtree

ROOT = Path(__file__).resolve().parent
ALIASES = {
    "ESSEX TOWN": "ESSEX",
    "ESSEX JUNCTION CITY": "ESSEX JUNCTION",
}
UNINCORPORATED = {
    "AVERILL",
    "AVERY'S GORE",
    "BUELS GORE",
    "FERDINAND",
    "GLASTENBURY",
    "LEWIS",
    "SOMERSET",
    "WARNER'S GRANT",
    "WARREN'S GORE",
}
PARTICIPATION_FIELDS = {
    "ballots",
    "denominator",
    "districts",
    "districts_reporting",
    "provisional",
    "quality_flags",
    "registered_turnout_pct",
    "registered_voters",
    "reported_house_contest_total",
    "reporting_unit_kind",
    "source_url",
    "state_code",
    "town",
    "town_id",
    "uninterpreted_source_tabs",
    "year",
}
AGGREGATE_FIELDS = {
    "ballots",
    "boundary_name",
    "boundary_object_id",
    "boundary_reference",
    "boundary_source",
    "districts",
    "districts_reporting",
    "key",
    "name",
    "quality_flags",
    "registered_turnout_pct",
    "registered_voters",
    "town_geoid",
    "town_id",
}


def load_gzip(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def positive_overlaps(geometries, tolerance=1e-12):
    tree = STRtree(geometries)
    result = []
    for left_index, left in enumerate(geometries):
        for right_index in tree.query(left, predicate="intersects"):
            right_index = int(right_index)
            if right_index <= left_index:
                continue
            area = left.intersection(geometries[right_index]).area
            if area > tolerance:
                result.append((left_index, right_index, area))
    return result


def main():
    checksums = json.loads((ROOT / "checksums.json").read_text())
    for relative, receipt in checksums.items():
        path = ROOT / relative
        body = path.read_bytes()
        if len(body) != receipt["bytes"] or hashlib.sha256(body).hexdigest() != receipt["sha256"]:
            raise ValueError(f"checksum mismatch: {relative}")

    queries = json.loads((ROOT / "query-manifest.json").read_text())
    for record in queries["requests"]:
        path = ROOT / "originals/vcgi-town-boundary-query" / record["file"]
        body = path.read_bytes()
        if len(body) != record["bytes"] or hashlib.sha256(body).hexdigest() != record["sha256"]:
            raise ValueError(f"official query receipt mismatch: {record['file']}")

    original = json.loads(
        (ROOT / "originals/vcgi-town-boundary-query/town-boundaries.geojson").read_bytes()
    )
    count = json.loads(
        (ROOT / "originals/vcgi-town-boundary-query/town-count.json").read_bytes()
    )
    item = json.loads(
        (ROOT / "originals/vcgi-town-boundary-query/town-item.json").read_bytes()
    )
    layer = json.loads(
        (ROOT / "originals/vcgi-town-boundary-query/town-layer.json").read_bytes()
    )
    if (
        count["count"] != 256
        or len(original["features"]) != 256
        or item["id"] != "3f464b0e1980450e9026430a635bff0a"
        or item["owner"] != "Services_VCGI"
        or item["access"] != "public"
        or item["title"] != "VT Data - Town Boundaries"
        or layer["serviceItemId"] != item["id"]
        or layer["geometryType"] != "esriGeometryPolygon"
    ):
        raise ValueError("official VCGI reference identity or scope changed")

    boundary_by_name = {}
    all_geometries = []
    for feature in original["features"]:
        properties = feature["properties"]
        if set(properties) != {
            "OBJECTID",
            "FIPS6",
            "TOWNNAME",
            "TOWNNAMEMC",
            "CNTY",
            "TOWNGEOID",
            "Shape__Area",
            "Shape__Length",
        }:
            raise ValueError("unexpected official boundary attribute")
        name = properties["TOWNNAME"]
        geoid = properties["TOWNGEOID"]
        if name in boundary_by_name or not geoid.startswith("50") or len(geoid) != 10:
            raise ValueError("invalid or duplicate official municipality identity")
        geometry = shape(feature["geometry"])
        if geometry.is_empty or not geometry.is_valid:
            raise ValueError(f"invalid official geometry: {name}")
        boundary_by_name[name] = feature
        all_geometries.append(geometry)
    if not coverage_is_valid(all_geometries) or positive_overlaps(all_geometries):
        raise ValueError("official municipality reference is not a nonoverlapping coverage")

    participation = load_gzip(ROOT / "data/municipal-participation.json.gz")
    aggregate = load_gzip(ROOT / "data/vermont-municipal-participation.geojson.gz")
    if (
        len(participation) != 247
        or len(aggregate["features"]) != 247
        or len({row["town_id"] for row in participation}) != 247
        or any(set(row) != PARTICIPATION_FIELDS for row in participation)
        or any(set(feature["properties"]) != AGGREGATE_FIELDS for feature in aggregate["features"])
    ):
        raise ValueError("aggregate schema, identity, or row count changed")
    if sum(row["registered_turnout_pct"] is None for row in participation) != 6:
        raise ValueError("withheld-rate inventory changed")

    output_by_id = {feature["properties"]["town_id"]: feature for feature in aggregate["features"]}
    if len(output_by_id) != 247:
        raise ValueError("duplicate output town identity")
    used_boundary_names = set()
    for row in participation:
        feature = output_by_id[row["town_id"]]
        properties = feature["properties"]
        boundary_name = ALIASES.get(row["town"], row["town"])
        boundary = boundary_by_name.get(boundary_name)
        if not boundary:
            raise ValueError(f"missing official municipality: {row['town']}")
        used_boundary_names.add(boundary_name)
        comparisons = {
            "name": row["town"],
            "town_id": row["town_id"],
            "ballots": row["ballots"],
            "registered_voters": row["registered_voters"],
            "registered_turnout_pct": row["registered_turnout_pct"],
            "quality_flags": row["quality_flags"],
            "districts": row["districts"],
            "districts_reporting": row["districts_reporting"],
            "town_geoid": boundary["properties"]["TOWNGEOID"],
            "boundary_name": boundary_name,
            "boundary_object_id": boundary["properties"]["OBJECTID"],
            "key": f"additional:VT:{row['town_id']}",
        }
        for field, expected in comparisons.items():
            if properties[field] != expected:
                raise ValueError(f"changed native value: {row['town']} / {field}")
        if feature["geometry"] != boundary["geometry"]:
            raise ValueError(f"geometry is not the exact official polygon: {row['town']}")

    if set(boundary_by_name) - used_boundary_names != UNINCORPORATED:
        raise ValueError("boundary-only inventory changed")
    delivered_geometries = [shape(feature["geometry"]) for feature in aggregate["features"]]
    if positive_overlaps(delivered_geometries):
        raise ValueError("delivered municipalities overlap")

    proof = {
        "status": "verified",
        "municipalities": len(participation),
        "reviewed_rates": sum(row["registered_turnout_pct"] is not None for row in participation),
        "withheld_rates": sum(row["registered_turnout_pct"] is None for row in participation),
        "ballots": sum(row["ballots"] for row in participation),
        "registered_voters": sum(row["registered_voters"] for row in participation),
        "official_boundary_features": len(original["features"]),
        "boundary_only_unincorporated": sorted(UNINCORPORATED),
        "positive_area_overlap_pairs": 0,
        "exact_geometry_matches": len(aggregate["features"]),
        "person_or_private_records": 0,
    }
    print(json.dumps(proof, indent=2))


if __name__ == "__main__":
    main()
