# Data dictionary

## `municipal-participation.json.gz`

One aggregate row per Vermont election municipality.

- `town_id`, `town`: native election identity
- `registered_voters`, `ballots`: source aggregate counts
- `registered_turnout_pct`: reviewed fraction or `null`
- `quality_flags`: reasons a rate is withheld
- `districts`, `districts_reporting`: native reporting counters
- `reported_house_contest_total`: comparison value only; never substituted for
  ballots
- `denominator`: source denominator description
- `provisional`: native election status

## `vermont-municipal-participation.geojson.gz`

The same aggregate values plus exact official municipality geometry.

- `key`: `additional:VT:<town_id>`
- `town_geoid`: official VCGI municipality identity
- `boundary_name`, `boundary_object_id`: frozen VCGI identity
- `boundary_source`, `boundary_reference`: source and qualification

No candidate vote or legislative-split value is used as participation.
