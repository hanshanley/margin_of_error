"""Package complete acquired original bytes, receipts and standalone replay tools."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--cache", type=Path, required=True)
parser.add_argument("--collector", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise ValueError("Refusing to overwrite an immutable source package")
acquisition = json.loads((args.cache / "acquisition.json").read_text())
receipts = sorted(args.cache.rglob("*.receipt.json"))
assert len(receipts) == 18 and len(acquisition["originals"]) == 16
for path in receipts:
    receipt = json.loads(path.read_text())
    raw = path.with_name(path.name.removesuffix(".receipt.json")).read_bytes()
    assert receipt["status"] == 200 and receipt["bytes"] == len(raw)
    assert receipt["sha256"] == hashlib.sha256(raw).hexdigest()
files = {p.relative_to(args.cache).as_posix(): p.read_bytes()
         for p in args.cache.rglob("*") if p.is_file()}
files["tools/acquire-official-county-followups.py"] = args.collector.read_bytes()
files["tools/package-official-county-followups.py"] = Path(__file__).read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w") as archive:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(raw))
raw = gzip.compress(buffer.getvalue(), mtime=0)
args.output.mkdir(parents=True)
(args.output / "complete-originals.tar.gz").write_bytes(raw)
index = dict(
    status="complete_originals_acquired_review_pending", maps_approved=False,
    source_files=len(receipts), pdf_documents=len(acquisition["originals"]),
    pdf_pages=sum(r["pages"] for r in acquisition["originals"]),
    pdf_bytes=sum(r["bytes"] for r in acquisition["originals"]),
    scope={"ME": "City of Lewiston only; 14 declared PDFs for 13 even years, 2002 through 2026, "
           "including separate 2026 write-ins; not statewide Maine.",
           "PA": "Two official 2026 administrative mail-return / precinct-reporting PDFs, "
           "not candidate results or final turnout."},
    archive=dict(file="complete-originals.tar.gz", bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
    originals=acquisition["originals"], notes=acquisition["notes"],
    next_action="Normalize actual PDF coordinates and reconcile scope/counts before any UI integration. "
    "Keep Lewiston central voting unallocated and PA administrative returns separate from candidate votes.")
(args.output / "index.json").write_text(json.dumps(index, indent=2) + "\n")
(args.output / "checksums.json").write_text(json.dumps(
    {name: hashlib.sha256(body).hexdigest() for name, body in sorted(files.items())}, indent=2) + "\n")
print(json.dumps(index["archive"], indent=2))
