"""Preserve declared Maine originals and separate PA administrative participation reports."""

from datetime import datetime, timezone
import argparse
import hashlib
from html.parser import HTMLParser
import io
import json
from pathlib import Path
import re
from urllib.parse import parse_qs, urljoin, urlsplit

from pypdf import PdfReader
from playwright.sync_api import sync_playwright


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--offline", action="store_true")
args = parser.parse_args()
ROOT = args.output
ROOT.mkdir(exist_ok=True)
INDEXES = {
    "ME": "https://www.lewistonmaine.gov/471/Election-Results",
    "PA": "https://www.pa.gov/agencies/vote/elections/elections-data",
}
runtime = sync_playwright().start()
browser = runtime.chromium.launch()
context = browser.new_context()


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.active = None
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self.active = [dict(attrs).get("href", ""), ""]

    def handle_data(self, data):
        if self.active is not None:
            self.active[1] += data

    def handle_endtag(self, tag):
        if tag == "a" and self.active is not None:
            self.links.append(tuple(self.active))
            self.active = None


def acquire(relative, url):
    path = ROOT / relative
    receipt_path = path.with_suffix(path.suffix + ".receipt.json")
    if path.exists():
        raw = path.read_bytes()
        receipt = json.loads(receipt_path.read_text())
        assert receipt["url"] == url and receipt["status"] == 200
        assert receipt["bytes"] == len(raw) and receipt["sha256"] == hashlib.sha256(raw).hexdigest()
        return raw, receipt
    if args.offline:
        raise FileNotFoundError("Required complete original is missing: " + relative)
    page = None
    if url in INDEXES.values():
        page = context.new_page()
        response = page.goto(url, wait_until="domcontentloaded", timeout=90000)
    else:
        response = context.request.get(url, timeout=90000)
    raw = response.body()
    receipt = dict(url=url, resolved_url=response.url, status=response.status,
                   bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                   acquired_at=datetime.now(timezone.utc).isoformat(),
                   headers={k: v for k, v in response.headers.items()
                            if k.lower() in {"content-type", "etag", "last-modified", "date"}})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    if page:
        page.close()
    if not response.ok:
        raise ValueError(f"Original source HTTP {response.status}: {url}")
    return raw, receipt


declared = []
for code, url in INDEXES.items():
    raw, receipt = acquire(code + "/official-index.html", url)
    links = Links()
    links.feed(raw.decode("utf-8"))
    for href, label in links.links:
        label = " ".join(label.split())
        source = urljoin(url, href)
        if code == "ME":
            election = re.search(r"November\s+(\d{1,2}),?\s+(20\d{2})", label)
            if not election or int(election[2]) % 2 or not re.search("general|write-in", label, re.I):
                continue
            assert urlsplit(source).hostname == "www.lewistonmaine.gov"
            if "/DocumentCenter/View/" in source:
                identity = source.split("/DocumentCenter/View/", 1)[1].split("/")[0].split("?")[0]
            else:
                assert urlsplit(source).path == "/DocumentView.aspx"
                identity = parse_qs(urlsplit(source).query)["DID"][0]
            assert identity.isdecimal()
            name = f"ME/{election[2]}-{identity}.pdf"
        else:
            if label not in {"2026 Supplemental Election Returns Report", "12:01 County Mail Ballot Report"}:
                continue
            assert urlsplit(source).hostname == "www.pa.gov" and source.lower().endswith(".pdf")
            name = "PA/" + source.rsplit("/", 1)[1]
        declared.append(dict(state_code=code, label=label, url=source, file=name))

assert len({r["file"] for r in declared}) == len(declared)
assert {int(re.search(r"November\s+\d{1,2},?\s+(20\d{2})", r["label"])[1])
        for r in declared if r["state_code"] == "ME"} == set(range(2002, 2027, 2))
assert sum(r["state_code"] == "PA" for r in declared) == 2
assert sum("2026" in r["label"] and r["state_code"] == "ME" for r in declared) == 2


def document(row):
    raw, receipt = acquire(row["file"], row["url"])
    assert raw.startswith(b"%PDF-"), row
    pdf = PdfReader(io.BytesIO(raw), strict=True)
    texts = [page.extract_text() or "" for page in pdf.pages]
    assert texts, row
    text_path = ROOT / Path(row["file"]).with_suffix(".txt")
    text_path.write_text("\n\n".join(texts))
    return dict(row, pages=len(texts), bytes=len(raw), sha256=receipt["sha256"],
                extracted_text_bytes=text_path.stat().st_size,
                status="complete_original_acquired_not_normalized",
                geography="City of Lewiston only" if row["state_code"] == "ME"
                else "Pennsylvania counties; administrative mail returns / precinct reporting, not candidate votes")


inventory = [document(row) for row in declared]
(ROOT / "acquisition.json").write_text(json.dumps(dict(
    originals=inventory,
    notes="Full declared source bytes preserved. No new map, candidate-party classification, "
          "county aggregation, turnout rate, precinct allocation or statewide Maine completeness is approved. "
          "Lewiston C-V is separate central voting; write-in Absentees is a different native label. "
          "PA returned-mail counts are administrative and precincts reporting are not voters."
), indent=2) + "\n")
print(json.dumps(dict(documents=len(inventory), pages=sum(r["pages"] for r in inventory),
                      original_pdf_bytes=sum(r["bytes"] for r in inventory),
                      output=str(ROOT)), indent=2))
browser.close()
runtime.stop()
