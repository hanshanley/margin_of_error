import hashlib
import json
from pathlib import Path
import re

import fitz
from PIL import Image

files = Path(__file__).parent
source = files / "precinct-expansion-sources/MA-2026"
cells = source / "governor-cell-second-reading"
tight = cells / "tight-crops"
review = json.loads((files / "worcester-native-visual-review.json").read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(source / "official-worcester-declared-2026-general-results.pdf") == review["source_pdf_sha256"]
assert sha(files / "worcester-native-cell-review-manifest.json") == review["cell_review_manifest_sha256"]
assert sha(files / "worcester-native-cell-review.png") == review["cell_review_image_sha256"]
for name, digest in review["identity_images"].items():
    assert sha(files / name) == digest
review_manifest = json.loads((files / "worcester-native-cell-review-manifest.json").read_bytes())
assert len(review_manifest) == len(review["cell_values_in_explicit_review_index_order"]) == 35
manual = {}
for entry, value in zip(review_manifest, review["cell_values_in_explicit_review_index_order"]):
    assert sha(tight / entry["file"]) == entry["tight_crop_sha256"]
    assert type(value) is int and value >= 0
    manual[entry["file"]] = value
precincts = review["precinct_codes_read_in_actual_source_order"]
assert len(set(precincts)) == len(precincts) == 62
assert "4-2A" in precincts and "7-5A" in precincts
document = fitz.open(source / "official-worcester-declared-2026-general-results.pdf")
assert len(document) == 60
for page in [15, 16, 27, 28, 39, 40, 51, 52]:
    raster = document[page - 1].get_pixmap(matrix=fitz.Matrix(240 / 72, 240 / 72), alpha=False)
    original = Image.open(source / f"derived-worcester-page-{page:03}-240dpi.png").convert("RGB")
    assert original.size == (raster.width, raster.height) == (2640, 2040)
    assert original.tobytes() == raster.samples, page
rapid = [row for path in sorted((tight / "independent-rapidocr").glob("ocr-*.json"))
         for row in json.loads(path.read_bytes())]
parent_manifest = json.loads((cells / "manifest.json").read_bytes())
tight_manifest = json.loads((tight / "manifest.json").read_bytes())
assert len(rapid) == len(parent_manifest["cells"]) == len(tight_manifest["cells"]) == 1260
matrix = {}
for entry, parent, crop in zip(rapid, parent_manifest["cells"], tight_manifest["cells"]):
    name = entry["file"]
    assert name == parent["file"] == crop["file"]
    assert sha(cells / name) == parent["sha256"] == crop["parent_sha256"]
    assert sha(tight / name) == crop["sha256"]
    page, row, column = map(int, re.fullmatch(r"page-(\d+)-row-(\d+)-col-(\d+).png", name).groups())
    if name in manual:
        value = manual[name]
    else:
        assert entry["result"] and len(entry["result"]) == 1, entry
        text = entry["result"][0][0].strip()
        assert re.fullmatch(r"0|[1-9][0-9]*", text), entry
        value = int(text)
    assert column not in matrix.setdefault(page, {}).setdefault(row, {}), name
    matrix[page][row][column] = value
values = {}
footers = {}
for first, mode in [(15, "overall"), (27, "election_day"), (39, "early_voting_1"), (51, "early_voting_2")]:
    assert list(matrix[first]) == list(range(1, 39))
    assert list(matrix[first + 1]) == list(range(1, 26))
    rows = list(matrix[first].values()) + list(matrix[first + 1].values())[:-1]
    assert len(rows) == 62 and all(set(row) == set(range(1, 6)) for row in rows)
    footer = matrix[first + 1][25]
    actual = [sum(row[column] for row in rows) for column in range(1, 6)]
    expected = [footer[column] for column in range(1, 6)]
    assert actual == expected, (mode, actual, expected)
    values[mode] = {precinct: [row[column] for column in range(1, 6)]
                    for precinct, row in zip(precincts, rows)}
    footers[mode] = expected
failures = []
for precinct in precincts:
    for column in range(5):
        actual = sum(values[mode][precinct][column] for mode in
                     ["election_day", "early_voting_1", "early_voting_2"])
        expected = values["overall"][precinct][column]
        if actual != expected:
            failures.append(dict(precinct=precinct, column=column + 1, overall=expected,
                                 sum_of_three_modes=actual))
assert not failures, failures
proof = dict(status="passed", scope="Worcester governor candidate/write-in/blank accounting only; "
    "not unique voters, registration or turnout; geometry not acquired",
    source_pdf_sha256=review["source_pdf_sha256"], source_pages=60,
    governor_panels=[15, 16, 27, 28, 39, 40, 51, 52], precincts=62,
    voting_modes=4, original_image_pixels_verified_against_pdf=True,
    actual_identities_visually_verified_all_four_modes=True,
    split_precincts_preserved=["4-2A", "7-5A"], source_count_cells=1260,
    visually_reviewed_unknown_or_conflicting_cells=35,
    all_four_candidate_footers_reconcile=True,
    all_310_precinct_candidate_mode_relations_reconcile=True,
    footers=footers, values=values)
(files / "worcester-2026-native-governor-reconciliation.json").write_text(json.dumps(proof, indent=2) + "\n")
print("WORCESTER_NATIVE_GOVERNOR_FULL_RECONCILIATION_PASSED",
      json.dumps({k: v for k, v in proof.items() if k != "values"}))
