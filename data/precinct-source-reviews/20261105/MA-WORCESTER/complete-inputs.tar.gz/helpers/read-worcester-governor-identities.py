import hashlib
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageOps

files = Path(__file__).parent
source = files / "precinct-expansion-sources/MA-2026"
parent = source / "governor-cell-second-reading/manifest.json"
cells = json.loads(parent.read_bytes())["cells"]
output = source / "governor-identity-second-reading"
output.mkdir(exist_ok=True)
manifest = []
for cell in cells[::5]:
    path = source / cell["source_image"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == cell["source_image_sha256"]
    y0, y1 = cell["source_pixel_box"][1], cell["source_pixel_box"][3]
    box = [30, y0 - 2, 410, y1 + 2]
    image = Image.open(path).convert("L").crop(box)
    image = ImageOps.expand(image.resize((image.width * 3, image.height * 3),
                                        Image.Resampling.LANCZOS), border=24, fill=255)
    name = cell["file"].replace("-col-1", "-identity")
    target = output / name
    image.save(target)
    manifest.append(dict(file=name, count_first_column=cell["file"],
        source_image=path.name, source_image_sha256=cell["source_image_sha256"],
        source_pixel_box=box, scale=3, padding=24, interpolation="Pillow Lanczos",
        sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(output / "manifest.json").write_text(json.dumps(dict(
    status="Unverified identity reading; no generated or inferred precinct identifiers",
    parent_manifest_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
    cells=manifest), indent=2) + "\n")
for offset in range(0, len(manifest), 100):
    response = subprocess.run([str(files / "ocr-native-vision"),
        *(str(output / crop["file"]) for crop in manifest[offset:offset + 100])],
        capture_output=True, check=True)
    (output / f"ocr-{offset:04}.json").write_bytes(response.stdout)
    print("SOURCE_IDENTITY_ROWS_READ", offset, flush=True)
