import hashlib
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageOps

files = Path(__file__).parent
source = files / "precinct-expansion-sources/MA-2026/governor-cell-second-reading"
original_manifest = json.loads((source / "manifest.json").read_bytes())
output = source / "tight-crops"
output.mkdir(exist_ok=True)
manifest = []
for cell in original_manifest["cells"]:
    path = source / cell["file"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == cell["sha256"]
    image = Image.open(path).convert("L")
    bounds = image.point(lambda value: 255 if value < 128 else 0).getbbox()
    assert bounds is not None, cell["file"]
    box = [max(0, bounds[0] - 4), max(0, bounds[1] - 4),
           min(image.width, bounds[2] + 4), min(image.height, bounds[3] + 4)]
    target = output / path.name
    ImageOps.expand(image.crop(box), border=12, fill=255).save(target)
    manifest.append(dict(file=cell["file"], parent_sha256=cell["sha256"],
        parent_pixel_box=box, padding=12, sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(output / "manifest.json").write_text(json.dumps(dict(
    status="Unverified extra reading; no approved counts",
    method="Rectangle enclosing ALL pixels below 128, expanded by 4, padding 12; "
           "retains original grayscale pixels, no inpainting, component removal or binarized OCR input",
    parent_manifest_sha256=hashlib.sha256((source / "manifest.json").read_bytes()).hexdigest(),
    cells=manifest), indent=2) + "\n")
for offset in range(0, len(manifest), 100):
    response = subprocess.run([str(files / "ocr-native-vision"),
        *(str(output / cell["file"]) for cell in manifest[offset:offset + 100])],
        capture_output=True, check=True)
    (output / f"ocr-{offset:04}.json").write_bytes(response.stdout)
    print("ALL_INK_RECTANGULAR_CROPS_READ", offset, flush=True)
