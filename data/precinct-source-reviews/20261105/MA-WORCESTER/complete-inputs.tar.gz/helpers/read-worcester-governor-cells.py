import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

import numpy as np
from PIL import Image, ImageOps

parser = argparse.ArgumentParser()
parser.add_argument("--trial", action="store_true")
args = parser.parse_args()
files = Path(__file__).parent
source = files / "precinct-expansion-sources/MA-2026"
output = source / ("governor-cell-trial" if args.trial else "governor-cell-second-reading")
output.mkdir(exist_ok=True)
manifest = []
for page in ([15] if args.trial else [15, 16, 27, 28, 39, 40, 51, 52]):
    path = source / f"derived-worcester-page-{page:03}-240dpi.png"
    image = Image.open(path).convert("L")
    a = np.asarray(image)
    h, w = a.shape
    profile = (a[:, int(w * .416):int(w * .625)] < 155).mean(axis=1)
    indices = np.where((profile > .55) & (np.arange(h) > h * .345) &
                       (np.arange(h) < h * .94))[0]
    groups = []
    for y in indices:
        if groups and y <= groups[-1][-1] + 1:
            groups[-1].append(int(y))
        else:
            groups.append([int(y)])
    ys = [sum(group) / len(group) for group in groups]
    assert len(ys) == (39 if page % 12 == 3 else 26), (page, ys)
    assert all(27 < b - a < 33 for a, b in zip(ys, ys[1:]))
    xprofile = (a[int(ys[0]) + 4:int(ys[-1]) - 4, :] < 155).mean(axis=0)
    xs = []
    for approximate in [.411, .455, .499, .543, .587, .631]:
        start, end = int(w * (approximate - .007)), int(w * (approximate + .007))
        x = start + int(xprofile[start:end].argmax())
        assert xprofile[x] > .6, (page, x, xprofile[x])
        xs.append(x)
    assert all(110 < b - a < 120 for a, b in zip(xs, xs[1:]))
    for row in range(min(8, len(ys) - 1) if args.trial else len(ys) - 1):
        for column in range(5):
            box = [xs[column] + 5, round(ys[row]) + 3,
                   xs[column + 1] - 5, round(ys[row + 1]) - 3]
            crop = image.crop(box)
            crop = ImageOps.expand(crop.resize((crop.width * 3, crop.height * 3),
                                              Image.Resampling.LANCZOS), border=24, fill=255)
            name = f"page-{page:03}-row-{row + 1:03}-col-{column + 1}.png"
            target = output / name
            crop.save(target)
            manifest.append(dict(file=name, source_page=page, source_image=path.name,
                source_image_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                source_pixel_box=box, scale=3, padding=24, interpolation="Pillow Lanczos",
                sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(output / "manifest.json").write_text(json.dumps(dict(
    status="Unverified second reading; no approved counts or precinct identities",
    engine="Apple Vision revision 3 accurate English, no language correction",
    source_pdf_sha256=hashlib.sha256(
        (source / "official-worcester-declared-2026-general-results.pdf").read_bytes()
    ).hexdigest(),
    source_grid="Independently detected horizontal and vertical source-image borders",
    cells=manifest), indent=2) + "\n")
started = time.time()
for offset in range(0, len(manifest), 100):
    batch = manifest[offset:offset + 100]
    response = subprocess.run([str(files / "ocr-native-vision"),
        *(str(output / cell["file"]) for cell in batch)], check=True, capture_output=True)
    (output / f"ocr-{offset:04}.json").write_bytes(response.stdout)
    values = json.loads(response.stdout)
    print("CROPPED_NATIVE_SECOND_READING", offset, "cells", len(values),
          "elapsed", round(time.time() - started, 1), flush=True)
    if args.trial:
        for cell, value in zip(batch, values):
            print(cell["file"], [line["candidates"][0] for line in value["lines"]], flush=True)
