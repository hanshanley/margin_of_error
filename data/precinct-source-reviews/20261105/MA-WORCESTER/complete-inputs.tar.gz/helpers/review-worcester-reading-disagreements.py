import hashlib
import json
from pathlib import Path
import re

from PIL import Image, ImageDraw, ImageOps

files = Path(__file__).parent
source = files / "precinct-expansion-sources/MA-2026/governor-cell-second-reading"
tight = source / "tight-crops"
rapid = [row for path in sorted((tight / "independent-rapidocr").glob("ocr-*.json"))
         for row in json.loads(path.read_bytes())]
apple = [row for path in sorted(tight.glob("ocr-*.json")) for row in json.loads(path.read_bytes())]
manifest = []
def integer(text):
    return int(text.strip()) if text is not None and re.fullmatch(r"0|[1-9][0-9]*", text.strip()) else None
for a, b in zip(apple, rapid):
    assert Path(a["image"]).name == b["file"]
    av = a["lines"][0]["candidates"][0]["text"] if len(a["lines"]) == 1 else None
    bv = b["result"][0][0] if b["result"] and len(b["result"]) == 1 else None
    ai, bi = integer(av), integer(bv)
    if bi is None or ai is not None and ai != bi:
        path = tight / b["file"]
        manifest.append(dict(review=len(manifest) + 1, file=b["file"],
            tight_crop_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            apple_text=av, rapid_text=bv))
sheet = Image.new("RGB", (900, ((len(manifest) + 4) // 5) * 110), "white")
draw = ImageDraw.Draw(sheet)
for i, cell in enumerate(manifest):
    x, y = (i % 5) * 180, (i // 5) * 110
    page, row, column = re.fullmatch(r"page-(\d+)-row-(\d+)-col-(\d+).png", cell["file"]).groups()
    draw.text((x + 5, y + 3), f'#{cell["review"]} p{int(page)} r{int(row)} c{int(column)}', fill="black")
    image = Image.open(tight / cell["file"]).convert("RGB")
    image = ImageOps.contain(image, (164, 83))
    sheet.paste(image, (x + (180 - image.width) // 2, y + 21 + (83 - image.height) // 2))
    draw.rectangle((x, y, x + 179, y + 109), outline="#cccccc")
sheet.save(files / "worcester-native-cell-review.png")
(files / "worcester-native-cell-review-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print("ACTUAL_NATIVE_CELLS_REQUIRING_VISUAL_REVIEW", len(manifest))
originals = source.parent
for first, last in [(15, 16), (27, 28), (39, 40), (51, 52)]:
    image = Image.new("L", (400, 1930), 255)
    for page, top, bottom, offset in [(first, 720, 1880, 0), (last, 715, 1458, 1180)]:
        original = Image.open(originals / f"derived-worcester-page-{page:03}-240dpi.png").convert("L")
        image.paste(original.crop((25, top, 425, bottom)), (0, offset))
    image.save(files / f"worcester-native-identities-{first:03}-{last:03}.png")
