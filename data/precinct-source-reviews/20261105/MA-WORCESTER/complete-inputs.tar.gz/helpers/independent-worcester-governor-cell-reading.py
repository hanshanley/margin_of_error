import hashlib
import argparse
import importlib.metadata
import json
from pathlib import Path
import re
import time
import sys

print("INDEPENDENT_OCR_RUNTIME", sys.executable, sys.prefix, sys.path, flush=True)

import rapidocr_onnxruntime
from rapidocr_onnxruntime import RapidOCR

files = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path,
    default=files / "precinct-expansion-sources/MA-2026/governor-cell-second-reading")
source = parser.parse_args().source
manifest_path = source / "manifest.json"
manifest = json.loads(manifest_path.read_bytes())
output = source / "independent-rapidocr"
output.mkdir(exist_ok=True)
provenance = dict(status="Unverified independent reading; no approved counts",
    input_manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    packages={name: importlib.metadata.version(name) for name in
              ["rapidocr-onnxruntime", "onnxruntime", "numpy", "opencv-python"]},
    parameters=dict(use_det=False, use_cls=False, use_rec=True),
    models={path.name: dict(bytes=path.stat().st_size,
                            sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for path in Path(rapidocr_onnxruntime.__file__).parent.rglob("*.onnx")})
(output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
engine = RapidOCR()
started = time.time()
for offset in range(0, len(manifest["cells"]), 100):
    results = []
    for cell in manifest["cells"][offset:offset + 100]:
        path = source / cell["file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == cell["sha256"]
        value, elapsed = engine(str(path), use_det=False, use_cls=False, use_rec=True)
        results.append(dict(file=cell["file"], result=value, elapsed=elapsed))
    (output / f"ocr-{offset:04}.json").write_text(json.dumps(results, indent=2) + "\n")
    valid = sum(bool(r["result"]) and len(r["result"]) == 1 and
                re.fullmatch(r"[0-9]+", r["result"][0][0]) is not None for r in results)
    print("INDEPENDENT_NATIVE_CELL_READING", offset, "cells", len(results),
          "plain_integer_reads", valid, "elapsed", round(time.time() - started, 1),
          flush=True)
