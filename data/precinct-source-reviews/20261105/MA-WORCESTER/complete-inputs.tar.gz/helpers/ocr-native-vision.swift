import Foundation
import ImageIO
import Vision

var pages: [[String: Any]] = []
for path in CommandLine.arguments.dropFirst() {
    let url = URL(fileURLWithPath: path)
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
          let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
        fatalError("Cannot decode original page image: \(path)")
    }
    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate
    request.recognitionLanguages = ["en-US"]
    request.usesLanguageCorrection = false
    request.minimumTextHeight = 0.002
    request.revision = VNRecognizeTextRequestRevision3
    try VNImageRequestHandler(cgImage: image).perform([request])
    let lines: [[String: Any]] = (request.results ?? []).map { observation in
        let box = observation.boundingBox
        return [
            "bounds": [box.minX, box.minY, box.width, box.height],
            "candidates": observation.topCandidates(3).map {
                ["text": $0.string, "confidence": $0.confidence] as [String: Any]
            }
        ]
    }
    pages.append([
        "image": path,
        "engine": "Apple Vision accurate English; language correction disabled",
        "request_revision": request.revision,
        "lines": lines
    ])
}
FileHandle.standardOutput.write(
    try JSONSerialization.data(withJSONObject: pages, options: [.prettyPrinted, .sortedKeys])
)
FileHandle.standardOutput.write(Data("\n".utf8))
